package com.ey.model.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.ey.model.entity.Configuration;

@Repository
public interface ConfigurationRepository extends JpaRepository<Configuration, Long> {
    
    // Find configurations created by specific user
    List<Configuration> findByCreatedBy(String createdBy);
    
    // Find configurations by created by and other criteria (if needed)
    List<Configuration> findByCreatedByOrderBySubmittedAtDesc(String createdBy);
}