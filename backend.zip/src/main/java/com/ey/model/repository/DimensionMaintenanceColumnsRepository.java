package com.ey.model.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import com.ey.model.entity.DimensionMaintenanceColumns;

@Repository
public interface DimensionMaintenanceColumnsRepository extends JpaRepository<DimensionMaintenanceColumns, Long> {

    // DELETE method needs @Modifying and @Transactional
    @Modifying
    @Transactional
    @Query("DELETE FROM DimensionMaintenanceColumns dmc WHERE dmc.dimensionTableName = :tableName")
    void deleteByDimensionTableName(@Param("tableName") String tableName);

    // Find columns by dimension table name
    List<DimensionMaintenanceColumns> findByDimensionTableName(String dimensionTableName);

    // Find columns created by specific user (through the parent DimensionMaintenance)
    @Query("SELECT dmc FROM DimensionMaintenanceColumns dmc " +
           "JOIN dmc.dimensionMaintenance dm " +
           "WHERE dm.createdBy = :createdBy")
    List<DimensionMaintenanceColumns> findByCreatedBy(@Param("createdBy") String createdBy);

    // Find columns by dimension table name and created by specific user
    @Query("SELECT dmc FROM DimensionMaintenanceColumns dmc " +
           "JOIN dmc.dimensionMaintenance dm " +
           "WHERE dmc.dimensionTableName = :tableName AND dm.createdBy = :createdBy")
    List<DimensionMaintenanceColumns> findByDimensionTableNameAndCreatedBy(
            @Param("tableName") String tableName,
            @Param("createdBy") String createdBy
    );
}