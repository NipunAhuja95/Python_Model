
// DimensionRepository.java
package com.ey.model.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.ey.model.entity.Dimension;

@Repository
public interface DimensionRepository extends JpaRepository<Dimension, Long> {
    // Find dimensions created by specific user
    List<Dimension> findByCreatedBy(String createdBy);
    
    // Optional: Find active dimensions for user
    List<Dimension> findByCreatedByAndActiveStatus(String createdBy, int activeStatus);
}
