package com.ey.model.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;
import com.ey.model.service.DatabaseConnectionService;
import java.util.Map;

@RestController
@RequestMapping("/api/database")
public class DatabaseConnectionController {

    @Autowired
    private DatabaseConnectionService databaseConnectionService;

    @PostMapping("/executeSql")
    public ResponseEntity<Map<String, Object>> executeSql(@RequestBody Map<String, Object> request) {
        // Get authenticated user
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String currentUser = (authentication != null && authentication.isAuthenticated()) 
            ? authentication.getName() 
            : "anonymous";

        try {
            System.out.println("Received request: " + request);
            
            String dbType = (String) request.get("dbType");
            String host = (String) request.get("host");
            Object portObj = request.get("port");
            String dbName = (String) request.get("dbName");
            String username = (String) request.get("username");
            String password = (String) request.get("password");
            String sql = (String) request.get("sql");

            // Handle port conversion safely
            Integer port;
            if (portObj instanceof String) {
                port = Integer.parseInt((String) portObj);
            } else if (portObj instanceof Integer) {
                port = (Integer) portObj;
            } else {
                throw new IllegalArgumentException("Invalid port format");
            }

            // Validate required fields
            if (dbType == null || host == null || port == null || dbName == null || 
                username == null || password == null || sql == null) {
                throw new IllegalArgumentException("Missing required fields");
            }

            Map<String, Object> result = databaseConnectionService.executeSqlQuery(
                dbType, host, port, dbName, username, password, sql, currentUser
            );

            return ResponseEntity.ok(result);
        } catch (Exception e) {
            System.err.println("Error in executeSql: " + e.getMessage());
            e.printStackTrace();
            return ResponseEntity.badRequest().body(Map.of(
                "error", "Failed to execute SQL query: " + e.getMessage(),
                "data", java.util.Collections.emptyList()
            ));
        }
    }

    @PostMapping("/transferData")
    public ResponseEntity<Map<String, Object>> transferData(@RequestBody Map<String, Object> request) {
        // Get authenticated user
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String currentUser = (authentication != null && authentication.isAuthenticated()) 
            ? authentication.getName() 
            : "anonymous";

        try {
            System.out.println("Received transfer request: " + request);
            
            String dbType = (String) request.get("dbType");
            String host = (String) request.get("host");
            Object portObj = request.get("port");
            String dbName = (String) request.get("dbName");
            String username = (String) request.get("username");
            String password = (String) request.get("password");
            String sql = (String) request.get("sql");
            String targetTableName = (String) request.get("targetTableName");

            // Handle port conversion safely
            Integer port;
            if (portObj instanceof String) {
                port = Integer.parseInt((String) portObj);
            } else if (portObj instanceof Integer) {
                port = (Integer) portObj;
            } else {
                throw new IllegalArgumentException("Invalid port format");
            }

            // Validate required fields
            if (dbType == null || host == null || port == null || dbName == null || 
                username == null || password == null || sql == null || targetTableName == null) {
                throw new IllegalArgumentException("Missing required fields");
            }

            databaseConnectionService.transferDataToLocalTable(
                dbType, host, port, dbName, username, password, sql, targetTableName, currentUser
            );

            return ResponseEntity.ok(Map.of("message", "success"));
        } catch (Exception e) {
            System.err.println("Error in transferData: " + e.getMessage());
            e.printStackTrace();
            return ResponseEntity.badRequest().body(Map.of(
                "message", "error",
                "error", "Failed to transfer data: " + e.getMessage()
            ));
        }
    }
}