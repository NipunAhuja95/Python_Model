package com.ey.model.controller;

import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.http.ResponseEntity;

import com.ey.model.service.DimensionService;
import com.ey.model.service.FileService;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.Strictness;
import com.opencsv.exceptions.CsvValidationException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api")
public class DataReaderController {
	
	@Autowired
	DimensionService dimensionService;
	
	@Autowired
	private FileService fileService;

	private final Gson gson = new Gson();

	GsonBuilder gsonBuilder = new GsonBuilder();

	@PostMapping(value = "/upload", consumes = "multipart/form-data")
	public ResponseEntity<String> fetchExcelData(@RequestPart("file") MultipartFile file,
			@RequestParam("columns") String columns,
			@RequestParam("data") String data,
			@RequestParam("tableName") String tableName) {

		// Check authentication
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		String currentUser = (authentication != null && authentication.isAuthenticated()) ? authentication.getName() : null;
		
		if (currentUser == null) {
			return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("User not authenticated");
		}

		// Process the file and the incoming data
		System.out.println("Received file: " + file.getOriginalFilename());
		System.out.println("Received table name: " + tableName);
		System.out.println("Received columns: " + columns);
		System.out.println("Received data: " + data);
		System.out.println("Created by user: " + currentUser);

		gsonBuilder.setStrictness(Strictness.LENIENT);
		HashMap<String, Object> columnsMap = gsonBuilder.create().fromJson(columns, HashMap.class);
		HashMap<String, Object> dataMap = gsonBuilder.create().fromJson(data, HashMap.class);
		System.out.println(columnsMap);
		System.out.println(dataMap);

		// The createdBy will be automatically set in the service method
		dimensionService.createUploadDimensionDetails(file, columnsMap, dataMap, tableName);
		return new ResponseEntity<>("Entity Created for user: " + currentUser, HttpStatus.OK);
	}

	// GET files - could be user-specific in future if needed
	@GetMapping("/files")
	public ResponseEntity<List<String>> getFiles() {
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		String currentUser = (authentication != null && authentication.isAuthenticated()) ? authentication.getName() : null;
		
		if (currentUser == null) {
			return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
		}
		
		// For now, return all files. In future, you might want to filter by user
		return ResponseEntity.ok(fileService.listFiles());
	}

	@GetMapping("/file-headers")
	public ResponseEntity<Map<String, String>> getFileHeaders(@RequestParam String fileName)
			throws IOException, CsvValidationException {
		
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		String currentUser = (authentication != null && authentication.isAuthenticated()) ? authentication.getName() : null;
		
		if (currentUser == null) {
			return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
		}
		
		return ResponseEntity.ok(fileService.getColumnHeadersAndTypes(fileName));
	}

	@PostMapping("/upload-file")
	public ResponseEntity<Map<String, Object>> uploadFile(@RequestBody Map<String, Object> payload)
			throws IOException, CsvValidationException {
		
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		String currentUser = (authentication != null && authentication.isAuthenticated()) ? authentication.getName() : null;
		
		if (currentUser == null) {
			Map<String, Object> errorResponse = new HashMap<>();
			errorResponse.put("error", "User not authenticated");
			return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(errorResponse);
		}
		
		String fileName = (String) payload.get("fileName");
		String tableName = (String) payload.get("tableName");
		Map<String, Map<String, String>> columnMappings = (Map<String, Map<String, String>>) payload
				.get("columnMappings");
		Map<String, Object> response = new HashMap<>();
		
		// First check if the same table is already present in the db or not.
		boolean exists = fileService.doesTableExists(tableName);

		if (exists) {
			// now delete the data from the table and then insert the new data.
			fileService.replaceTableData(tableName);
			System.out.println("Table data deleted/dropped");
			fileService.createTableAndUploadData(fileName, tableName, columnMappings);
			response.put("message", "Sequence saved successfully for user: " + currentUser);
		} else {
			fileService.createTableAndUploadData(fileName, tableName, columnMappings);
			response.put("message", "Sequence saved successfully for user: " + currentUser);
		}

		return ResponseEntity.ok(response);
	}
}