package com.ey.model.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.ey.model.dto.ConfigurationRequest;
import com.ey.model.entity.Configuration;
import com.ey.model.repository.ConfigurationRepository;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/configurations")
@RequiredArgsConstructor
public class ConfigController {

    @Autowired
    private ConfigurationRepository repo;

    @Autowired
    private RestTemplate restTemplate;

    // CREATE/SAVE Configuration - Auto-set createdBy and send to Python
    @PostMapping
    public ResponseEntity<?> saveAndTrigger(@RequestBody ConfigurationRequest request) {
        // Get authenticated user
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String submittedBy = (authentication != null && authentication.isAuthenticated())
                ? authentication.getName()
                : "anonymous";
        
        // Manual Mapping
        Configuration config = new Configuration();
        config.setValuationDate(request.getValuationDate());
        config.setProjectionTerm(request.getProjectionTerm());
        config.setSensitivitiesFlag(request.isSensitivitiesFlag());
        config.setReinsuranceFlag(request.isReinsuranceFlag());
        config.setRunType(request.getRunType());
        config.setTargetProfitMarginPricing(request.getTargetProfitMarginPricing());
        config.setRiskDiscountRatePricing(request.getRiskDiscountRatePricing());
        config.setPolicyStart(request.getPolicyStart());
        config.setPolicyEnd(request.getPolicyEnd());
        config.setOutputPath(request.getOutputPath());
        config.setOutputSeriatimFlag(request.isOutputSeriatimFlag());
        config.setSelectedProducts(request.getSelectedProducts());

        // Set user tracking fields
        config.setSubmittedBy(submittedBy);
        config.setSubmittedAt(LocalDateTime.now());
        config.setCreatedBy(submittedBy);

        // Save configuration to DB
        Configuration saved = repo.save(config);

        // Call Python Service
        String pythonUrl = "http://192.168.1.5:5000/execute";

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);

        try {
            // 🔹 Convert request to Map and add user tracking fields
            ObjectMapper mapper = new ObjectMapper();
            Map<String, Object> payload = mapper.convertValue(request, Map.class);
            payload.put("created_by", submittedBy);
            payload.put("submitted_by", submittedBy);

            HttpEntity<Map<String, Object>> entity = new HttpEntity<>(payload, headers);

            ResponseEntity<String> response = restTemplate.postForEntity(pythonUrl, entity, String.class);

            // Prepare response
            Map<String, Object> result = new HashMap<>();
            result.put("dbId", saved.getId());
            result.put("pythonResponse", response.getBody());
            result.put("submittedBy", submittedBy);

            return ResponseEntity.ok(result);

        } catch (Exception e) {
            e.printStackTrace();
            Map<String, Object> error = new HashMap<>();
            error.put("error", "Failed to trigger Python process");
            error.put("message", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(error);
        }
    }

    // GET all configurations for logged-in user
    @GetMapping
    public ResponseEntity<List<Configuration>> getUserConfigurations() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String currentUser = (authentication != null && authentication.isAuthenticated())
                ? authentication.getName()
                : null;

        if (currentUser == null) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }

        // Check if user is admin (can see all configurations)
        boolean isAdmin = authentication.getAuthorities().stream()
                .anyMatch(auth -> auth.getAuthority().equals("ROLE_ADMIN"));

        List<Configuration> configurations;
        if (isAdmin) {
            configurations = repo.findAll(); // Admin can see all
        } else {
            configurations = repo.findByCreatedBy(currentUser); // User sees only their own
        }

        return ResponseEntity.ok(configurations);
    }

    // GET specific configuration by ID (with ownership check)
    @GetMapping("/{id}")
    public ResponseEntity<Configuration> getConfiguration(@PathVariable Long id) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String currentUser = (authentication != null && authentication.isAuthenticated())
                ? authentication.getName()
                : null;

        if (currentUser == null) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }

        Configuration config = repo.findById(id).orElse(null);
        if (config == null) {
            return ResponseEntity.notFound().build();
        }

        // Check ownership (or if admin)
        boolean isAdmin = authentication.getAuthorities().stream()
                .anyMatch(auth -> auth.getAuthority().equals("ROLE_ADMIN"));

        if (!isAdmin && !currentUser.equals(config.getCreatedBy())) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).build(); // User can't access others' configs
        }

        return ResponseEntity.ok(config);
    }

    // DELETE configuration (with ownership check)
    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteConfiguration(@PathVariable Long id) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String currentUser = (authentication != null && authentication.isAuthenticated())
                ? authentication.getName()
                : null;

        if (currentUser == null) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }

        Configuration config = repo.findById(id).orElse(null);
        if (config == null) {
            return ResponseEntity.notFound().build();
        }

        // Check ownership (or if admin)
        boolean isAdmin = authentication.getAuthorities().stream()
                .anyMatch(auth -> auth.getAuthority().equals("ROLE_ADMIN"));

        if (!isAdmin && !currentUser.equals(config.getCreatedBy())) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        }

        repo.deleteById(id);
        return ResponseEntity.ok().body("Configuration deleted successfully");
    }
}
