package com.ey.model.controller;

import java.util.List;
import org.springframework.web.bind.annotation.GetMapping;
import com.ey.model.service.TableService;
import com.ey.model.service.DynamicTableService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.Map;

@RestController
@RequestMapping("/api/output-tables")
@CrossOrigin(origins = "*")
public class OutputDataController {

    @Autowired
    private DynamicTableService dynamicTableService;

    @Autowired
    private TableService tableService;

    /**
     * ✅ Fetch all output tables with metadata
     * This replaces old logic that scanned DB for tables.
     */
    @GetMapping
    public List<Map<String, Object>> getOutputTables() {
        return dynamicTableService.getAllOutputMetadata();
    }

    /**
     * ✅ Fetch data for a specific output table (used in modal popup)
     */
    @GetMapping("/data")
    public Map<String, Object> getOutputTableData(
            @RequestParam String tableName,
            @RequestParam(defaultValue = "1") int page,
            @RequestParam(defaultValue = "10") int size) {

        return dynamicTableService.getTableData(tableName, page, size);
    }
    
    @GetMapping("/download")
    public ResponseEntity<byte[]> downloadOutputTable(@RequestParam String tableName) {
        try {
            byte[] csvData = dynamicTableService.exportTableToCSV(tableName);

            return ResponseEntity.ok()
                    .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + tableName + ".csv")
                    .contentType(MediaType.parseMediaType("text/csv"))
                    .body(csvData);
        } catch (Exception e) {
            return ResponseEntity.internalServerError()
                    .body(("Error generating CSV: " + e.getMessage()).getBytes());
        }
    }

}
