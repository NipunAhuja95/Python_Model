
package com.ey.model.controller;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.ollama.OllamaChatModel;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ey.model.config.DatabaseTools;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

@RestController
@RequestMapping("/llm")
@CrossOrigin("*")
public class LLMController {

	private ChatClient chatClient;
	
	private final JdbcTemplate jdbcTemplate;
	
	private DatabaseTools databaseTools;

	public LLMController(OllamaChatModel chatModel, JdbcTemplate jdbcTemplate, DatabaseTools databaseTools) {
		this.chatClient = ChatClient.create(chatModel);
		this.jdbcTemplate = jdbcTemplate;
		this.databaseTools = databaseTools;
	}


//	@PostMapping("/ask")
//	public Map<String, Object> ask(@RequestBody Map<String, String> request) {
//	    String prompt = request.get("prompt");
//
//
//	    // Call LLM synchronously
//	    String resp = chatClient.prompt()
//	                            .user(prompt)
//	                            .tools(databaseTools)
//	                            .call()
//	                            .content();
//	    
//	    List<Map<String, Object>> tableData = new ArrayList<Map<String, Object>>();
//		try {
//			tableData = new ObjectMapper().readValue(resp, new TypeReference<>(){});
//		} catch (JsonProcessingException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//
//	    
//	    return Map.of("data", tableData);
//	}
	
	@PostMapping("/ask")
	public Map<String, Object> ask(@RequestBody Map<String, String> request) {
	    String prompt = request.get("prompt");

	    String resp = chatClient.prompt()
	                            .user(prompt)
	                            .tools(databaseTools)
	                            .call()
	                            .content();

	    List<Map<String, Object>> tableData = new ArrayList<>();

	    try {
	        // Split by lines
	        String[] lines = resp.split("\n");

	        // Find table start (line starting with | and containing headers)
	        int tableStart = -1;
	        for (int i = 0; i < lines.length; i++) {
	            if (lines[i].trim().startsWith("|") && lines[i].contains("|")) {
	                tableStart = i;
	                break;
	            }
	        }

	        if (tableStart != -1 && tableStart + 2 < lines.length) {
	            // Header
	            String[] headers = lines[tableStart].split("\\|");
	            for (int i = 0; i < headers.length; i++) headers[i] = headers[i].trim();

	            // Skip separator row (tableStart + 1)
	            for (int i = tableStart + 2; i < lines.length; i++) {
	                String line = lines[i].trim();
	                if (!line.startsWith("|")) break;

	                String[] cells = line.split("\\|");
	                Map<String, Object> row = new LinkedHashMap<>();
	                for (int j = 1; j < cells.length; j++) { // skip empty first cell
	                    row.put(headers[j], cells[j].trim());
	                }
	                tableData.add(row);
	            }
	        }

	    } catch (Exception e) {
	        e.printStackTrace();
	    }

	    return Map.of("data", tableData, "response", resp);
	}

	

}