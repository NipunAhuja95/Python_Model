package com.ey.model.controller;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;

import com.ey.model.entity.DimensionMaintenance;
import com.ey.model.entity.DynamicDataDvo;
import com.ey.model.service.DimensionService;
import com.ey.model.service.DynamicTableService;

import org.springframework.web.bind.annotation.RequestParam;

@RestController
@RequestMapping("/entity")
public class EntityController {
	
	private static final Logger log = LoggerFactory.getLogger(EntityController.class);
	
	@Autowired
	private DimensionService dimService;
	
    @Autowired
    private DynamicTableService dynamicTableService;
	
    // GET all entities for logged-in user (with admin override)
	@GetMapping("/getAll")
	public ResponseEntity<List<DimensionMaintenance>> getAllEntities(){
		log.debug("REST request to get all Entity Names");
		
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String currentUser = (authentication != null && authentication.isAuthenticated()) ? authentication.getName() : null;
        
        if (currentUser == null) {
            return ResponseEntity.status(401).build(); // Unauthorized
        }
        
        // Check if user is admin
        boolean isAdmin = authentication.getAuthorities().stream()
                .anyMatch(auth -> auth.getAuthority().equals("ROLE_ADMIN"));
        
        List<DimensionMaintenance> entities;
        if (isAdmin) {
            entities = dimService.getAllDimensionDetails(); // Admin sees all
        } else {
            entities = dimService.getDimensionDetailsByUser(currentUser); // User sees only their own
        }
        
        return ResponseEntity.ok(entities);
	}
	
	@GetMapping("/data")
	public DynamicDataDvo getData(@RequestParam String tableName, 
            @RequestParam(defaultValue = "1") int page, 
            @RequestParam(defaultValue = "10") int size)
	{
		// Note: This method doesn't filter by user since it's getting data from user's uploaded tables
		// The table access is already controlled at the dimension maintenance level
		DynamicDataDvo dataDvo = new DynamicDataDvo();
		List<Map<String, Object>> data = dynamicTableService.getDataFromTable(tableName, page, size);
		int totalRows = dynamicTableService.getTotalRows(tableName);
		int totalPages = (int) Math.ceil((double) totalRows / size);
		dataDvo.setData(data);
		dataDvo.setTotalPages(totalPages);
		dataDvo.setTotalRows(totalRows);
		return dataDvo;
	}
	
	// GET tables with columns for logged-in user (with admin override)
	@GetMapping("/getTablesWithColumns")
    public ResponseEntity<Map<String, List<String>>> getTablesWithColumns() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String currentUser = (authentication != null && authentication.isAuthenticated()) ? authentication.getName() : null;
        
        if (currentUser == null) {
            return ResponseEntity.status(401).build(); // Unauthorized
        }
        
        // Check if user is admin
        boolean isAdmin = authentication.getAuthorities().stream()
                .anyMatch(auth -> auth.getAuthority().equals("ROLE_ADMIN"));
        
        Map<String, List<String>> tablesWithColumns;
        if (isAdmin) {
            tablesWithColumns = dimService.getTablesWithColumns(); // Admin sees all
        } else {
            tablesWithColumns = dimService.getTablesWithColumnsByUser(currentUser); // User sees only their own
        }
        
        return ResponseEntity.ok(tablesWithColumns);
    }
	
	@GetMapping("/download")
	public ResponseEntity<byte[]> downloadEntityTable(@RequestParam String tableName) {
	    try {
	        byte[] csvData = dynamicTableService.exportTableToCSV(tableName);
	        return ResponseEntity.ok()
	                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + tableName + ".csv")
	                .contentType(MediaType.parseMediaType("text/csv"))
	                .body(csvData);
	    } catch (Exception e) {
	        return ResponseEntity.internalServerError()
	                .body(("Error generating CSV: " + e.getMessage()).getBytes());
	    }
	}
}