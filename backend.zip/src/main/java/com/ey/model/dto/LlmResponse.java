package com.ey.model.dto;

import java.util.List;
import java.util.Map;

public class LlmResponse {
    private String generatedQuery;
    private String response; // plain LLM text
    private List<Map<String, Object>> data; // SQL result
    private String error;

    public String getGeneratedQuery() {
        return generatedQuery;
    }
    public void setGeneratedQuery(String generatedQuery) {
        this.generatedQuery = generatedQuery;
    }
    public String getResponse() {
        return response;
    }
    public void setResponse(String response) {
        this.response = response;
    }
    public List<Map<String, Object>> getData() {
        return data;
    }
    public void setData(List<Map<String, Object>> data) {
        this.data = data;
    }
    public String getError() {
        return error;
    }
    public void setError(String error) {
        this.error = error;
    }
}
