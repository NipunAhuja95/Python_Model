package com.ey.model.util;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

@Component
public class UserContextHelper {
    
    /**
     * Get the currently authenticated user's email
     */
    public static String getCurrentUserEmail() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        return (authentication != null && authentication.isAuthenticated()) ? authentication.getName() : null;
    }
    
    /**
     * Check if the current user is an admin
     */
    public static boolean isCurrentUserAdmin() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        return authentication != null && 
               authentication.getAuthorities().stream()
                   .anyMatch(auth -> auth.getAuthority().equals("ROLE_ADMIN"));
    }
    
    /**
     * Check if current user can access resource created by specified user
     * (either owner or admin)
     */
    public static boolean canAccessResource(String resourceCreatedBy) {
        String currentUser = getCurrentUserEmail();
        if (currentUser == null) {
            return false;
        }
        
        return isCurrentUserAdmin() || currentUser.equals(resourceCreatedBy);
    }
    
    /**
     * Get current user email with fallback
     */
    public static String getCurrentUserEmailOrDefault(String defaultValue) {
        String user = getCurrentUserEmail();
        return user != null ? user : defaultValue;
    }
}