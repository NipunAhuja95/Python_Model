package com.ey.model.entity;

import java.time.LocalDateTime;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

@Entity
@Table(name = "dimension_maintenance")
public class DimensionMaintenance {

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "dimension_maintenance_id")
    private Long dimensionMaintenanceId;
	
	@Column(name = "dimension_table_name", unique = true)
	private String dimensionTableName;
	
	@Column(name = "dimension_type")
	private Integer dimensionType;
	
	// User-based filtering field
	@Column(name = "created_by", nullable = false)
	private String createdBy;
	
	// Timestamp fields for tracking creation and modification
	@CreationTimestamp
	@Column(name = "created_at", nullable = false, updatable = false)
	private LocalDateTime createdAt;
	
	@UpdateTimestamp
	@Column(name = "last_modified")
	private LocalDateTime lastModified;
	
	@OneToMany(mappedBy = "dimensionMaintenance")
	@JsonManagedReference
	List<DimensionMaintenanceColumns> dimensionMaintenanceColumns;

	// Getters and Setters
	public Long getDimensionMaintenanceId() {
		return dimensionMaintenanceId;
	}

	public void setDimensionMaintenanceId(Long dimensionMaintenanceId) {
		this.dimensionMaintenanceId = dimensionMaintenanceId;
	}

	public String getDimensionTableName() {
		return dimensionTableName;
	}

	public void setDimensionTableName(String dimensionTableName) {
		this.dimensionTableName = dimensionTableName;
	}

	public Integer getDimensionType() {
		return dimensionType;
	}

	public void setDimensionType(Integer dimensionType) {
		this.dimensionType = dimensionType;
	}

	public List<DimensionMaintenanceColumns> getDimensionMaintenanceColumns() {
		return dimensionMaintenanceColumns;
	}

	public void setDimensionMaintenanceColumns(List<DimensionMaintenanceColumns> dimensionMaintenanceColumns) {
		this.dimensionMaintenanceColumns = dimensionMaintenanceColumns;
	}
	
	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public LocalDateTime getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(LocalDateTime createdAt) {
		this.createdAt = createdAt;
	}

	public LocalDateTime getLastModified() {
		return lastModified;
	}

	public void setLastModified(LocalDateTime lastModified) {
		this.lastModified = lastModified;
	}
}