/*
 * package com.ey.model.service;
 * 
 * import org.springframework.ai.chat.client.ChatClient; import
 * org.springframework.stereotype.Service;
 * 
 * @Service public class LLMService {
 * 
 * private final ChatClient chatClient;
 * 
 * // ChatClient.Builder is auto-configured by the Spring AI starter on your
 * classpath public LLMService(ChatClient chatClient) { this.chatClient =
 * chatClient; }
 * 
 * 
 * public String getCompletion(String prompt) { // Simple one-shot call; works
 * with HuggingFace, Ollama, OpenAI, etc. return chatClient .prompt()
 * .user(prompt) .call() .content(); // -> String } }
 */