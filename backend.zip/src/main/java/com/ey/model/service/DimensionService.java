package com.ey.model.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.ey.model.entity.DimensionMaintenance;
import com.ey.model.entity.DimensionMaintenanceColumns;
import com.ey.model.repository.DimensionMaintenanceColumnsRepository;
import com.ey.model.repository.DimensionMaintenanceRepository;

import jakarta.persistence.EntityManager;
import jakarta.transaction.Transactional;

@Service
@Transactional
public class DimensionService {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Autowired
	private EntityManager entityManager;

	@Autowired
	private DimensionMaintenanceRepository dimensionMaintenanceRepository;

	@Autowired
	private DimensionMaintenanceColumnsRepository dimensionMaintenanceColumnsRepository;

	// ADMIN METHOD: Get all dimension details (no filtering)
	public List<DimensionMaintenance> getAllDimensionDetails() {
		return dimensionMaintenanceRepository.findAll();
	}
	
	// USER METHOD: Get dimension details for specific user
	public List<DimensionMaintenance> getDimensionDetailsByUser(String createdBy) {
		return dimensionMaintenanceRepository.findByCreatedBy(createdBy);
	}

	public DimensionMaintenance findById(Long id) {
		return dimensionMaintenanceRepository.getById(id);
	}

	public void createUploadDimensionDetails(MultipartFile file, HashMap<String, Object> columns, 
			HashMap<String, Object> data, String tableName) {
		
		// Get current authenticated user
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String currentUser = (authentication != null && authentication.isAuthenticated()) ? authentication.getName() : "system";
		
		DimensionMaintenance dimensionMaintenance = new DimensionMaintenance();
		
		dimensionMaintenance.setDimensionTableName(tableName);
		dimensionMaintenance.setDimensionType(0); // 0 upload & 2 manual
		// SET THE CREATED BY FIELD
		dimensionMaintenance.setCreatedBy(currentUser);
		dimensionMaintenanceRepository.save(dimensionMaintenance);
		
		StringBuilder createTableQuery = new StringBuilder("CREATE TABLE IF NOT EXISTS " + tableName + " (");
		StringBuilder insertTableQuery = new StringBuilder("Insert Into " + tableName + " (");
		
		// Create primary key column metadata
		DimensionMaintenanceColumns dimensionMaintenanceColumns = new DimensionMaintenanceColumns();
		
		createTableQuery.append(tableName).append("_id").append(" INT AUTO_INCREMENT , ");
		createTableQuery.append("PRIMARY KEY (").append(tableName).append("_id").append(") , ");
		
		dimensionMaintenanceColumns.setDimensionMaintenance(dimensionMaintenance);
		dimensionMaintenanceColumns.setDimensionTableName(tableName);
		dimensionMaintenanceColumns.setDimensionColumnName(tableName + "_id");
		dimensionMaintenanceColumns.setDimensionColumnDataType("INT");
		dimensionMaintenanceColumnsRepository.save(dimensionMaintenanceColumns);
		
		// Process the columns and data from the uploaded file
		if (columns != null && !columns.isEmpty()) {
			for (Map.Entry<String, Object> entry : columns.entrySet()) {
				String columnName = entry.getKey();
				String columnDataType = entry.getValue().toString();
				
				// Add column to CREATE TABLE query
				createTableQuery.append(columnName).append(" ").append(columnDataType).append(" , ");
				
				// Create column metadata record
				DimensionMaintenanceColumns columnMetadata = new DimensionMaintenanceColumns();
				columnMetadata.setDimensionMaintenance(dimensionMaintenance);
				columnMetadata.setDimensionTableName(tableName);
				columnMetadata.setDimensionColumnName(columnName);
				columnMetadata.setDimensionColumnDataType(columnDataType);
				dimensionMaintenanceColumnsRepository.save(columnMetadata);
			}
		}
		
		// Remove the last comma and space, then close the CREATE TABLE statement
		if (createTableQuery.toString().endsWith(" , ")) {
			createTableQuery.setLength(createTableQuery.length() - 3);
		}
		createTableQuery.append(")");
		
		// Execute the CREATE TABLE query
		try {
			jdbcTemplate.execute(createTableQuery.toString());
			System.out.println("Table created successfully: " + tableName);
			System.out.println("SQL: " + createTableQuery.toString());
		} catch (Exception e) {
			System.err.println("Error creating table: " + e.getMessage());
			throw new RuntimeException("Failed to create table: " + tableName, e);
		}
		
		// Process and insert data if provided
		if (data != null && !data.isEmpty()) {
			insertDataIntoTable(tableName, data);
		}
	}
	
	/**
	 * Helper method to insert data into the created table
	 */
	private void insertDataIntoTable(String tableName, HashMap<String, Object> data) {
		try {
			// This is a simplified implementation
			// You might need to adjust based on your actual data structure
			for (Map.Entry<String, Object> entry : data.entrySet()) {
				String key = entry.getKey();
				Object value = entry.getValue();
				
				// Build and execute INSERT statements based on your data structure
				// This is a placeholder - implement based on your actual data format
				System.out.println("Processing data entry: " + key + " = " + value);
			}
		} catch (Exception e) {
			System.err.println("Error inserting data into table: " + e.getMessage());
			throw new RuntimeException("Failed to insert data into table: " + tableName, e);
		}
	}
	
	// ADMIN METHOD: Get all tables with columns (no filtering)
    public Map<String, List<String>> getTablesWithColumns() {
        List<DimensionMaintenanceColumns> tableColumns = dimensionMaintenanceColumnsRepository.findAll();

        return tableColumns.stream()
                .collect(Collectors.groupingBy(
                		DimensionMaintenanceColumns::getDimensionTableName,
                        Collectors.mapping(DimensionMaintenanceColumns::getDimensionColumnName, Collectors.toList())
                ));
    }
    
    // USER METHOD: Get tables with columns for specific user
    public Map<String, List<String>> getTablesWithColumnsByUser(String createdBy) {
        List<DimensionMaintenanceColumns> tableColumns = dimensionMaintenanceColumnsRepository.findByCreatedBy(createdBy);

        return tableColumns.stream()
                .collect(Collectors.groupingBy(
                		DimensionMaintenanceColumns::getDimensionTableName,
                        Collectors.mapping(DimensionMaintenanceColumns::getDimensionColumnName, Collectors.toList())
                ));
    }
    
    /**
     * Get dimension maintenance by table name and user (with ownership check)
     */
    public DimensionMaintenance getDimensionMaintenanceByTableName(String tableName, String createdBy) {
        List<DimensionMaintenance> results = dimensionMaintenanceRepository.findByCreatedBy(createdBy);
        return results.stream()
                .filter(dm -> tableName.equals(dm.getDimensionTableName()))
                .findFirst()
                .orElse(null);
    }
    
    /**
     * Delete dimension maintenance (with ownership check)
     */
    public boolean deleteDimensionMaintenance(Long id, String currentUser) {
        DimensionMaintenance dimensionMaintenance = dimensionMaintenanceRepository.findById(id).orElse(null);
        
        if (dimensionMaintenance == null) {
            return false;
        }
        
        // Check ownership (admins can delete anything, users can only delete their own)
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        boolean isAdmin = authentication != null && 
                authentication.getAuthorities().stream()
                    .anyMatch(auth -> auth.getAuthority().equals("ROLE_ADMIN"));
        
        if (!isAdmin && !currentUser.equals(dimensionMaintenance.getCreatedBy())) {
            throw new SecurityException("User cannot delete dimension maintenance created by another user");
        }
        
        // Delete the associated table if it exists
        try {
            jdbcTemplate.execute("DROP TABLE IF EXISTS " + dimensionMaintenance.getDimensionTableName());
        } catch (Exception e) {
            System.err.println("Warning: Could not drop table " + dimensionMaintenance.getDimensionTableName() + ": " + e.getMessage());
        }
        
        // Delete the dimension maintenance record (cascade will handle columns)
        dimensionMaintenanceRepository.deleteById(id);
        return true;
    }
    
    /**
     * Create a new dimension table manually (not from file upload)
     */
    public DimensionMaintenance createManualDimensionTable(String tableName, Map<String, String> columnDefinitions) {
        // Get current authenticated user
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String currentUser = (authentication != null && authentication.isAuthenticated()) ? authentication.getName() : "system";
        
        DimensionMaintenance dimensionMaintenance = new DimensionMaintenance();
        dimensionMaintenance.setDimensionTableName(tableName);
        dimensionMaintenance.setDimensionType(2); // 2 = manual creation
        dimensionMaintenance.setCreatedBy(currentUser);
        dimensionMaintenanceRepository.save(dimensionMaintenance);
        
        // Build CREATE TABLE query
        StringBuilder createTableQuery = new StringBuilder("CREATE TABLE IF NOT EXISTS " + tableName + " (");
        
        // Add primary key
        createTableQuery.append(tableName).append("_id INT AUTO_INCREMENT PRIMARY KEY, ");
        
        // Add primary key to metadata
        DimensionMaintenanceColumns pkColumn = new DimensionMaintenanceColumns();
        pkColumn.setDimensionMaintenance(dimensionMaintenance);
        pkColumn.setDimensionTableName(tableName);
        pkColumn.setDimensionColumnName(tableName + "_id");
        pkColumn.setDimensionColumnDataType("INT");
        dimensionMaintenanceColumnsRepository.save(pkColumn);
        
        // Add other columns
        for (Map.Entry<String, String> entry : columnDefinitions.entrySet()) {
            String columnName = entry.getKey();
            String dataType = entry.getValue();
            
            createTableQuery.append(columnName).append(" ").append(dataType).append(", ");
            
            // Add to metadata
            DimensionMaintenanceColumns column = new DimensionMaintenanceColumns();
            column.setDimensionMaintenance(dimensionMaintenance);
            column.setDimensionTableName(tableName);
            column.setDimensionColumnName(columnName);
            column.setDimensionColumnDataType(dataType);
            dimensionMaintenanceColumnsRepository.save(column);
        }
        
        // Remove last comma and close statement
        if (createTableQuery.toString().endsWith(", ")) {
            createTableQuery.setLength(createTableQuery.length() - 2);
        }
        createTableQuery.append(")");
        
        // Execute CREATE TABLE
        jdbcTemplate.execute(createTableQuery.toString());
        
        return dimensionMaintenance;
    }
}