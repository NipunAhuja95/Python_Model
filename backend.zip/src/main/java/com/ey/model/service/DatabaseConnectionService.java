package com.ey.model.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ey.model.entity.DimensionMaintenance;
import com.ey.model.entity.DimensionMaintenanceColumns;
import com.ey.model.repository.DimensionMaintenanceColumnsRepository;
import com.ey.model.repository.DimensionMaintenanceRepository;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.*;

@Service
@Transactional
public class DatabaseConnectionService {

    @Autowired
    private JdbcTemplate localJdbcTemplate;

    @Autowired
    private DimensionMaintenanceRepository dimensionMaintenanceRepository;

    @Autowired
    private DimensionMaintenanceColumnsRepository dimensionMaintenanceColumnsRepository;

    private String getJdbcUrl(String dbType, String host, Integer port, String dbName) {
        switch (dbType.toLowerCase()) {
            case "mysql":
                return String.format("jdbc:mysql://%s:%d/%s?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC", 
                    host, port, dbName);
            case "postgresql":
                return String.format("jdbc:postgresql://%s:%d/%s", host, port, dbName);
            case "oracle":
                return String.format("jdbc:oracle:thin:@%s:%d:%s", host, port, dbName);
            case "mssql":
                return String.format("jdbc:sqlserver://%s:%d;databaseName=%s;trustServerCertificate=true", 
                    host, port, dbName);
            default:
                throw new IllegalArgumentException("Unsupported database type: " + dbType);
        }
    }

    private String getDriverClassName(String dbType) {
        switch (dbType.toLowerCase()) {
            case "mysql":
                return "com.mysql.cj.jdbc.Driver";
            case "postgresql":
                return "org.postgresql.Driver";
            case "oracle":
                return "oracle.jdbc.driver.OracleDriver";
            case "mssql":
                return "com.microsoft.sqlserver.jdbc.SQLServerDriver";
            default:
                throw new IllegalArgumentException("Unsupported database type: " + dbType);
        }
    }

    private Connection getConnection(String dbType, String host, Integer port, String dbName, 
                                   String username, String password) throws SQLException {
        String jdbcUrl = getJdbcUrl(dbType, host, port, dbName);
        String driverClassName = getDriverClassName(dbType);
        
        System.out.println("Attempting to connect to: " + jdbcUrl);
        System.out.println("Using driver: " + driverClassName);
        
        try {
            Class.forName(driverClassName);
        } catch (ClassNotFoundException e) {
            System.err.println("Database driver not found: " + driverClassName);
            throw new SQLException("Database driver not found: " + driverClassName + 
                ". Please make sure the driver is added to your classpath.");
        }
        
        Properties props = new Properties();
        props.setProperty("user", username);
        props.setProperty("password", password);
        
        try {
            Connection conn = DriverManager.getConnection(jdbcUrl, props);
            System.out.println("Successfully connected to database");
            return conn;
        } catch (SQLException e) {
            System.err.println("Failed to connect to database: " + e.getMessage());
            throw new SQLException("Failed to connect to database: " + e.getMessage());
        }
    }

    public Map<String, Object> executeSqlQuery(String dbType, String host, Integer port, String dbName,
                                              String username, String password, String sql, String currentUser) {
        
        Map<String, Object> result = new HashMap<>();
        List<Map<String, Object>> data = new ArrayList<>();
        
        try (Connection connection = getConnection(dbType, host, port, dbName, username, password)) {
            
            String trimmedSql = sql.trim().toLowerCase();
            
            // If it contains CREATE TABLE and INSERT statements, execute them and then query the data
            if (trimmedSql.contains("create table") && trimmedSql.contains("insert into")) {
                
                // Split SQL into individual statements
                String[] statements = sql.split(";");
                
                // Execute each statement
                for (String stmt : statements) {
                    String trimmedStmt = stmt.trim();
                    if (!trimmedStmt.isEmpty()) {
                        try (PreparedStatement ps = connection.prepareStatement(trimmedStmt)) {
                            ps.execute();
                            System.out.println("Executed for preview: " + trimmedStmt);
                        }
                    }
                }
                
                // Now query the created table to show preview
                String tableName = extractTableNameFromSQL(sql);
                String selectQuery = "SELECT * FROM " + tableName + " LIMIT 10";
                
                try (PreparedStatement statement = connection.prepareStatement(selectQuery);
                     ResultSet resultSet = statement.executeQuery()) {
                    
                    ResultSetMetaData metaData = resultSet.getMetaData();
                    int columnCount = metaData.getColumnCount();
                    
                    // Get column names
                    List<String> columnNames = new ArrayList<>();
                    for (int i = 1; i <= columnCount; i++) {
                        columnNames.add(metaData.getColumnName(i));
                    }
                    
                    // Process result rows
                    while (resultSet.next()) {
                        Map<String, Object> row = new LinkedHashMap<>();
                        for (int i = 1; i <= columnCount; i++) {
                            Object value = resultSet.getObject(i);
                            row.put(metaData.getColumnName(i), value);
                        }
                        data.add(row);
                    }
                    
                    result.put("data", data);
                    result.put("message", "SQL executed successfully - showing preview data");
                    result.put("columns", columnNames);
                }
                
            } else if (trimmedSql.startsWith("select")) {
                // Handle SELECT queries
                try (PreparedStatement statement = connection.prepareStatement(sql);
                     ResultSet resultSet = statement.executeQuery()) {
                    
                    ResultSetMetaData metaData = resultSet.getMetaData();
                    int columnCount = metaData.getColumnCount();
                    
                    // Get column names
                    List<String> columnNames = new ArrayList<>();
                    for (int i = 1; i <= columnCount; i++) {
                        columnNames.add(metaData.getColumnName(i));
                    }
                    
                    // Process result rows (limit to 100 for preview)
                    int rowCount = 0;
                    while (resultSet.next() && rowCount < 100) {
                        Map<String, Object> row = new LinkedHashMap<>();
                        for (int i = 1; i <= columnCount; i++) {
                            Object value = resultSet.getObject(i);
                            row.put(metaData.getColumnName(i), value);
                        }
                        data.add(row);
                        rowCount++;
                    }
                    
                    result.put("data", data);
                    result.put("message", "Query executed successfully");
                    result.put("columns", columnNames);
                }
                
            } else {
                result.put("error", "Please provide either SELECT queries or CREATE TABLE with INSERT statements.");
                result.put("data", Collections.emptyList());
            }
            
        } catch (SQLException e) {
            System.err.println("SQL Error: " + e.getMessage());
            result.put("error", "SQL Error: " + e.getMessage());
            result.put("data", Collections.emptyList());
        }
        
        return result;
    }

    public void transferDataToLocalTable(String dbType, String host, Integer port, String dbName,
                                       String username, String password, String sql, 
                                       String targetTableName, String currentUser) throws SQLException {
        
        Connection externalConnection = null;
        
        try {
            // Clean up existing table and metadata if it exists (for re-upload)
            try {
                localJdbcTemplate.execute("DROP TABLE IF EXISTS " + targetTableName);
                dimensionMaintenanceRepository.deleteByDimensionTableName(targetTableName);
                dimensionMaintenanceColumnsRepository.deleteByDimensionTableName(targetTableName);
                System.out.println("Cleaned up existing table: " + targetTableName);
            } catch (Exception e) {
                System.err.println("Warning during cleanup: " + e.getMessage());
            }

            // Connect to external database
            externalConnection = getConnection(dbType, host, port, dbName, username, password);
            
            // Split SQL into individual statements
            String[] statements = sql.split(";");
            
            // Execute each statement on the external database
            for (String stmt : statements) {
                String trimmedStmt = stmt.trim();
                if (!trimmedStmt.isEmpty()) {
                    try (PreparedStatement ps = externalConnection.prepareStatement(trimmedStmt)) {
                        ps.execute();
                        System.out.println("Executed: " + trimmedStmt);
                    }
                }
            }
            
            // Now query the created table to get its structure and data
            String selectQuery = "SELECT * FROM " + extractTableNameFromSQL(sql);
            
            try (PreparedStatement statement = externalConnection.prepareStatement(selectQuery);
                 ResultSet resultSet = statement.executeQuery()) {
                
                ResultSetMetaData metaData = resultSet.getMetaData();
                int columnCount = metaData.getColumnCount();
                
                // Create dimension maintenance record
                DimensionMaintenance dimensionMaintenance = new DimensionMaintenance();
                dimensionMaintenance.setDimensionTableName(targetTableName);
                dimensionMaintenance.setDimensionType(1); // 1 for SQL upload
                dimensionMaintenance.setCreatedBy(currentUser);
                dimensionMaintenanceRepository.save(dimensionMaintenance);
                
                // Build CREATE TABLE query for local database
                StringBuilder createTableQuery = new StringBuilder("CREATE TABLE IF NOT EXISTS " + targetTableName + " (");
                
                // Add auto-increment primary key
                createTableQuery.append(targetTableName).append("_id INT AUTO_INCREMENT PRIMARY KEY, ");
                
                // Save primary key column metadata
                DimensionMaintenanceColumns pkColumn = new DimensionMaintenanceColumns();
                pkColumn.setDimensionMaintenance(dimensionMaintenance);
                pkColumn.setDimensionTableName(targetTableName);
                pkColumn.setDimensionColumnName(targetTableName + "_id");
                pkColumn.setDimensionColumnDataType("INT");
                dimensionMaintenanceColumnsRepository.save(pkColumn);
                
                // Add other columns
                List<String> columnNames = new ArrayList<>();
                List<String> columnTypes = new ArrayList<>();
                
                for (int i = 1; i <= columnCount; i++) {
                    String columnName = metaData.getColumnName(i);
                    String sqlType = getSqlDataType(metaData.getColumnType(i));
                    
                    columnNames.add(columnName);
                    columnTypes.add(sqlType);
                    
                    createTableQuery.append(columnName).append(" ").append(sqlType).append(", ");
                    
                    // Save column metadata
                    DimensionMaintenanceColumns column = new DimensionMaintenanceColumns();
                    column.setDimensionMaintenance(dimensionMaintenance);
                    column.setDimensionTableName(targetTableName);
                    column.setDimensionColumnName(columnName);
                    column.setDimensionColumnDataType(sqlType);
                    dimensionMaintenanceColumnsRepository.save(column);
                }
                
                // Remove last comma and close CREATE TABLE statement
                if (createTableQuery.toString().endsWith(", ")) {
                    createTableQuery.setLength(createTableQuery.length() - 2);
                }
                createTableQuery.append(")");
                
                // Execute CREATE TABLE in local database
                localJdbcTemplate.execute(createTableQuery.toString());
                
                // Insert data into local table
                if (columnNames.size() > 0) {
                    StringBuilder insertQuery = new StringBuilder("INSERT INTO " + targetTableName + " (");
                    columnNames.forEach(col -> insertQuery.append(col).append(", "));
                    insertQuery.setLength(insertQuery.length() - 2); // Remove last comma
                    insertQuery.append(") VALUES (");
                    
                    // Add placeholders
                    for (int i = 0; i < columnNames.size(); i++) {
                        insertQuery.append("?, ");
                    }
                    insertQuery.setLength(insertQuery.length() - 2); // Remove last comma
                    insertQuery.append(")");
                    
                    // Prepare batch insert
                    List<Object[]> batchArgs = new ArrayList<>();
                    while (resultSet.next()) {
                        Object[] rowData = new Object[columnNames.size()];
                        for (int i = 0; i < columnNames.size(); i++) {
                            rowData[i] = resultSet.getObject(i + 1);
                        }
                        batchArgs.add(rowData);
                    }
                    
                    // Execute batch insert
                    if (!batchArgs.isEmpty()) {
                        localJdbcTemplate.batchUpdate(insertQuery.toString(), batchArgs);
                        System.out.println("Inserted " + batchArgs.size() + " rows into " + targetTableName);
                    }
                }
            }
            
        } finally {
            // Clean up resources
            if (externalConnection != null) {
                try { externalConnection.close(); } catch (SQLException e) { /* ignore */ }
            }
        }
    }
    
    // Helper method to extract table name from CREATE TABLE SQL
    private String extractTableNameFromSQL(String sql) {
        String lowerSql = sql.toLowerCase();
        int createIndex = lowerSql.indexOf("create table");
        if (createIndex != -1) {
            String afterCreate = sql.substring(createIndex + 12).trim();
            String[] parts = afterCreate.split("\\s+");
            if (parts.length > 0) {
                return parts[0].replaceAll("[^a-zA-Z0-9_]", "");
            }
        }
        return "unknown_table";
    }
    
    private String getSqlDataType(int sqlType) {
        switch (sqlType) {
            case Types.BIGINT:
            case Types.INTEGER:
            case Types.SMALLINT:
            case Types.TINYINT:
                return "INT";
            case Types.DECIMAL:
            case Types.NUMERIC:
            case Types.DOUBLE:
            case Types.FLOAT:
            case Types.REAL:
                return "DOUBLE";
            case Types.DATE:
                return "DATE";
            case Types.TIME:
            case Types.TIMESTAMP:
                return "TIMESTAMP";
            case Types.BOOLEAN:
            case Types.BIT:
                return "BOOLEAN";
            case Types.CHAR:
            case Types.VARCHAR:
            case Types.LONGVARCHAR:
            case Types.NCHAR:
            case Types.NVARCHAR:
            case Types.LONGNVARCHAR:
            case Types.CLOB:
            case Types.NCLOB:
            default:
                return "VARCHAR(255)";
        }
    }
}