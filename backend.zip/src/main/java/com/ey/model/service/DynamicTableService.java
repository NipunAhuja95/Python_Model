package com.ey.model.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class DynamicTableService {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    /* =====================================================
     * SECTION 1: Existing functions (used by EntityController)
     * ===================================================== */

    /**
     * Fetch paginated data from a specific table (used in EntityController)
     */
    public List<Map<String, Object>> getDataFromTable(String tableName, int page, int size) {
        // Prevent SQL injection
        if (!tableName.matches("^[a-zA-Z0-9_]+$")) {
            throw new IllegalArgumentException("Invalid table name: " + tableName);
        }

        int offset = (page - 1) * size;
        String sql = String.format("SELECT * FROM %s LIMIT %d OFFSET %d", tableName, size, offset);
        return jdbcTemplate.queryForList(sql);
    }

    /**
     * ✅ Count total rows of a table (used in EntityController)
     */
    public int getTotalRows(String tableName) {
        if (!tableName.matches("^[a-zA-Z0-9_]+$")) {
            throw new IllegalArgumentException("Invalid table name: " + tableName);
        }
        String sql = String.format("SELECT COUNT(*) FROM %s", tableName);
        return jdbcTemplate.queryForObject(sql, Integer.class);
    }

    /* =====================================================
     * SECTION 2: New Output Screen Functions (for OutputDataController)
     * ===================================================== */

    /**
     * Fetch metadata for all generated output tables.
     * Reads from final_report_metadata table.
     */
    public List<Map<String, Object>> getAllOutputMetadata() {
        String sql = """
            SELECT 
                table_name,
                run_type,
                valuation_date,
                output_run_date,
                output_run_time,
                user_id
            FROM final_report_metadata
            ORDER BY created_at DESC
        """;
        return jdbcTemplate.queryForList(sql);
    }

    /**
     * ✅ Fetch paginated output table data by table name.
     * Used in the OutputDataController popup view.
     */
    public Map<String, Object> getTableData(String tableName, int page, int size) {
        if (!tableName.matches("^[a-zA-Z0-9_]+$")) {
            throw new IllegalArgumentException("Invalid table name: " + tableName);
        }

        int offset = (page - 1) * size;
        String sql = String.format("SELECT * FROM %s LIMIT %d OFFSET %d", tableName, size, offset);
        List<Map<String, Object>> rows = jdbcTemplate.queryForList(sql);

        int totalRows = jdbcTemplate.queryForObject("SELECT COUNT(*) FROM " + tableName, Integer.class);

        Map<String, Object> result = new HashMap<>();
        result.put("columns", rows.isEmpty() ? new ArrayList<>() : new ArrayList<>(rows.get(0).keySet()));
        result.put("data", rows);
        result.put("totalRows", totalRows);

        return result;
    }
    
    public byte[] exportTableToCSV(String tableName) throws Exception {
        List<Map<String, Object>> data = getDataFromTable(tableName, 1, Integer.MAX_VALUE);
        if (data.isEmpty()) return "No data found".getBytes();

        StringBuilder csv = new StringBuilder();
        Set<String> columns = data.get(0).keySet();
        csv.append(String.join(",", columns)).append("\n");

        for (Map<String, Object> row : data) {
            csv.append(columns.stream()
                    .map(c -> row.get(c) == null ? "" : row.get(c).toString().replace(",", ""))
                    .collect(Collectors.joining(",")))
                    .append("\n");
        }

        return csv.toString().getBytes(StandardCharsets.UTF_8);
    }

}
