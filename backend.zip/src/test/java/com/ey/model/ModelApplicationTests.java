package com.ey.model;

import org.junit.jupiter.api.Test;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

@SpringBootTest
class ModelApplicationTests {
	
	@MockBean
    private ChatClient chatClient;

	@Test
	void contextLoads() {
	}

}
