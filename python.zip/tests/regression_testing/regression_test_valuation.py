# test_regression.py

import sys
import pandas as pd
from pandas.testing import assert_frame_equal
from pathlib import Path
sys.path.append(str(Path(__file__).resolve().parents[2]))

from src.executor import initialize_test_environment
from src.config import RunConfig
from src.run_type import Valuation


def test_regression():
    # Setup test directories
    test_root = Path(__file__).parent
    test_data_path = test_root / 'data'  # Points to the test data directory
    test_output_path = test_root / 'output'
    test_log_path = test_root / 'logs'
    
    # Create necessary directories
    test_output_path.mkdir(exist_ok=True)
    test_log_path.mkdir(exist_ok=True)
    
    # Create test data directory if it doesn't exist
    test_data_path.mkdir(exist_ok=True)

    # Setup test environment with test paths
    logger, table_index = initialize_test_environment(test_data_path, test_log_path)

    try:
        # Create test config dictionary
        test_config = {
            'Valuation_Date': '31-03-2024',
            'Projection_Term': 30,
            'Sensitivities_Flag': 0,
            'Reinsurance_Flag': 1,
            'Run_Type': 'Valuation',
            'Target_Profit_Margin_Pricing': 0.1,
            'Risk_Discount_Rate_Pricing': 0.12,
            'Policy_start': 1,
            'Policy_end': 9999999,
            'Products_to_run': ['BASE_TERM', 'GCL', 'RIDER_ADB', 'RIDER_CI', 'RIDER_ATPD'],
            'Output_path': str(test_output_path),
            'Output_seratim_cf_flag': 0
        }

        # Create RunConfig from dictionary - test_root is the regression test root directory
        run_config = RunConfig.from_dict(test_config, table_index, test_root)

        # Create and run instance
        run_instance = Valuation(run_config=run_config, table_index=table_index)
        run_instance.run()

        # Test outputs
        expected_dir = test_root / "expected_result"
        output_file_names = [f"{product}_Base_aggregate_output.csv" 
                            for product in run_config.products_to_run]

        for product_name, output_file_name in zip(run_config.products_to_run, output_file_names):
            expected_output = pd.read_csv(expected_dir / output_file_name)
            current_output = pd.read_csv(run_config.output_path / output_file_name)
            assert list(current_output.columns) == list(expected_output.columns), "Column mismatch"
            assert current_output.shape == expected_output.shape, "Row/column count changed"
            assert_frame_equal(current_output, expected_output, rtol=1e-6, atol=1e-8)
            logger.info(f"{product_name} regression test completed successfully.")
        
        logger.info("All regression tests completed successfully.")
    except Exception as e:
        logger.error(f"Regression test failed: {str(e)}")
        raise e

if __name__ == "__main__":
    test_regression()
