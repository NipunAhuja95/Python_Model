# src/config.py

from dataclasses import dataclass
from typing import Dict, List, Any, Optional, Union
import pandas as pd
from pathlib import Path
import yaml, json
from datetime import datetime
from src.data_access import DataSource, DataSourceFactory


@dataclass
class TableIndex:
    data_source: DataSource

    @classmethod
    def load_table_index(cls, data_source: DataSource) -> 'TableIndex':
        return cls(data_source=data_source)

    def get_file_path(self, table_name: str, root_folder: Optional[Path] = None) -> Union[str, Path]:
        return self.data_source.get_table_path(table_name)

    def read_table(self, table_name: str, **kwargs) -> pd.DataFrame:
        """Read a table with optional pandas read parameters"""
        return self.data_source.read_table(table_name, **kwargs)


@dataclass
class SensitivityConfig:
    sensitivities: pd.DataFrame

    @classmethod
    def load_sensitivities(cls, table_index: TableIndex, sensitivity_table: str) -> 'SensitivityConfig':
        df = table_index.read_table(sensitivity_table)
        return cls(sensitivities=df)

    def get_sensitivity_by_description(self, description: str) -> pd.Series:
        sensitivity_row = self.sensitivities[self.sensitivities['Sensitivity Description'] == description]
        if sensitivity_row.empty:
            raise ValueError(f"Sensitivity '{description}' not found.")
        return sensitivity_row.iloc[0]

    def get_all_sensitivities(self) -> pd.DataFrame:
        return self.sensitivities


@dataclass
class RunConfig:
    valuation_date: datetime
    projection_term: int
    sensitivities_flag: int
    reinsurance_flag: int
    run_type: str
    target_profit_margin: float
    risk_discount_rate: float
    policy_start: int
    policy_end: int
    products_to_run: List[str]
    table_index: TableIndex
    sensitivity_config: Optional[SensitivityConfig] = None
    root_folder: Optional[Path] = None
    output_path: Path = Path('./output/')
    output_seriatim_cf_flag: int = 0
    data_source_config: Dict[str, Any] = None
    created_by: Optional[str] = None

    @classmethod
    def from_json(cls, json_string: str) -> 'RunConfig':
        """Create RunConfig from JSON string"""
        try:
            config_data = json.loads(json_string)

            # Ensure we have a root folder path even for JSON/SQL config
            if 'root_folder' not in config_data:
                config_data['root_folder'] = str(Path(__file__).parent.parent)

            # Create data source from config
            data_source_config = config_data.get('data_source', {
                'source_type': 'sql',
                'root_folder': config_data['root_folder']
            })
            data_source = DataSourceFactory.create_data_source(data_source_config)
            table_index = TableIndex.load_table_index(data_source)

            return cls._create_config(config_data, table_index)
        except (json.JSONDecodeError, KeyError, ValueError) as e:
            raise ValueError(f"Error parsing JSON config: {str(e)}")

    @classmethod
    def from_dict(cls, data: Dict[str, Any], table_index: TableIndex, root_folder: Path) -> 'RunConfig':
        """Create RunConfig from a dictionary of configuration data."""
        root_folder = Path(root_folder) if isinstance(root_folder, str) else root_folder
        data['root_folder'] = str(root_folder)
        return cls._create_config(data, table_index)

    @classmethod
    def from_yaml(cls, yaml_path: Path, table_index: TableIndex) -> 'RunConfig':
        """Create RunConfig from YAML file"""
        try:
            with open(yaml_path, 'r') as file:
                config_data = yaml.safe_load(file)
            return cls._create_config(config_data, table_index)
        except (yaml.YAMLError, KeyError, ValueError) as e:
            raise ValueError(f"Error parsing YAML config: {str(e)}")

    @classmethod
    def _create_config(cls, data: Dict[str, Any], table_index: TableIndex) -> 'RunConfig':
        """Internal method to create RunConfig from dictionary data"""

        # 🔁 Step 1: Rename keys from camelCase to PascalCase
        key_map = {
            'runType': 'Run_Type',
            'valuationDate': 'Valuation_Date',
            'projectionTerm': 'Projection_Term',
            'sensitivitiesFlag': 'Sensitivities_Flag',
            'reinsuranceFlag': 'Reinsurance_Flag',
            'targetProfitMarginPricing': 'Target_Profit_Margin_Pricing',
            'riskDiscountRatePricing': 'Risk_Discount_Rate_Pricing',
            'policyStart': 'Policy_start',
            'policyEnd': 'Policy_end',
            'selectedProducts': 'Products_to_run',
            'outputSeriatimFlag': 'Output_seratim_cf_flag',
            'outputPath': 'Output_path'
        }

        for camel, pascal in key_map.items():
            if camel in data:
                data[pascal] = data.pop(camel)

        # ✅ Step 2: Ensure root_folder is always set
        if 'root_folder' not in data:
            data['root_folder'] = str(Path(__file__).parent.parent)

        root_folder = Path(data['root_folder'])

        # ✅ Step 3: Handle output_path
        output_path = Path(data.get('Output_path', './output/'))
        if not output_path.is_absolute():
            output_path = (root_folder / output_path).resolve()

        # ✅ Step 4: Handle valuation date
        val_date = data.get('Valuation_Date')
        if isinstance(val_date, str):
            try:
                valuation_date = datetime.strptime(val_date, '%Y-%m-%d')
            except ValueError:
                valuation_date = datetime.strptime(val_date, '%d-%m-%Y')
        else:
            valuation_date = datetime.now()

        # ✅ Step 5: Create sensitivity config if needed
        sensitivity_config = None
        if data.get('Sensitivities_Flag', 0) == 1:
            sensitivity_config = SensitivityConfig.load_sensitivities(
                table_index,
                'Sensitivities'
            )

        # ✅ Step 6: Create RunConfig instance
        run_config = cls(
            valuation_date=valuation_date,
            projection_term=int(data.get('Projection_Term', 0)),
            sensitivities_flag=int(data.get('Sensitivities_Flag', 0)),
            reinsurance_flag=int(data.get('Reinsurance_Flag', 0)),
            run_type=data.get('Run_Type', ''),
            target_profit_margin=float(data.get('Target_Profit_Margin_Pricing', 0.0)),
            risk_discount_rate=float(data.get('Risk_Discount_Rate_Pricing', 0.0)),
            policy_start=int(data.get('Policy_start', 1)),
            policy_end=int(data.get('Policy_end', 1)),
            products_to_run=data.get('Products_to_run', []),
            table_index=table_index,
            root_folder=root_folder,
            output_path=output_path,
            output_seriatim_cf_flag=int(data.get('Output_seratim_cf_flag', 0)),
            data_source_config=data.get('data_source'),
            sensitivity_config=sensitivity_config,
            created_by=data.get('created_by') or data.get('submitted_by')
        )

        # ✅ Step 7: Load detailed sensitivities if needed
        if run_config.sensitivities_flag == 1:
            sensitivities_table = 'Sensitivities_2024Q3'
            run_config.sensitivity_config = SensitivityConfig.load_sensitivities(
                table_index,
                sensitivities_table
            )

        return run_config


@dataclass
class ProductConfig:
    product_name: str
    variables: Dict[str, Any]

    @classmethod
    def load_product_config(cls, table_index: TableIndex, product_name: str) -> 'ProductConfig':
        df = table_index.read_table('Product_Config')
        df.set_index('Product Config Variable', inplace=True)
        df.columns = [col.strip().upper() for col in df.columns]
        product_name_upper = product_name.strip().upper()
        if product_name_upper not in df.columns:
            raise ValueError(f"Product '{product_name}' not found in product config.")
        variables = df[product_name_upper].to_dict()
        for key in variables:
            try:
                variables[key] = float(variables[key])
            except ValueError:
                pass  # Keep as string if cannot convert to float
        return cls(product_name=product_name, variables=variables)
