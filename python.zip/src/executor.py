from pathlib import Path
from typing import Optional, Tuple
from src.config import TableIndex, RunConfig
from src.logger import Logger, setup_logging, export_logs_after_run
from src.run_type import get_run_type_class
from src.data_access import DataSourceFactory
import json

def initialize_environment(root_folder: Path) -> Logger:
    """Common initialization for logging"""
    # Setup logging
    setup_logging(root_folder / 'main.log', root_folder / 'error.log')
    return Logger()

def initialize_test_environment(test_data_path: Path, log_path: Path) -> Tuple[Logger, TableIndex]:
    """Initialize environment specifically for testing
    
    Args:
        test_data_path (Path): Path to test data directory
        log_path (Path): Path where log files should be created
        
    Returns:
        Tuple[Logger, TableIndex]: Logger instance and TableIndex configured for test data
    """
    # Setup logging in test directory
    setup_logging(log_path / 'main.log', log_path / 'error.log')
    logger = Logger()
    
    # Create test data source
    data_source_config = {
        'source_type': 'csv',
        'data_folder': str(test_data_path)  # This already points to the test data directory
    }
    data_source = DataSourceFactory.create_data_source(data_source_config)
    table_index = TableIndex.load_table_index(data_source)
    
    return logger, table_index

def executor(json_config: Optional[str] = None) -> None:
    """
    Main executor function that can be called with either JSON config or use YAML file.
    """
    root_folder = Path(__file__).parent.parent
    data_folder = root_folder / 'data'
    logger = initialize_environment(root_folder)

    try:
        # Create data source and table_index before branching logic
        if json_config:
            # Parse JSON config to get database details
            config_data = json.loads(json_config)
            data_source_config = config_data.get('data_source', {})

            print("🔍 config_data received in executor:", config_data)
            print("🔍 extracted data_source_config:", data_source_config)
            data_source = DataSourceFactory.create_data_source(data_source_config)
            table_index = TableIndex.load_table_index(data_source)
            if 'created_by' not in config_data and 'submitted_by' in config_data:
                config_data['created_by'] = config_data['submitted_by']
                
            run_config = RunConfig.from_dict(config_data, table_index, root_folder)

        else:
            # For local runs, use the YAML config file
            data_source_config = {
                'source_type': 'csv',
                'data_folder': str(data_folder)
            }
            data_source = DataSourceFactory.create_data_source(data_source_config)
            table_index = TableIndex.load_table_index(data_source)
            yaml_path = table_index.get_file_path('Run_Config')
            run_config = RunConfig.from_yaml(yaml_path, table_index)

        # Get RunType class using factory function
        RunType = get_run_type_class(run_config.run_type)
        
        # Create and run an instance of the run type
        logger.info("Initializing run type instance.")
        run_instance = RunType(run_config=run_config, table_index=table_index)
        run_instance.run()

        # After all products and sensitivities complete, export logs once
        export_logs_after_run(run_config)

    except Exception as e:
        logger.error(f"ERROR in src.executor..executor: {str(e)}")
        raise
