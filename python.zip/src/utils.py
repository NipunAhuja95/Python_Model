# utils.py

import yaml
import time
import logging
from functools import wraps

def read_yaml(file_path: str):
    with open(file_path, 'r') as f:
        data = yaml.safe_load(f)
    return data

@staticmethod
def time_it(log: bool = False):
    """
    Decorator to measure the execution time of functions.
    
    Args:
        log (bool): If True, logs the execution time. If False, suppresses logging.
    
    Returns:
        Callable: Wrapped function with timing.
    """
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            start_time = time.time()
            try:
                result = func(*args, **kwargs)
            except Exception as e:
                # If an exception occurs, re-raise it after logging
                raise e
            end_time = time.time()
            elapsed_time = end_time - start_time
            if log:
                logger = logging.getLogger('main_logger')
                logger.info(f"Function '{func.__name__}' executed in {elapsed_time:.4f} seconds.")
            return result
        return wrapper
    return decorator