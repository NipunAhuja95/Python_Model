from product_type import Term, CreditLife

class ProductFactory:
    @staticmethod
    def create_product(config: ProductConfig):
        product_name = config.product_name
        if product_name == 'BaseTerm':
            return BaseTerm(config)
        elif product_name == 'TermADBRider':
            return TermADBRider(config)
        # Add other product types as needed
        else:
            raise ValueError(f"Unsupported product type: {product_name}")
        
class BaseTerm(Term):
    def __init__(self):
        super().__init__()
        # Additional attributes specific to BaseTerm

class GroupCreditLife(CreditLife)
    def __init__(self):
        super().__init__()
        # Additional attributes specific to BaseTerm
# Rider products
class TermADBRider(BaseTerm):
    def __init__(self):
        super().__init__()
        # Additional attributes for ADB Rider

class TermATPDRider(BaseTerm):
    def __init__(self):
        super().__init__()
        # Additional attributes for ATPD Rider