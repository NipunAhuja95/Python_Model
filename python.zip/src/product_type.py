from config import ProductConfig
# Product Lines/Type
class Product:
    def __init__(self, config: ProductConfig):
        self.config = config
        self.initialize_parameters()

    def initialize_parameters(self):
        # Initialize product-specific parameters
        self.product_name = self.config.product_name
        self.commission_rates = self.config.commission_rates
        self.min_policy_term = self.config.min_policy_term
        self.max_policy_term = self.config.max_policy_term
        self.reinsurance_rates = self.config.reinsurance_rates
        # Any additional initialization

class Term(Product):
    def __init__(self, config: ProductConfig):
        super().__init__(config)
        # any term specific settings

class UnitLinked(Product):
    def __init__(self):
        super().__init__(config)
        # any UL specific settings

class Par(Product):
    def __init__(self):
        super().__init__(config)
        # any Par specific settings

class Annuity(Product):
    def __init__(self):
        # any Annuity specific settings

class CreditLife(Product):
    def __init__(self):
        # any CreditLife specific settings

