# src/run_type.py

from typing import Type, Optional, Dict, Any
from pathlib import Path

from src.policy_data import Inforce
from src.base_calc_engine import CalculationEngine
from src.term_calc_engine import TermCalculationEngine
from src.rider_calc_engine import RiderCalculationEngine
from src.gcl_calc_engine import GroupCreditLifeCalculationEngine
from src.logger import Logger
from src.config import ProductConfig, RunConfig, TableIndex
from src.assumptions import (
    Mortality,
    Persistency,
    Expense,
    Commissions,
    InterestRate,
    ReinsuranceMortality,
    Morbidity,
    ReinsuranceMorbidity,
    ModalFactor,
)

engine_mapping = {
    'BASE_TERM': TermCalculationEngine,
    'RIDER_ADB': RiderCalculationEngine,
    'RIDER_CI': RiderCalculationEngine,
    'RIDER_ATPD': RiderCalculationEngine,
    'GCL': GroupCreditLifeCalculationEngine
}


def get_run_type_class(run_type_str: str) -> Type:
    run_type_str = run_type_str.lower()
    run_type_mapping = {
        'valuation': Valuation,
        'pricing': Pricing,
        'businessplanning': BusinessPlanning,
        'crnhr': CRNHR,
        'ifrs': IFRS
    }

    if run_type_str in run_type_mapping:
        return run_type_mapping[run_type_str]
    else:
        raise ValueError(f"Unknown run type specified: '{run_type_str}'")


class Valuation:
    def __init__(self, run_config: RunConfig, table_index: TableIndex):
        self.config = run_config
        self.table_index = table_index
        self.logger = Logger()
        self.assumptions = {}
        self.logger.info("Valuation initialized.")

    def load_assumptions(self, product_name: str, sensitivity_row: Optional[Dict[str, Any]] = None):
        root_folder = Path(self.config.root_folder)
        self.logger.info("Loading Mortality Assumptions.")
        self.mortality = Mortality(self.table_index, root_folder, product_name)
        self.mortality.load_data()

        self.logger.info("Loading Persistency Assumptions.")
        self.persistency = Persistency(self.table_index, root_folder, product_name)
        self.persistency.load_data()

        self.logger.info("Loading Expense Assumptions.")
        self.expense = Expense(self.table_index, root_folder, product_name)
        self.expense.load_data()

        self.logger.info("Loading Commissions Assumptions.")
        self.commissions = Commissions(self.table_index, root_folder, product_name)
        self.commissions.load_data()

        self.logger.info("Loading Interest Rate Assumptions.")
        self.interest_rate = InterestRate(self.table_index, self.config)
        self.interest_rate.load_data()

        self.logger.info("Loading Reinsurance Mortality Assumptions.")
        self.reinsurance_mortality = ReinsuranceMortality(self.table_index, root_folder, product_name)
        self.reinsurance_mortality.load_data()

        self.logger.info("Loading Modal factors")
        self.modal_factor = ModalFactor(self.table_index, root_folder, product_name)
        self.modal_factor.load_data()

        if product_name.upper() in ['RIDER_CI', 'RIDER_ADB', 'RIDER_ATPD']:
            self.logger.info("Loading Morbidity Assumptions.")
            self.morbidity = Morbidity(self.table_index, root_folder, product_name)
            self.morbidity.load_data()

            self.logger.info("Loading Reinsurance Morbidity Assumptions.")
            self.reinsurance_morbidity = ReinsuranceMorbidity(self.table_index, root_folder, product_name)
            self.reinsurance_morbidity.load_data()

            self.assumptions['morbidity'] = self.morbidity
            self.assumptions['reinsurance_morbidity'] = self.reinsurance_morbidity

        self.assumptions.update({
            'sensitivity': sensitivity_row.get('Sensitivity Description', 'Base') if sensitivity_row is not None else 'Base',
            'mortality': self.mortality,
            'persistency': self.persistency,
            'expense': self.expense,
            'commissions': self.commissions,
            'interest_rate': self.interest_rate,
            'reinsurance_mortality': self.reinsurance_mortality,
            'modal_factor': self.modal_factor
        })
        if sensitivity_row is not None:
            self.apply_sensitivity_factors(product_name, sensitivity_row)
        self.logger.info(f"Completed loading assumptions for '{product_name}'.")

    def run(self):
        try:
            if self.config.sensitivities_flag == 1 and self.config.sensitivity_config is not None:
                for _, sensitivity_row in self.config.sensitivity_config.get_all_sensitivities().iterrows():
                    sensitivity_desc = sensitivity_row.get('Sensitivity Description', 'Base')
                    self.logger.info(f"Valuation started for sensitivity: {sensitivity_desc}")
                    self.run_products_for_sensitivity(sensitivity_row)
                    self.logger.info(f"Valuation finished for sensitivity: {sensitivity_desc}.")
            else:
                sensitivity_desc = "Base"
                self.logger.info(f"Valuation started for sensitivity: {sensitivity_desc}")
                self.run_products_for_sensitivity(None)
                self.logger.info(f"Valuation finished for sensitivity: {sensitivity_desc}.")
        except Exception as e:
            self.logger.exception(f"Valuation failed: {e}")
            raise

    def run_products_for_sensitivity(self, sensitivity_row: Optional[Dict[str, Any]]):
        for product_name in self.config.products_to_run:
            desc = "Base" if sensitivity_row is None else sensitivity_row.get('Sensitivity Description', 'Base')
            self.logger.info(f"Processing product: {product_name} under sensitivity: {desc}")
            self.load_assumptions(product_name, sensitivity_row)
            inforce = Inforce(self.table_index, self.config, product_name)

            product_config = ProductConfig.load_product_config(self.table_index, product_name)
            self.config.product_name = product_name

            engine_class = engine_mapping.get(product_name.upper())
            if engine_class:
                engine_instance = engine_class(
                    inforce=inforce,
                    assumptions=self.assumptions,
                    product_config=product_config,
                    config=self.config,
                    table_index=self.table_index,
                    batch_size=5000
                )
                self.logger.info(f"Running {engine_class.__name__} for product: {product_name}.")
                engine_instance.run_valuation()
            else:
                self.logger.warning(f"No calculation engine implemented for product: {product_name}.")
            self.logger.info(f"Valuation completed for product: {product_name}.")

    def apply_sensitivity_factors(self, product_name: str, row: Dict[str, Any]):
        mort_add = float(row.get('Mortality Additive Factor', 0.0))
        mort_mult = float(row.get('Mortality Multiplicative Factor', 1.0))
        self.logger.info(f"Applying Mortality Sensitivity: add={mort_add}, mult={mort_mult}")
        self.mortality.apply_sensitivities(mort_add, mort_mult)
        self.reinsurance_mortality.apply_sensitivities(mort_add, mort_mult)

        if product_name.upper() in ['RIDER_CI', 'RIDER_ADB', 'RIDER_ATPD']:
            morb_add = float(row.get('Morbidity Additive Factor', 0.0))
            morb_mult = float(row.get('Morbidity Multiplicative Factor', 1.0))
            self.logger.info(f"Applying Morbidity Sensitivity: add={morb_add}, mult={morb_mult}")
            if hasattr(self, 'morbidity'):
                self.morbidity.apply_sensitivities(morb_add, morb_mult)
            if hasattr(self, 'reinsurance_morbidity'):
                self.reinsurance_morbidity.apply_sensitivities(morb_add, morb_mult)

        lapse_add = float(row.get('Lapse Additive Factor', 0.0))
        lapse_mult = float(row.get('Lapse Multiplicative Factor', 1.0))
        self.logger.info(f"Applying Lapse Sensitivity: add={lapse_add}, mult={lapse_mult}")
        self.persistency.apply_sensitivities(lapse_add, lapse_mult)

        exp_add = float(row.get('Expense Additive Factor', 0.0))
        exp_mult = float(row.get('Expense Multiplicative Factor', 1.0))
        self.logger.info(f"Applying Expense Sensitivity: add={exp_add}, mult={exp_mult}")
        self.expense.apply_sensitivities(exp_add, exp_mult)

        int_add = float(row.get('Interest Additive Factor', 0.0))
        int_mult = float(row.get('Interest Multiplicative Factor', 1.0))
        self.logger.info(f"Applying Interest Sensitivity: add={int_add}, mult={int_mult}")
        self.interest_rate.apply_sensitivities(int_add, int_mult)
        self.logger.info("All sensitivity factors applied successfully.")


class CRNHR(Valuation):
    def run(self):
        self.logger.info("CRNHR run started.")
        for product_name in self.config.products_to_run:
            self.logger.info(f"---CRNHR {product_name}---")
            self.load_assumptions(product_name)
            inforce = Inforce(self.table_index, self.config, product_name)
            self.config.product_name = product_name
            product_config = ProductConfig.load_product_config(self.table_index, product_name)
            engine_class = engine_mapping.get(product_name.upper())
            if engine_class:
                engine_instance = engine_class(
                    inforce=inforce,
                    assumptions=self.assumptions,
                    product_config=product_config,
                    config=self.config,
                    table_index=self.table_index,
                    batch_size=5000
                )
                self.logger.info(f"Running {engine_class.__name__} for product: {product_name}.")
                engine_instance.run_CRNHR()
            else:
                self.logger.warning(f"No calculation engine implemented for product: {product_name}.")
        self.logger.info("CRNHR run completed.")


class Pricing(Valuation):
    def __init__(self, run_config: RunConfig, table_index: TableIndex, sensitivity_row=None):
        self.config = run_config
        self.table_index = table_index
        self.logger = Logger()
        self.assumptions = {}
        self.logger.info("Pricing initialized.")

    def run(self):
        self.logger.info("Pricing run started.")
        for product_name in self.config.products_to_run:
            self.logger.info(f"---Pricing {product_name}---")
            self.load_assumptions(product_name)
            inforce = Inforce(self.table_index, self.config, product_name)
            inforce.policy_data.pricing_override()
            product_config = ProductConfig.load_product_config(self.table_index, product_name)
            self.config.product_name = product_name
            engine_class = engine_mapping.get(product_name.upper())
            if engine_class:
                engine_instance = engine_class(
                    inforce=inforce,
                    assumptions=self.assumptions,
                    product_config=product_config,
                    config=self.config,
                    table_index=self.table_index,
                    batch_size=5000
                )
                self.logger.info(f"Running {engine_class.__name__} for product: {product_name}.")
                engine_instance.run_pricing()
            else:
                self.logger.warning(f"No calculation engine implemented for product: {product_name}.")
        self.logger.info("Pricing run completed.")


class BusinessPlanning(Valuation):
    def __init__(self, run_config: RunConfig, table_index: TableIndex, sensitivity_row: Optional[Dict[str, Any]] = None):
        self.config = run_config
        self.table_index = table_index
        self.sensitivity_row = sensitivity_row
        self.assumptions = {}
        self.logger = Logger()
        self.logger.info("Bplan initialized.")

    def run(self):
        self.logger.info("Business Planning run started.")
        for product_name in self.config.products_to_run:
            self.logger.info(f"---Business Planning {product_name}---")
            self.load_assumptions(product_name)
            inforce = Inforce(self.table_index, self.config, product_name)
            product_config = ProductConfig.load_product_config(self.table_index, product_name)
            self.config.product_name = product_name
            engine_class = engine_mapping.get(product_name.upper())
            if engine_class:
                engine_instance = engine_class(
                    inforce=inforce,
                    assumptions=self.assumptions,
                    product_config=product_config,
                    config=self.config,
                    table_index=self.table_index,
                    batch_size=5000
                )
                self.logger.info(f"Running {engine_class.__name__} for product: {product_name}.")
                engine_instance.run_bplan()
            else:
                self.logger.warning(f"No calculation engine implemented for product: {product_name}.")
        self.logger.info("Business Planning process completed.")


class IFRS(Valuation):
    def __init__(self, run_config: RunConfig, table_index: TableIndex):
        super().__init__(run_config, table_index)
        self.config = run_config
        self.table_index = table_index
        self.logger = Logger()

    def run(self):
        self.logger.info("IFRS run started.")
        for product_name in self.config.products_to_run:
            self.logger.info(f"---CRNHR {product_name}---")
            self.load_assumptions(product_name)
            inforce = Inforce(self.table_index, self.config, product_name)
            self.config.product_name = product_name
            product_config = ProductConfig.load_product_config(self.table_index, product_name)
            engine_class = engine_mapping.get(product_name.upper())
            if engine_class:
                engine_instance = engine_class(
                    inforce=inforce,
                    assumptions=self.assumptions,
                    product_config=product_config,
                    config=self.config,
                    table_index=self.table_index,
                    batch_size=5000
                )
                self.logger.info(f"Running {engine_class.__name__} for product: {product_name}.")
                engine_instance.run_IFRS()
            else:
                self.logger.warning(f"No calculation engine implemented for product: {product_name}.")
        self.logger.info("IFRS run completed.")
