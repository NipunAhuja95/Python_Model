# base_calc_engine.py
import copy
import abc
import jax
import jax.numpy as jnp
from jax import jit, lax
import numpy as np
import pandas as pd
from typing import Dict, List, Any, Optional

from src.jax_config import FLOAT_DTYPE, INT_DTYPE
from src.config import TableIndex
from src.assumptions import (
    Mortality,
    Persistency,
    Expense,
    Commissions,
    InterestRate,
    ReinsuranceMortality,
    Morbidity,
    ReinsuranceMorbidity,
    IFRS17,  # Add this import
)
from src.policy_data import Inforce
from src.config import RunConfig, ProductConfig
from src.logger import Logger
from src.output import Output


class CalculationEngine(abc.ABC):
    """
    Abstract base class for calculation engines.
    """
    RIDER_TYPES = ['RIDER_CI', 'RIDER_ADB', 'RIDER_ATPD']

    def __init__(
        self,
        inforce: Inforce,
        assumptions: Dict[str, Any],
        product_config: ProductConfig,
        config: RunConfig,
        table_index: TableIndex,
        batch_size: int = 5000,
    ):
        self.inforce = inforce
        self.assumptions = assumptions
        self.product_config = product_config
        self.config = config
        self.logger = Logger()
        self.batch_size = batch_size
        self.policy_data = inforce.policy_data.data
        self.policy_numbers = inforce.policy_numbers
        self.num_policies = len(self.policy_numbers)
        self.product_name = config.product_name
        self.product = config.product_name
        self.table_index = table_index
        self.output = Output(output_path=self.config.output_path, product_name=self.product_name, sensitivity=self.assumptions['sensitivity'], config=config,table_index=self.table_index)
        self.projection_years = config.projection_term
        self.projection_months = self.projection_years * 12
        self.run_type = None
        self.sales_key = inforce.sales_key
        

    def run_valuation(self):
        self.run_type = "Valuation"
        num_batches = (self.num_policies + self.batch_size - 1) // self.batch_size
        self.logger.info(f"Starting {self.__class__.__name__} with {num_batches} batches.")

        for batch_idx in range(num_batches):
            self.logger.info(f"Processing batch {batch_idx + 1} of {num_batches}")
            start_idx = batch_idx * self.batch_size
            end_idx = min(start_idx + self.batch_size, self.num_policies)
            batch_policy_data = {k: v[start_idx:end_idx] for k, v in self.policy_data.items()}
            batch_policy_numbers = self.policy_numbers[start_idx:end_idx]

            # Run calculations for the batch
            batch_results = self.run_batch(batch_policy_data, batch_policy_numbers)
            batch_output = self.create_output_df(batch_policy_numbers, batch_results)
            self.output.store_results(batch_output)

            self.logger.info(f"Batch {batch_idx + 1} processed successfully.")

        self.output.print_output(self.inforce)
        self.logger.info(f"{self.__class__.__name__} run completed.")

    def run_pricing(self):
        self.run_type = "Pricing"
        self.logger.info(f"Starting {self.__class__.__name__}.")

        # 1. Calculate premium
        target_profit_margin = self.config.target_profit_margin
        risk_discount_rate = self.config.risk_discount_rate
        if self.product_name in self.RIDER_TYPES: 
            self.premium_fieldname = "Rider_Premium" 
        elif self.product_name == "GCL":
            self.premium_fieldname = "Premium"
        elif self.product_name == "BASE_TERM":
            self.premium_fieldname = "Premium_Amount"
        else:
            raise ValueError(f"Unknown product name: {self.product_name}")

        final_premiums = self.goal_seek_premium(target_profit_margin, risk_discount_rate)
        self.policy_data[self.premium_fieldname] = final_premiums
        
        batch_results = self.run_batch(self.policy_data, self.policy_numbers)
        batch_output = self.create_output_df(self.policy_numbers, batch_results)
        #profit_margin = self.compute_profit_margin(batch_results, risk_discount_rate)
        profit_metrics = {}
        profit_metrics['Policy_Number'] = self.policy_numbers
        profit_metrics.update(self.compute_profit_metrics(batch_results, risk_discount_rate))
        
        time_zero_df = pd.DataFrame(profit_metrics)
        
        self.output.store_results(batch_output, time_zero_df)
        self.output.print_output(self.inforce)
        self.logger.info(f"{self.__class__.__name__} run completed.")

    def margin_diff(self, premium_guess, target_margin, risk_discount_rate):
        """
        Vectorized version:
        - premium_guess: shape (num_policies,)
        - target_margin: float or shape (num_policies,) if each policy can have its own target
        - returns an array of shape (num_policies,) -> marginDiff for each policy
        """
        # 1) Overwrite all policies' premiums at once
        
        self.policy_data[self.premium_fieldname] = premium_guess  # vector shape

        # 2) Run the vectorized engine ONCE (the engine must handle all policies in parallel)
        results = self.run_batch(self.policy_data, self.policy_numbers)

        # 3) Compute profit margin for all policies: (num_policies, num_months).
        margin = self.compute_profit_margin(results, risk_discount_rate)

        # 4) Compute difference from target profit margin for all policies: (num_policies, num_months).
        diff_array = margin - target_margin  # shape (num_policies,)

        return diff_array

    def goal_seek_premium(self, target_margin, risk_discount_rate):
        
        num_policies = self.policy_data[self.premium_fieldname].shape[0]

        # shape (num_policies,)
        low_guess  = jnp.full((num_policies,), 100.0)
        high_guess = jnp.full((num_policies,), 1_000_000.0)

        f_low  = self.margin_diff(low_guess,  target_margin, risk_discount_rate)  # shape (num_policies,)
        f_high = self.margin_diff(high_guess, target_margin, risk_discount_rate)  # shape (num_policies,)

        # If we need to check bracket sign individually:
        # f_low * f_high for each policy
        sign_check = f_low * f_high
        # Possibly some logging or checks

        tolerance     = 1e-6
        max_iterations = 30

        current_low  = low_guess
        current_high = high_guess
        current_flow = f_low
        
        for i in range(max_iterations):
            mid_guess = 0.5 * (current_low + current_high)
            f_mid     = self.margin_diff(mid_guess, target_margin, risk_discount_rate)

            # We treat policies individually:
            # If f_mid[i]*f_low[i] > 0 => root is in upper half => low=mid
            # else => high=mid

            same_sign = (f_mid * current_flow) > 0  # shape (num_policies,), boolean
            # Update low for policies that have the same sign
            new_low  = jnp.where(same_sign, mid_guess, current_low)
            # Update high for policies that do not have the same sign
            new_high = jnp.where(same_sign, current_high, mid_guess)

            # Also update flow
            new_flow = jnp.where(same_sign, f_mid, current_flow)

            # Check for convergence
            # We'll define "converged" if abs(f_mid) < tolerance for each policy
            # shape (num_policies,)
            done_mask = jnp.abs(f_mid) < tolerance

            # We can short-circuit if *all* are converged:
            if jnp.all(done_mask):
                self.logger.info(f"Pricing goalseek completed in {i} iterations")
                return mid_guess

            current_low  = new_low
            current_high = new_high
            current_flow = new_flow

        
        # after max_iterations, return midpoint
        final = 0.5 * (current_low + current_high)
        self.logger.info(f"Pricing goalseek completed in {max_iterations} iterations")
        return final
    def compute_profit_metrics(self, results: Dict, risk_discount_rate: float) -> Dict:
        """
        Calculate various profit metrics:
        - profit margin
        - Average premium increase
        - Average profit per policy
        - Average decremented premium
        """

        net_profit_array = results['be_results']['net_profit_after_sm']
        premium_array    = results['be_results']['be_premiums']
        commissions = results['be_results']['be_commissions']
        initial_expense = results['be_results']['be_initial_expense']
        renewal_expense = results['be_results']['be_renewal_expenses']
        # death_benefit = results['be_results']['be_death_benefits']
        reins_premium = results['be_results']['be_reinsurance_premiums']
        reins_recovery = results['be_results']['be_reinsurance_recoveries']
        interest_on_bom_cf = results['be_results']['be_interest_on_cashflows']
        increase_in_reserves = results['be_results']['increase_in_reserves']
        interest_on_reserves = results['be_results']['interest_on_reserves']
        increase_in_solvency_capital = results['be_results']['increase_in_solvency_capital']
        interest_on_solvency_capital = results['be_results']['interest_on_solvency_capital']

        num_policies, num_months = net_profit_array.shape

        monthly_risk_rate = (1.0 + risk_discount_rate) ** (1.0/12.0) - 1.0
        t_index = jnp.arange(num_months)
        discount_factors = 1.0 / jnp.power((1.0 + monthly_risk_rate), t_index)
        # shape (1, num_months)
        df_2d = discount_factors.reshape((1, -1))

        # sum across months to get shape (num_policies,)
        npv_profit = jnp.sum(net_profit_array * df_2d, axis=1)
        npv_prem   = jnp.sum(premium_array    * df_2d, axis=1)
        npv_com   = jnp.sum(commissions       * df_2d, axis=1)
        npv_initial_expense = jnp.sum(initial_expense * df_2d, axis=1)
        npv_renewal_expense = jnp.sum(renewal_expense * df_2d, axis=1)
        # npv_death_benefit = jnp.sum(death_benefit * df_2d, axis=1)
        npv_reins_premium = jnp.sum(reins_premium * df_2d, axis=1)
        npv_reins_recovery = jnp.sum(reins_recovery * df_2d, axis=1)
        npv_interest_on_bom_cf = jnp.sum(interest_on_bom_cf * df_2d, axis=1)
        npv_increase_in_reserves = jnp.sum(increase_in_reserves * df_2d, axis=1)
        npv_interest_on_reserves = jnp.sum(interest_on_reserves * df_2d, axis=1)
        npv_increase_in_solvency_capital = jnp.sum(increase_in_solvency_capital * df_2d, axis=1)
        npv_interest_on_solvency_capital = jnp.sum(interest_on_solvency_capital * df_2d, axis=1)
        profit_margin = npv_profit / npv_prem

        results = {
            'profit_margin': profit_margin,
            'npv_profit': npv_profit,
            'npv_prem': npv_prem,
            'npv_com': npv_com,
            'npv_initial_expense': npv_initial_expense,
            'npv_renewal_expense': npv_renewal_expense,
            # 'npv_death_benefit': npv_death_benefit,
            'npv_reins_premium': npv_reins_premium,
            'npv_reins_recovery': npv_reins_recovery,
            'npv_interest_on_bom_cf': npv_interest_on_bom_cf,
            'npv_increase_in_reserves': npv_increase_in_reserves,
            'npv_interest_on_reserves': npv_interest_on_reserves,
            'npv_increase_in_solvency_capital': npv_increase_in_solvency_capital,
            'npv_interest_on_solvency_capital': npv_interest_on_solvency_capital
        }

        return results

    def compute_profit_margin(self, results: Dict, risk_discount_rate: float) -> float:
        """
        Calculate the pricing profit margin: 
        NPV of net profit / NPV of decremented premiums
        using monthly discounting at the given risk_discount_rate.
        """
        # Number of months
        net_profit_array = results['be_results']['net_profit_after_sm']
        premium_array    = results['be_results']['be_premiums']

        # 4) We want an array of margin per policy. For each policy i:
        #       margin[i] = NPV_of_profit[i] / NPV_of_prem[i]
        # so we do a per-policy discount & sum.

        num_policies, num_months = net_profit_array.shape

        monthly_risk_rate = (1.0 + risk_discount_rate) ** (1.0/12.0) - 1.0
        t_index = jnp.arange(num_months)
        discount_factors = 1.0 / jnp.power((1.0 + monthly_risk_rate), t_index)
        # shape (1, num_months)
        df_2d = discount_factors.reshape((1, -1))

        # shape (num_policies, num_months)
        discounted_profit = net_profit_array * df_2d
        discounted_prem   = premium_array    * df_2d

        # sum across months to get shape (num_policies,)
        npv_profit = jnp.sum(discounted_profit, axis=1)
        npv_prem   = jnp.sum(discounted_prem,   axis=1)

        # margin[i] = npv_profit[i] / npv_prem[i]
        margin = npv_profit / (npv_prem + 1e-14)

        return margin
    
    def compute_interest_rates(self) -> Dict[str, jnp.ndarray]:
        """
        Computes interest rates used in calculations.
        This method can be shared by different calculation engines.
        """
        rates = {}
        # Interest rates
        interest_rate = self.assumptions['interest_rate']
        # Monthly VROI rates
        monthly_vroi_rates = interest_rate.get_monthly_vroi_rates(self.projection_months)
        rates['monthly_VROI_rates'] = monthly_vroi_rates
        # Monthly ROI rates
        monthly_roi_rates = interest_rate.get_monthly_roi_rates(self.projection_months)
        rates['monthly_ROI_rates'] = monthly_roi_rates
        # Monthly CCIL rates
        monthly_ccil_rates = interest_rate.get_monthly_ccil_rates(self.projection_months)
        rates['monthly_CCIL_rates'] = monthly_ccil_rates
        return rates

    def calculate_discounted_cf(self, net_cash_flows: jnp.ndarray, interest_rates: jnp.ndarray) -> jnp.ndarray:
        """
        Calculates discounted cash flows.
        This method can be shared by different calculation engines.
        """
        num_policies, num_months = net_cash_flows.shape
        discounted_cf = jnp.zeros((num_policies, num_months + 1))
        for t in reversed(range(num_months)):
            discounted_cf = discounted_cf.at[:, t].set(
                (discounted_cf[:, t + 1] + net_cash_flows[:, t]) / (1 + interest_rates[t])
            )
        return discounted_cf[:, :-1]

    def calculate_bel(self, net_cf_mcev: jnp.ndarray, monthly_ccil_rates: jnp.ndarray) -> jnp.ndarray:
        """
        Calculates the BEL.
        This method can be shared by different calculation engines.
        """
        num_policies, num_months = net_cf_mcev.shape
        BEL = jnp.zeros((num_policies, num_months + 1))
        for t in reversed(range(num_months)):
            BEL = BEL.at[:, t].set(
                (BEL[:, t + 1] + net_cf_mcev[:, t]) / (1 + monthly_ccil_rates[t])
            )
        return BEL[:, :-1]

    def calculate_pvfp(self, net_profit_before_sm: jnp.ndarray, monthly_ccil_rates: jnp.ndarray) -> jnp.ndarray:
        """
        Calculates the PVFP.
        This method can be shared by different calculation engines.
        """
        num_policies, num_months = net_profit_before_sm.shape
        PVFP = jnp.zeros((num_policies, num_months + 1))
        for t in reversed(range(num_months)):
            PVFP = PVFP.at[:, t].set(
                (PVFP[:, t + 1] + net_profit_before_sm[:, t]) / (1 + monthly_ccil_rates[t])
            )
        return PVFP[:, :-1]

    def calculate_pv_premiums(self, premiums: jnp.ndarray, monthly_ccil_rates: jnp.ndarray) -> jnp.ndarray:
        """
        Calculates the present value of premiums.
        This method can be shared by different calculation engines.
        """
        num_policies, num_months = premiums.shape
        PV_Premiums = jnp.zeros((num_policies, num_months + 1))
        for t in reversed(range(num_months)):
            PV_Premiums = PV_Premiums.at[:, t].set(
                (PV_Premiums[:, t + 1] + premiums[:, t]) / (1 + monthly_ccil_rates[t])
            )
        return PV_Premiums[:, :-1]

    @staticmethod
    def compute_inflation_factors(policy_months: jnp.ndarray, inflation_rate: float) -> jnp.ndarray:
        """
        Computes inflation factors.
        This method can be shared by different calculation engines.
        """
        inflation_factors = (1 + inflation_rate) ** (policy_months / 12)
        return inflation_factors

    @staticmethod
    def compute_maturity_indicator(policy_months: jnp.ndarray, policy_terms_months: jnp.ndarray) -> jnp.ndarray:
        """
        Computes an indicator for maturity.
        This method can be shared by different calculation engines.
        """
        is_maturity = (policy_months == policy_terms_months).astype(FLOAT_DTYPE)
        return is_maturity
    
    def run_bplan(self):
        self.run_type = "BusinessPlanning"
        num_batches = (self.num_policies + self.batch_size - 1) // self.batch_size
        self.logger.info(f"Starting {self.__class__.__name__} with {num_batches} batches.")

        for batch_idx in range(num_batches):
            self.logger.info(f"Processing batch {batch_idx + 1} of {num_batches}")
            start_idx = batch_idx * self.batch_size
            end_idx = min(start_idx + self.batch_size, self.num_policies)
            batch_policy_data = {k: v[start_idx:end_idx] for k, v in self.policy_data.items()}
            batch_policy_numbers = self.policy_numbers[start_idx:end_idx]

            # Run calculations for the batch
            batch_results = self.run_batch(batch_policy_data, batch_policy_numbers)
            batch_output = self.create_bplan_output_df(batch_policy_numbers, batch_results, self.sales_key)
            self.output.store_results(batch_output)
    
            self.logger.info(f"Batch {batch_idx + 1} processed successfully.")

        bplan_df = self.output.return_bplan_output()
        bplan_df = self.bplan_cross_mult(bplan_df)
        bplan_df = self.bplan_sales_month_agg(bplan_df)
        self.output.print_bplan_output(bplan_df)
        self.logger.info(f"{self.__class__.__name__} run completed.")

    def bplan_cross_mult(self, df):
        df['Investment Income'] = df['interest_on_reserves'] + df['be_interest_on_cashflows']
        old_column_list = ['be_premiums','be_reinsurance_premiums','Investment Income','be_commissions','be_initial_expense','be_renewal_expenses',
                           'be_death_benefits','be_surrender_benefits','increase_in_reserves','required_solvency_capital']
        new_columns_list = ['Total Premium','Reinsurance Premium','Investment Income','Total Commission','Initial Expenses','Renewal Expenses',
                            'Death Benefit','Surrender Benefit','Change in Reserve','Required Solvency Margin']
        if self.config.product_name in ['RIDER_ADB','RIDER_CI','RIDER_ATPD']:
            old_column_list.remove('be_death_benefits')
            new_columns_list.remove('Death Benefit')
        if self.config.product_name == 'RIDER_ADB':
            old_column_list.insert(6,'be_adb_benefit')
            new_columns_list.insert(6,'ADB Benefit')
        elif self.config.product_name == 'RIDER_CI':
            old_column_list.insert(6,'be_ci_benefit')
            new_columns_list.insert(6,'CI Benefit')
            old_column_list.insert(7,'be_wop_benefit')
            new_columns_list.insert(7,'WOP Benefit')
        elif self.config.product_name == 'RIDER_ATPD':
            old_column_list.insert(6,'be_tpd_benefit')
            new_columns_list.insert(6,'TPD Benefit')
            old_column_list.insert(7,'be_wop_benefit')
            new_columns_list.insert(7,'WOP Benefit')
        df[new_columns_list] = df[old_column_list].mul(df['Number_of_policies'], axis=0)
        return df
    
    def bplan_sales_month_agg(self, df):
        df['nb_ind'] = df['Projection_Step'] == 1
        df['ren_ind'] =df['Projection_Step'] > 1
        df['New Business Premium'] = df['Total Premium'] * df['nb_ind']
        df['Renewal Premium'] = df['Total Premium'] * df['ren_ind']
        df['Initial Commission'] = df['Total Commission'] * df['nb_ind']
        df['Renewal Commission'] = df['Total Commission'] * df['ren_ind']
        df['Financial_Year'] = df['Financial_Year'].astype(str)
        df['Total Income'] = df['Total Premium'] + df['Investment Income'] - df['Reinsurance Premium']
        if self.config.product_name == 'RIDER_ADB':
            df['Total Benefit Payout'] = df['ADB Benefit'] + df['Surrender Benefit'] 
        elif self.config.product_name == 'RIDER_CI':
            df['Total Benefit Payout'] = df['CI Benefit'] + df['Surrender Benefit'] + df['WOP Benefit']
        elif self.config.product_name == 'RIDER_ATPD':
            df['Total Benefit Payout'] = df['TPD Benefit'] + df['Surrender Benefit'] + df['WOP Benefit']
        else:
            df['Total Benefit Payout'] = df['Death Benefit'] + df['Surrender Benefit'] 
        df['Total Outgo'] = df['Total Benefit Payout'] + df['Change in Reserve'] + df['Total Commission'] + df['Initial Expenses'] + df['Renewal Expenses']
        df['Profit Before Tax'] = df['Total Income'] - df['Total Outgo']
        df['Tax'] = 0
        df['Profit After Tax'] = df['Profit Before Tax'] - df['Tax']
        cashflow_vars = ['New Business Premium','Renewal Premium','Total Premium','Reinsurance Premium','Total Income','Investment Income',
                         'Initial Commission','Renewal Commission','Total Commission','Initial Expenses','Renewal Expenses','Death Benefit',
                         'Surrender Benefit','Total Benefit Payout','Change in Reserve','Required Solvency Margin','Total Outgo','Profit Before Tax',
                         'Tax','Profit After Tax']
        if self.config.product_name in ['RIDER_ADB','RIDER_CI','RIDER_ATPD']:
            cashflow_vars.remove('Death Benefit')
        if self.config.product_name == 'RIDER_ADB':
            cashflow_vars.insert(6,'ADB Benefit')
        elif self.config.product_name == 'RIDER_CI':
            cashflow_vars.insert(6,'CI Benefit')
            cashflow_vars.insert(7,'WOP Benefit')
        elif self.config.product_name == 'RIDER_ATPD':
            cashflow_vars.insert(6,'TPD Benefit')
            cashflow_vars.insert(7,'WOP Benefit')
        
        aggregate_sales_month_df = df.groupby(['Projection_Step','Sales_Key','Calendar_Month','Financial_Year'])[cashflow_vars].sum().reset_index()
        aggregate_fy_df = aggregate_sales_month_df.groupby(['Financial_Year','Calendar_Month'])[cashflow_vars].sum().reset_index()
        aggregate_fy_df = aggregate_fy_df.T
        aggregate_fy_df = aggregate_fy_df.reset_index()
        aggregate_fy_df.rename(columns={'index': 'Particulars'}, inplace=True)
        return aggregate_fy_df

    def run_CRNHR(self):
        """
        Runs the CRNHR process for the entire product in one go:
         1) Load and parse CRNHR sensitivity table
         2) Perform a 'base' run (store BEL_PP, etc.)
         3) For each CRNHR scenario, override assumptions, run, store BEL_PP, etc.
         4) Compute CRNHR capital using the scenario results
         5) Export results
        """
        self.run_type = "CRNHR"
        self.logger.info(f"Starting CRNHR run in {self.__class__.__name__}.")

        # 1) read CRNHR sensitivity table
        if self.product_name =='RIDER_ADB':
            table_name = "Sensitivity_Table_CRNHR_ADB"
        elif self.product_name in ['RIDER_CI','RIDER_ATPD']:
            table_name = "Sensitivity_Table_CRNHR_CI_ATPD"
        else:
            table_name = "Sensitivity_Table_CRNHR_Term_GCL"
        crnhr_sens_df = self.table_index.read_table(table_name)  # DataFrame with scenario rows

        # 2) base run
        self.logger.info("Running base scenario for CRNHR.")
        base_results = self.run_batch(self.policy_data, self.policy_numbers)
        self.base_assumptions = copy.deepcopy(self.assumptions)
        
        # 3) loop over each scenario in CRNHR table
        scenario_results = {}
        for _, row in crnhr_sens_df.iterrows():
            scenario_name = row['Sensitivity Description']
            
            # Skip Morbidity scenarios for non-rider products
            if scenario_name == "Morbidity" and self.product_name not in self.RIDER_TYPES:
                self.logger.info(f"Skipping CRNHR scenario: {scenario_name} for non-rider product {self.product_name}")
                continue
            
            self.logger.info(f"Running CRNHR scenario: {scenario_name}")
            # run scenario
            bel_scenario = self._run_crnhr_scenario(row, scenario_label=scenario_name)
            scenario_results[scenario_name] = bel_scenario

        # 4) compute CRNHR capital using stored base + scenario results
        crnhr_output = self._compute_crnhr_capital(
            base_results=base_results,
            scenario_results=scenario_results
        )
        batch_output = self.create_output_df(self.policy_numbers, base_results)
        
        # 5) store or export final CRNHR outputs
        self._export_crnhr_results(crnhr_output, batch_output)
        self.output.print_output(self.inforce)

        self.logger.info(f"CRNHR run completed in {self.__class__.__name__}.")

    #def compute_ifrs_var(self, base_results: Dict[str, Any], scenario_results: Dict[str, Any], crnhr_output) -> Dict[str, Any]:
        """
        Computes IFRS 17 variables for the product.
        """
        #BEL_PP_onerou= base_results['pv_results']['bel_pp']+crnhr_output['pv_CRNHR']

        #return BEL

    def _run_crnhr_scenario(self, sensitivity_row: Optional[Dict[str, Any]], scenario_label:str):
        """
        1) If sensitivity_row is not None, apply scenario assumption overwrites
        2) run 'Valuation' style approach (since we want BEL, etc.)
        3) extract BEL_PP (and anything else needed)
        4) revert assumptions if needed
        5) return scenario results in a dictionary
        """
        self.assumptions = copy.deepcopy(self.base_assumptions)
        # If we do want to override assumptions
        if sensitivity_row is not None:
            self.apply_crnhr_sensitivities(sensitivity_row)

        # do a run_valuation or partial run => gather results
        scenario_results = self.run_batch(self.policy_data, self.policy_numbers)

        if self.run_type != "IFRS":
            return scenario_results['pv_results']['bel_pp']
        else:
            return scenario_results['pv_results']['ifrs_bel_pp']

    def apply_crnhr_sensitivities(self, row: Dict[str, Any]):

        """
        Overwrite assumptions for CRNHR scenario, 
        e.g. row['Mortality_Multiplicative_Factor'], etc.
        """
        mort_add = float(row.get('Mortality_Additive_Factor', 0.0))
        mort_mult = float(row.get('Mortality_Multiplicative_Factor', 1.0))
        
        self.assumptions['mortality'].mortality_table += mort_add
        self.assumptions['mortality'].mortality_table *= mort_mult

        if self.product_name in ['BASE_TERM','GCL']:
            self.assumptions['reinsurance_mortality'].mortality_table = self.assumptions['reinsurance_mortality'].mortality_table + 0
            self.assumptions['reinsurance_mortality'].mortality_table = self.assumptions['reinsurance_mortality'].mortality_table * 1
        else:
            self.assumptions['reinsurance_mortality'].mortality_table = self.assumptions['reinsurance_mortality'].mortality_table + mort_add
            self.assumptions['reinsurance_mortality'].mortality_table = self.assumptions['reinsurance_mortality'].mortality_table * mort_mult

        lapse_add = float(row.get('Lapse_Additive_Factor', 0.0))
        lapse_mult = float(row.get('Lapse_Multiplicative_Factor', 1.0))

        self.assumptions['persistency'].lapse_rates += lapse_add
        self.assumptions['persistency'].lapse_rates *= lapse_mult

        if self.product_name in self.RIDER_TYPES:
            morb_add = float(row.get('Morbidity_Additive_Factor', 0.0))
            morb_mult = float(row.get('Morbidity_Multiplicative_Factor', 1.0))

            if self.product_name == 'RIDER_ADB':
                morb_add = float(row.get('Mortality_Additive_Factor', 0.0))
                morb_mult = float(row.get('Mortality_Multiplicative_Factor', 1.0))

            self.assumptions['morbidity'].morbidity_table += morb_add
            self.assumptions['morbidity'].morbidity_table *= morb_mult
            self.assumptions['reinsurance_morbidity'].morbidity_table += 0.0
            self.assumptions['reinsurance_morbidity'].morbidity_table *= 1.0


    def _compute_crnhr_capital(
        self,
        base_results: Dict[str, Any],
        scenario_results: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Computes CRNHR capital components using base and scenario results.
        Returns a dictionary with capital breakdowns and final present value.

        Steps:
        1) Gather base arrays (BEL, surrender benefits, inforce probabilities, sum assured, etc.).
        2) Retrieve scenario BEL arrays for each relevant shock.
        3) Calculate risk capitals (mortality, morbidity, lapse, catastrophe, expense).
        4) Sum and apply correlation matrix for diversified capital.
        5) Add operational risk, compute economic capital.
        6) Calculate and discount cost of economic capital to get PV of CRNHR.
        """
        if self.run_type != "IFRS":
            bel_pp_base = jnp.nan_to_num(base_results['pv_results']['bel_pp'], nan=0.0)
        else:
            bel_pp_base = jnp.nan_to_num(base_results['pv_results']['ifrs_bel_pp'], nan=0.0)
            
        decrements = base_results['decrements_BE']
        prob_inforce = decrements['lives_so_end']
        # Check if the product is a rider that models morbidity
        if self.product_name.upper() in self.RIDER_TYPES:
            maturities = decrements['maturities']
            rider_option = base_results['policy_attrs']['rider_option']
            if jnp.all(rider_option == 2):
                prob_inforce += maturities + decrements['net_cumulative_critical_illness']
            elif jnp.all(rider_option == 1):
                prob_inforce += maturities
            else:
                prob_inforce += maturities + decrements['net_cumulative_disability']
        
        surrender_benefits_base = base_results['be_results']['be_surrender_benefits']
        sum_assured = base_results['policy_attrs']['sum_assureds']
        reins_sum_assured = base_results['reinsurance_results']['reins_sum_assured']

        bel_pp_mort = jnp.nan_to_num(scenario_results.get('Mortality', bel_pp_base),nan=0.0)
        bel_pp_lapse_up = jnp.nan_to_num(scenario_results.get('Lapse Up', bel_pp_base), nan=0.0)
        bel_pp_lapse_down = jnp.nan_to_num(scenario_results.get('Lapse Down', bel_pp_base), nan=0.0)
        if self.product_name.upper() in self.RIDER_TYPES:
            bel_pp_morb = jnp.nan_to_num(scenario_results.get('Morbidity', bel_pp_base), nan=0.0)

        mortality_rc = jnp.maximum(bel_pp_mort - bel_pp_base, 0.0) * prob_inforce
        if self.product_name.upper() in self.RIDER_TYPES: 
            morbidity_rc = jnp.maximum(bel_pp_morb - bel_pp_base, 0.0) * prob_inforce
        lapse_up_rc = jnp.maximum(bel_pp_lapse_up - bel_pp_base, 0.0) * prob_inforce
        lapse_down_rc = jnp.maximum(bel_pp_lapse_down - bel_pp_base, 0.0) * prob_inforce
        mass_lapse_rc = jnp.maximum(surrender_benefits_base - bel_pp_base, 0.0) * 0.4 * prob_inforce
        lapse_rc = jnp.maximum(jnp.maximum(lapse_up_rc, lapse_down_rc), mass_lapse_rc)

        cat_factor = 0.0015
        if self.product_name in ['RIDER_ADB', 'BASE_TERM', 'GCL']:
            if self.run_type != "IFRS":
                cat_rc = cat_factor * jnp.maximum(sum_assured - reins_sum_assured - bel_pp_base, 0.0) * prob_inforce
                #print("Calculating cat_rc for non-IFRS run")
            else:
                cat_rc = cat_factor * jnp.maximum(sum_assured - bel_pp_base, 0.0) * prob_inforce
                #print("Calculating cat_rc for IFRS run")
        else:
            cat_rc = cat_factor * jnp.maximum((sum_assured - reins_sum_assured)*0 - bel_pp_base, 0.0) * prob_inforce
            
        self._compute_annuity_factors(base_results)
        annuity_factor_base = base_results['ann_factors']['annuity_factor_base']
        annuity_factor_stress = base_results['ann_factors']['annuity_factor_stress']
        # renewal_expenses_value = jnp.array(100.0, dtype=FLOAT_DTYPE)
        if self.product_name.upper() in self.RIDER_TYPES: 
            premiums = self.policy_data['Rider_Premium'][:, None]  # Shape: (num_policies, 1)
        elif self.product_name.upper()=='BASE_TERM':
            premiums = self.policy_data['Premium_Amount'][:, None]  # Shape: (num_policies, 1)
        else:
            premiums = self.policy_data['Premium'][:, None]  # Shape: (num_policies, 1)
        premiums = jnp.tile(premiums, (1, self.projection_months))
        Inflation_Factor = float(self.product_config.variables.get('Inflation', 0.0))
        renewal_expenses = self.assumptions['expense'].get_renewal_expense_rates()
        fixed_expense_rate = renewal_expenses.get('Fixed expenses', 0.0)  # scalar
        percent_prem_expense_rate = renewal_expenses.get('% of Prem', 0.0) / 100.0 
        renewal_expenses_value = ((fixed_expense_rate + percent_prem_expense_rate * premiums)/12) * (1 + Inflation_Factor) ** ((base_results['policy_attrs']['projection_steps'] - 1)/12) 
        expense_cap = renewal_expenses_value * (annuity_factor_stress - annuity_factor_base) * prob_inforce
        if self.run_type != "IFRS":
            expense_rc = expense_cap
        else:
            expense_rc = base_results['pv_results']['ifrs_expense_capital']
            
        # Sum each capital over policies before correlation
        if self.product_name.upper() in self.RIDER_TYPES: 
            monthly_capital_stack = jnp.stack(
                [lapse_rc, mortality_rc, morbidity_rc, expense_rc, cat_rc],
                axis=-1
            )
        else:
            monthly_capital_stack = jnp.stack(
                [lapse_rc, mortality_rc, expense_rc, cat_rc],
                axis=-1
            )
        corr_df = self.table_index.read_table("Correlation_Matrix_CRNHR", index_col=0)
        if self.product_name.upper() not in self.RIDER_TYPES:
            corr_df = corr_df.drop(index='Morbidity', columns='Morbidity')
        corr_matrix = jnp.array(corr_df.values, dtype=FLOAT_DTYPE)

        def single_diversified_capital(risk_vec: jnp.ndarray) -> jnp.ndarray:
            # risk_vec shape (5,)
            # tmp = risk_vec^T corr risk_vec
            val = risk_vec @ corr_matrix @ risk_vec
            return jnp.sqrt(val)

        diversified_caps = jax.vmap(
            lambda capital_for_policy: jax.vmap(single_diversified_capital)(capital_for_policy)
        )(monthly_capital_stack)

        opRiskChargeEP = float(self.product_config.variables.get('Operational Risk Charge - Earned Premium', 0.04))
        opRiskChargeTP = float(self.product_config.variables.get('Operational risk charge - Technical provisions', 0.0045))
        be_premiums = base_results['be_results']['be_premiums']  # shape (num_policies, num_months)

        num_months = be_premiums.shape[1]
        window_size = 12

        def rolling_12_months_for_one_policy(prem_for_policy: jnp.ndarray) -> jnp.ndarray:
            """
            Given a single policy's monthly premiums: shape (num_months,)
            Returns a rolling 12-month sum array: same shape (num_months,).
            """
            rolling_sum = jnp.zeros_like(prem_for_policy)
            for t in range(num_months):
                start_idx = jnp.maximum(t - (window_size - 1), 0)
                rolling_sum = rolling_sum.at[t].set(
                    jnp.sum(prem_for_policy[start_idx : t + 1])
                )
            return rolling_sum

        # Vectorize across policies:
        rolling_prem_12 = jax.vmap(rolling_12_months_for_one_policy)(be_premiums)
        
        if self.run_type != "IFRS":
            bel_base = jnp.nan_to_num(base_results['pv_results']['bel'], nan=0.0)
        else:
            bel_base = jnp.nan_to_num(base_results['pv_results']['ifrs_bel'], nan=0.0)
            
        op_risk_monthly = jnp.maximum(opRiskChargeEP * rolling_prem_12, opRiskChargeTP * jnp.maximum(0.0, -bel_base))

        if self.product_name.upper() in self.RIDER_TYPES:
            sum_risk_capital = lapse_rc + mortality_rc + morbidity_rc + expense_rc + cat_rc
        else:
            sum_risk_capital = lapse_rc + mortality_rc + expense_rc + cat_rc
        factor70pct = 0.70
        ec_temp = jnp.maximum(factor70pct * sum_risk_capital, diversified_caps)

        coc_charge = float(self.product_config.variables.get('Cost of Capital Charge', 0.04))
        tax_rate = float(self.product_config.variables.get('Tax Rate', 0.1456))
        csr_rate = float(self.product_config.variables.get('CSR', 0.02))
            

        if self.run_type != "IFRS":
            economic_capital_monthly = ec_temp + op_risk_monthly
            monthly_factor = coc_charge * (1.0 - tax_rate) * (1.0 - csr_rate) / 12.0
            cost_of_ec_monthly = economic_capital_monthly * monthly_factor

        else:
            economic_capital_monthly = ec_temp
            monthly_factor = coc_charge / 12.0
            cost_of_ec_monthly = economic_capital_monthly * monthly_factor
            
        # Instantiate the IFRS17 class and load the data
        ifrs17_init = IFRS17(self.table_index, self.config,self.product_name)
        ifrs17_init.load_data()

        #starting_policy_month = base_results['policy_attrs']['policy_months'].min()  # Assuming policy_months is a 2D array
        starting_policy_month = base_results['policy_attrs']['policy_months']
        # Access the IFRS ROI rates
        ifrs_current_rate = ifrs17_init.get_monthly_rates('if17_Current_ROI')
        ifrs_locked_in_rate = ifrs17_init.get_monthly_rates('if17_Locked_in_Rate')
        ifrs_ccil_rate_raw = ifrs17_init.get_monthly_rates('if17_CCIL Fwd Rates')
        
        num_policies, projection_months = starting_policy_month.shape
        ifrs_ccil_rate_list = []
        for i in range(num_policies):
            # Take the first month for each policy (e.g. starting_policy_month[i, 0])
            start_month = int(starting_policy_month[i, 0])  # assuming all cols are same start for that policy

            # Start from start_month, shift by 1 (add 0 in front), remove last
            rate_slice = ifrs_ccil_rate_raw[start_month:]
            shifted = np.concatenate([np.zeros(1), rate_slice[:-1]])

            # Pad to match projection length
            if len(shifted) < projection_months:
                shifted = np.concatenate([shifted, np.zeros(projection_months - len(shifted))])
            elif len(shifted) > projection_months:
                shifted = shifted[:projection_months]

            # Add to list
            ifrs_ccil_rate_list.append(shifted)
        
        ifrs_ccil_rate = ifrs_ccil_rate_list[0]
        ifrs_ccil_rate_array = np.array(ifrs_ccil_rate_list)

        for policy_idx in range(num_policies):
            # DYNAMICALLY select the correct rate array for the CURRENT policy
            ifrs_ccil_rate = ifrs_ccil_rate_array[policy_idx]
            # Reverse the rates for the current policy
            ccil_discount_rates_rev = ifrs_ccil_rate[::-1]


        if self.run_type != "IFRS":
            monthly_CCIL_rates_raw = self.assumptions['interest_rate'].get_monthly_rates('CCIL')  # For MCEV calculations
        else:
            monthly_CCIL_rates_raw = ifrs_ccil_rate
        
        monthly_CCIL_rates = np.zeros_like(monthly_CCIL_rates_raw)
        monthly_CCIL_rates = monthly_CCIL_rates_raw

        if self.run_type != "IFRS":
            monthly_interest_rates_rev = monthly_CCIL_rates[::-1] # Shape: (num_months,)
        else:
             monthly_interest_rates_rev = np.zeros_like(ifrs_ccil_rate_array)
             for policy_idx in range(num_policies):
                # DYNAMICALLY select the correct rate array for the CURRENT policy
                ifrs_ccil_rate = ifrs_ccil_rate_array[policy_idx]
                # Reverse the rates for the current policy
                monthly_interest_rates_rev[policy_idx] = ifrs_ccil_rate[::-1]
        
        def discount_policy_cashflows(cash_flow_rev,monthly_interest_rates_rev):
            def discount_step(carry, inputs):
                discount_rate, net_cf = inputs
                pv_next = carry
                pv = (pv_next + net_cf) / (1 + discount_rate)
                return pv, pv

            init_carry = 0.0

            _, discounted_rev = lax.scan(
                discount_step,
                init_carry,
                (monthly_interest_rates_rev, cash_flow_rev)
            )

            return discounted_rev

        # PVFP

        if self.run_type == "IFRS":
            cost_of_ec_monthly_rev = cost_of_ec_monthly[:, ::-1]  # Shape: (num_policies, num_months)
        else:
            cost_of_ec_monthly_rev = economic_capital_monthly[:, ::-1]
            
        cost_of_ec_monthly_rev = jnp.nan_to_num(cost_of_ec_monthly_rev, nan=0.0)
        disc_ec_rev = jax.vmap(discount_policy_cashflows)(cost_of_ec_monthly_rev,monthly_interest_rates_rev)
        disc_ec = disc_ec_rev[:, ::-1]
        pv_crnhr = jnp.concatenate([disc_ec[:, 1:], jnp.zeros((disc_ec.shape[0], 1))], axis=1)

        crnhr_output = {
            "mortality_rc": mortality_rc,
            "lapse_up_rc": lapse_up_rc,
            "lapse_down_rc": lapse_down_rc,
            "mass_lapse_rc": mass_lapse_rc,
            "lapse_rc": lapse_rc,
            "cat_rc": cat_rc,
            "expense_rc": expense_rc,
            "diversified_caps": diversified_caps,
            "operational_risk_monthly": op_risk_monthly,
            "economic_capital_monthly": economic_capital_monthly,
            "cost_of_ec_monthly": cost_of_ec_monthly,
            "pv_crnhr": pv_crnhr
        }

        if self.product_name.upper() in self.RIDER_TYPES:
            crnhr_output["morbidity_rc"] = morbidity_rc

        return crnhr_output

    def _export_crnhr_results(self, crnhr_output: Dict, batch_output: Dict):
        """
        Writes final CRNHR results to the output class for subsequent CSV exports.
        """
        self.logger.info("Exporting CRNHR results.")

        # Prefix the keys so we don't collide with other variables in 'self.output'.
        for key, value in crnhr_output.items():
            batch_output[f"crnhr_{key}"] = np.array(value).flatten()
        # pass None as the second argument to store_results.
        self.output.store_results(batch_output, time_zero_data=None)

    def _compute_annuity_factors(self, base_results: Dict[str, jnp.ndarray]):
        """
        Computes and returns annuity factors under base and stress discount rates for CRNHR.
        """
        policy_attrs = base_results['policy_attrs']
        num_policies = policy_attrs['num_policies']
        num_months   = self.projection_months
        decrements = base_results['decrements_BE']
        
        # Extract the monthly interest rate for CRNHR from product config
        # and also any inflation or stress adjustments.
        annual_int_for_expenses = float(self.product_config.variables.get('Interest Rate to calculate PV of expenses in CRNHR', 0.075))
        annual_inflation = float(self.product_config.variables.get('Inflation', 0.05))
        annual_inflation_stress_shock = float(self.product_config.variables.get('CRNHR Expense Inflation Stress', 0.01))
        annual_inflation_stress = annual_inflation + annual_inflation_stress_shock  # if you are applying +1% for stress

        # Convert to monthly
        monthly_expense_rate   = (1.0 + annual_int_for_expenses) ** (1.0 / 12.0) - 1.0
        monthly_infl_base      = (1.0 + annual_inflation)   ** (1.0 / 12.0) - 1.0
        monthly_infl_stress    = (1.0 + annual_inflation_stress) ** (1.0 / 12.0) - 1.0

        # CRNHR discount rates = (1 + expense_rate)/(1 + inflation_rate) - 1
        monthly_dr_base   = (1.0 + monthly_expense_rate) / (1.0 + monthly_infl_base)   - 1.0
        monthly_dr_stress = (1.0 + monthly_expense_rate) / (1.0 + monthly_infl_stress) - 1.

        # Build discount-factor arrays: shape (num_months,) for base & stress
        t_index     = jnp.arange(num_months)  # [0..num_months-1]
        df_base     = 1.0 / jnp.power(1.0 + monthly_dr_base,   t_index)
        df_stress   = 1.0 / jnp.power(1.0 + monthly_dr_stress, t_index)

        lives_begin = decrements.get('lives_so_begin', None)
        
        # Check if the product is a rider that models morbidity
        if self.product_name.upper() in self.RIDER_TYPES:
            rider_option = policy_attrs['rider_option']
            if jnp.all(rider_option ==2):
                adjusted_px = lives_begin + decrements['net_cumulative_critical_illness']
            elif jnp.all(rider_option ==1):
                adjusted_px = lives_begin
            else:
                adjusted_px = lives_begin + decrements['net_cumulative_disability']
        else:
            # Non-morbidity products
            adjusted_px = lives_begin

        # Function to compute the annuity-factor “vector” for one policy
        # e.g. a reversed cumulative sum of (adjusted_px * discount_factors).
        def annuity_factor_for_one_policy(px_for_policy: jnp.ndarray, df: jnp.ndarray) -> jnp.ndarray:
            # rev_mult = px_for_policy[::-1] * df[::-1]
            # ann_vect_rev = jnp.cumsum(rev_mult, axis=0)
            # ann_vect     = ann_vect_rev[::-1]
            # return ann_vect  # shape (num_months,)
    
            rev_mult = px_for_policy[::-1] * df[::-1]      # shape (num_months,)
            rev_cumsum    = jnp.cumsum(rev_mult, axis=0) # partial sums in reverse
            partial_sums  = rev_cumsum[::-1]                  # shape (num_months,)

            return partial_sums / (df*px_for_policy)

        # Vectorize across all policies using jax.vmap
        ann_factors_base = jax.vmap(lambda px: annuity_factor_for_one_policy(px, df_base))(adjusted_px)
        # ann_factors_base = jax.vmap(annuity_factor_for_one_policy(adjusted_px, df_base))

        exp_stress = float(self.product_config.variables.get('CRNHR Expense Sensitivity', 0.0))

        ann_factors_stress = jax.vmap(lambda px: annuity_factor_for_one_policy(px, df_stress))(adjusted_px)
        ann_factors_stress = ann_factors_stress*exp_stress

        # Store them so your CRNHR code can read them
        base_results.setdefault('ann_factors', {})
        base_results['ann_factors']['annuity_factor_base']   = ann_factors_base   # (num_policies, num_months)
        base_results['ann_factors']['annuity_factor_stress'] = ann_factors_stress # (num_policies, num_months)

    def run_IFRS(self):
        """
        Runs the IFRS process for the entire product in one go:
        
        """
        self.run_type = "IFRS"
        self.logger.info(f"Starting IFRS run in {self.__class__.__name__}.")

        # 1) read CRNHR sensitivity table
        if self.product_name =='RIDER_ADB':
            table_name = "Sensitivity_Table_CRNHR_ADB"
        elif self.product_name in ['RIDER_CI','RIDER_ATPD']:
            table_name = "Sensitivity_Table_CRNHR_CI_ATPD"
        else:
            table_name = "Sensitivity_Table_CRNHR_Term_GCL"
        crnhr_sens_df = self.table_index.read_table(table_name)  # DataFrame with scenario rows

        # 2) base run
        self.logger.info("Running base scenario for CRNHR.")
        base_results = self.run_batch(self.policy_data, self.policy_numbers)
        self.base_assumptions = copy.deepcopy(self.assumptions)
        
        # 3) loop over each scenario in CRNHR table
        scenario_results = {}
        for _, row in crnhr_sens_df.iterrows():
            scenario_name = row['Sensitivity Description']
            
            # Skip Morbidity scenarios for non-rider products
            if scenario_name == "Morbidity" and self.product_name not in self.RIDER_TYPES:
                self.logger.info(f"Skipping CRNHR scenario: {scenario_name} for non-rider product {self.product_name}")
                continue
            
            self.logger.info(f"Running CRNHR scenario: {scenario_name}")
            # run scenario
            bel_scenario = self._run_crnhr_scenario(row, scenario_label=scenario_name)
            scenario_results[scenario_name] = bel_scenario

        # 4) compute CRNHR capital using stored base + scenario results
        crnhr_output = self._compute_crnhr_capital(
            base_results=base_results,
            scenario_results=scenario_results
        )
        batch_output = self.create_output_df(self.policy_numbers, base_results)
        
        # 5) store or export final CRNHR outputs
        self._export_crnhr_results(crnhr_output, batch_output)
        ifrs_output = self.generate_ifrs_output(base_results, scenario_results, crnhr_output)
        self.output.store_results(ifrs_output)
        self.output.print_output(self.inforce)

        self.logger.info(f"IFRS run completed in {self.__class__.__name__}.")

    def generate_ifrs_output(self, base_results,scenario_results, crnhr_output):
        """
        Generates IFRS-specific output.
        """
        # Implement the logic to generate IFRS-specific output
        ifrs_output = {}
        # Add IFRS-specific calculations and results to ifrs_output
        policy_numbers = self.policy_numbers
        calendar_months = base_results['policy_attrs']['calendar_months']
        projection_steps = base_results['policy_attrs']['projection_steps']
        policy_months = base_results['policy_attrs']['policy_months']
        
        num_entries = base_results['policy_attrs']['policy_months'].size
        
        policy_numbers = np.repeat(policy_numbers, num_entries // len(policy_numbers))
        policy_months = np.array(policy_months).flatten()[:num_entries]
        calendar_months = np.tile(calendar_months, len(policy_numbers) // len(calendar_months))[:num_entries]
        projection_steps = np.tile(projection_steps, len(policy_numbers) // len(projection_steps))[:num_entries]
        
        policy_attrs = base_results['policy_attrs']
        rates    = base_results['rates']
        premium_frequencies = policy_attrs['premium_frequencies']
        
        if self.product_name in ['RIDER_CI', 'RIDER_ADB', 'RIDER_ATPD']:
            premium_amounts = policy_attrs['base_premiums']  
        else:  
            premium_amounts = policy_attrs['premium_amounts']
        
        modal_factor = rates['modal_factor']
        lives_so_begin = base_results['decrements_BE']['lives_so_begin']
        lapses = base_results['decrements_BE']['lapses']
        deaths = base_results['decrements_BE']['deaths']
        lives_so_end = base_results['decrements_BE']['lives_so_end']
        maturities = base_results['decrements_BE']['maturities']
        sum_assureds = base_results['policy_attrs']['sum_assureds']
        reins_sum_assured = base_results['reinsurance_results']['reins_sum_assured']
        
        if self.product_name in ['RIDER_CI', 'RIDER_ADB', 'RIDER_ATPD']:
            reinsurance_mortality_rates = rates['monthly_reins_morbidity_rates']
        else:
            reinsurance_mortality_rates = rates['reinsurance_mortality_rates']
        
        num_months = policy_attrs['policy_months'].shape[1]
        num_policies = policy_attrs['num_policies']
        policy_terms_months = policy_attrs['policy_terms_months']
        fy = policy_attrs['fy']
        valuation_year = self.config.valuation_date.year
        if self.product_name in ['RIDER_CI', 'RIDER_ADB', 'RIDER_ATPD']:
            rider_option = policy_attrs['rider_option']


        premium_due_mask = jnp.where((premium_frequencies == 12), 1, (((policy_attrs['policy_months'] % (12 / premium_frequencies))) == 1).astype(FLOAT_DTYPE))
        premium_due_mask = premium_due_mask * (policy_attrs['projection_steps'] > 0).astype(FLOAT_DTYPE)  # Exclude time 0

        # Calculate premiums
        ifrs_premiums = base_results['be_results']['be_premiums']  # Shape: (num_policies, num_months)
        ifrs_premiums = ifrs_premiums.flatten()
        if len(ifrs_premiums) < num_entries:
            # Repeat until we match or exceed num_entries
            ifrs_premiums = np.tile(ifrs_premiums, (num_entries // len(ifrs_premiums)) + 1)[:num_entries]

        
        if self.product in ['RIDER_CI', 'RIDER_ADB', 'RIDER_ATPD']:
            if jnp.all(rider_option == 2):
                ifrs_death_benefits = base_results['be_results']['be_ci_benefit'] + base_results['be_results']['be_wop_benefit']
            elif jnp.all(rider_option ==1):
                ifrs_death_benefits = base_results['be_results']['be_adb_benefit']
            else:
                ifrs_death_benefits = base_results['be_results']['be_tpd_benefit'] + base_results['be_results']['be_wop_benefit']
        else:
            ifrs_death_benefits = base_results['be_results']['be_death_benefits']

        ifrs_surrender_benefits = base_results['be_results']['be_surrender_benefits']

        if self.product == 'GCL':
            Insurance_Component_Outgo = ifrs_death_benefits + ifrs_surrender_benefits
            Investment_Component_Outgo = jnp.zeros_like(ifrs_death_benefits)
        else:
            Insurance_Component_Outgo = ifrs_death_benefits
            Investment_Component_Outgo = ifrs_surrender_benefits

        # Instantiate the IFRS17 class and load the data
        ifrs17_init = IFRS17(self.table_index, self.config,self.product_name)
        ifrs17_init.load_data()

        starting_policy_month = policy_attrs['policy_months']
        
        # Acces annual locked-in-rate for Seriatim
        ifrs_annual_locked_in_rate = ifrs17_init.get_annual_rates('if17_Annual_Locked_in_Rate')
        ifrs_annual_locked_in_rate = np.tile(ifrs_annual_locked_in_rate, (num_entries // len(ifrs_annual_locked_in_rate)) + 1)[:num_entries]
        # for I17_GRP_NB_INT_ACC_CSM
        ifrs_annual_locked_in_rate = (1 + ifrs_annual_locked_in_rate)**(policy_months/12)
        
        
        valuation_month = self.config.valuation_date.month

        if valuation_month > 3:
            month_shift_locked_in = abs(valuation_month - 4)
        else:
            month_shift_locked_in = abs(valuation_month - 4 + 12)

        month_shift_current = abs(month_shift_locked_in - 13)

        # Access the IFRS ROI rates
        ifrs_current_rate_raw = ifrs17_init.get_monthly_rates('if17_Current_ROI')
        ifrs_current_rate = ifrs_current_rate_raw
        ifrs_current_rate = np.concatenate([ np.zeros(month_shift_current), ifrs_current_rate[:-(month_shift_current)] ])  
        ifrs_current_rate_array = np.tile(ifrs_current_rate, (num_policies, 1)) 
        
        ifrs_locked_in_rate_raw = ifrs17_init.get_monthly_rates('if17_Locked_in_Rate')
        ifrs_locked_in_rate = ifrs_locked_in_rate_raw[month_shift_locked_in:]
        ifrs_locked_in_rate = np.concatenate([np.zeros(1), ifrs_locked_in_rate[:-1]])
        ifrs_locked_in_rate = np.concatenate([ ifrs_locked_in_rate, np.zeros(month_shift_locked_in)])
        ifrs_locked_in_rate_array = np.tile(ifrs_locked_in_rate, (num_policies, 1)) 
        

        ifrs_ccil_rate_raw = ifrs17_init.get_monthly_rates('if17_CCIL Fwd Rates')
        
        num_policies, projection_months = starting_policy_month.shape
        ifrs_ccil_rate_list = []

        indicator = (policy_months - 1) // 12 + 1

        for i in range(num_policies):
            # Take the first month for each policy (e.g. starting_policy_month[i, 0])
            start_month = int(starting_policy_month[i, 0])  # assuming all cols are same start for that policy

            # Start from start_month, shift by 1 (add 0 in front), remove last
            rate_slice = ifrs_ccil_rate_raw[start_month:]
            shifted = np.concatenate([np.zeros(1), rate_slice[:-1]])

            # Pad to match projection length
            if len(shifted) < projection_months:
                shifted = np.concatenate([shifted, np.zeros(projection_months - len(shifted))])
            elif len(shifted) > projection_months:
                shifted = shifted[:projection_months]

            # Add to list
            ifrs_ccil_rate_list.append(shifted)
        

        # Convert the list to a numpy array
        ifrs_ccil_rate = ifrs_ccil_rate_list[0]
        ifrs_ccil_rate_array = np.array(ifrs_ccil_rate_list)

        for policy_idx in range(num_policies):
            # DYNAMICALLY select the correct rate array for the CURRENT policy
            ifrs_ccil_rate = ifrs_ccil_rate_array[policy_idx]
            # Reverse the rates for the current policy
            ccil_discount_rates_rev = ifrs_ccil_rate[::-1]



        # Calculate the IFRS17 initial expenses
        ifrs_initial_expenses = (base_results['be_results']['be_initial_expense'] * ifrs17_init.ifrs17_multiplier_initial_expenses) + base_results['be_results']['be_commissions']
        
        # Calculate the IFRS17 renewal expenses
        IFRS_Renewal_Fixed_expenses = ifrs17_init.get_renewal_expense_rates('Fixed expenses')
        IFRS17_Prem_expenses = ifrs17_init.get_renewal_expense_rates('% of Prem')
        IFRS17_Claim_expenses = ifrs17_init.get_renewal_expense_rates('Claim expenses')
        
        ifrs_renewal_fixed_expenses = IFRS_Renewal_Fixed_expenses

        
        # Shift ifrs_renewal_fixed_expenses down by 1 row
        if self.product == "GCL":
            ifrs_renewal_fixed_expenses = np.insert(ifrs_renewal_fixed_expenses[:-1], 0, 0.0)

            if ifrs_renewal_fixed_expenses.ndim == 1:
                ifrs_renewal_fixed_expenses = np.expand_dims(ifrs_renewal_fixed_expenses, axis=0)

            last_value = 0

            for i in range(2, ifrs_renewal_fixed_expenses.shape[1], 12):  # Step by 12 months
                    # Find the first non-zero value in the current 12-month block
                    block_start = i
                    block_end = min(i + 12, ifrs_renewal_fixed_expenses.shape[1])  # Ensure we don't go out of bounds
                    block_values = ifrs_renewal_fixed_expenses[0, block_start:block_end]

                    # Check if there is any non-zero value in the block
                    non_zero_indices = jnp.where(block_values != 0)[0]
                    if len(non_zero_indices) > 0:
                        # Use the first non-zero value in the block
                        first_non_zero_value = block_values[non_zero_indices[0]]
                    else:
                        # If no non-zero value is found, use the last value from the previous block
                        first_non_zero_value = last_value

                    # Update the block with the repeated value
                    ifrs_renewal_fixed_expenses[0, block_start:block_end] = first_non_zero_value

                    # Update the last_value for the next block
                    last_value = first_non_zero_value

            ifrs_renewal_fixed_expenses_scaled = ifrs_renewal_fixed_expenses[:, 2:] * (1 / 12)
            
            ifrs_renewal_fixed_expenses_undec = jnp.concatenate(
                [ifrs_renewal_fixed_expenses[:, :2], ifrs_renewal_fixed_expenses_scaled],
                axis=1
            )
            # Ensure ifrs_renewal_fixed_expenses has the same number of rows as lives_so_begin
            if ifrs_renewal_fixed_expenses.shape[0] == 1:
                ifrs_renewal_fixed_expenses = jnp.tile(ifrs_renewal_fixed_expenses, (lives_so_begin.shape[0], 1))

            ifrs_renewal_fixed_expenses = ifrs_renewal_fixed_expenses.at[:, 2:].set(
                ifrs_renewal_fixed_expenses_undec[:, 2:] * lives_so_begin[:, 2:]
            )

        else:
            ifrs_renewal_fixed_expenses = np.insert(ifrs_renewal_fixed_expenses[:-1], 0, 0.0)
        
        # Calculate the start month offset for each policy individually
        start_month_offsets = starting_policy_month[:, 0]  # Assuming starting_policy_month is a 2D array with shape (num_policies, num_months)

        # Adjust IFRS17_Prem_expenses for each policy based on its start month offset
        premium_frequency = policy_attrs['premium_frequencies']  # Take premium frequency from data
        
        IFRS17_Prem_expenses = IFRS17_Prem_expenses.reshape(1, -1)

        adjusted_IFRS17_Prem_expenses = []
        for policy_idx, start_month_offset in enumerate(start_month_offsets):
            # Check if the premium frequency is 12 (annual)
            if premium_frequency[policy_idx, 0] > 1:  # Assuming premium_frequency is a 2D array
                
                IFRS17_Prem_expenses_policy = IFRS17_Prem_expenses[:, start_month_offset - 1:]

                # Add padding to match the projection length
                padding_length = projection_months - IFRS17_Prem_expenses_policy.shape[1]
                if padding_length > 0:
                    padding = jnp.zeros((1, padding_length))
                    IFRS17_Prem_expenses_policy = jnp.concatenate([IFRS17_Prem_expenses_policy, padding], axis=1)
    
                if IFRS17_Prem_expenses_policy.ndim == 1:
                    IFRS17_Prem_expenses_policy = IFRS17_Prem_expenses_policy.reshape(1, -1) 
                
                last_value = 0

                # Iterate over the months in 12-month blocks
                for i in range(2, IFRS17_Prem_expenses_policy.shape[1], 12):  # Step by 12 months
                    # Find the first non-zero value in the current 12-month block
                    block_start = i
                    block_end = min(i + 12, IFRS17_Prem_expenses_policy.shape[1])  # Ensure we don't go out of bounds
                    block_values = IFRS17_Prem_expenses_policy[0, block_start:block_end]

                    # Check if there is any non-zero value in the block
                    non_zero_indices = jnp.where(block_values != 0)[0]
                    if len(non_zero_indices) > 0:
                        # Use the first non-zero value in the block
                        first_non_zero_value = block_values[non_zero_indices[0]]
                    else:
                        # If no non-zero value is found, use the last value from the previous block
                        first_non_zero_value = last_value

                    # Update the block with the repeated value
                    IFRS17_Prem_expenses_policy = IFRS17_Prem_expenses_policy.at[0, block_start:block_end].set(first_non_zero_value)

                    # Update the last_value for the next block
                    last_value = first_non_zero_value

                
            else:
                # Slice dynamically for the current policy
                IFRS17_Prem_expenses_policy = IFRS17_Prem_expenses[:, start_month_offset - 1:]
    
                # Add padding to match the projection length
                padding_length = projection_months - IFRS17_Prem_expenses_policy.shape[1]
                if padding_length > 0:
                    padding = jnp.zeros((1, padding_length))
                    IFRS17_Prem_expenses_policy = jnp.concatenate([IFRS17_Prem_expenses_policy, padding], axis=1)
    
            adjusted_IFRS17_Prem_expenses.append(IFRS17_Prem_expenses_policy)

        # Convert the list back to a single array
        adjusted_IFRS17_Prem_expenses = jnp.concatenate(adjusted_IFRS17_Prem_expenses, axis=0)

        
        if ifrs_renewal_fixed_expenses.ndim == 1:
            ifrs_premiums_reshape = ifrs_premiums.reshape(-1, len(ifrs_renewal_fixed_expenses))  # Reshape with dynamic number of policies
        else:
            ifrs_premiums_reshape = ifrs_premiums.reshape(-1, ifrs_renewal_fixed_expenses.shape[1])
        
        ifrs_renewal_prem_expenses = adjusted_IFRS17_Prem_expenses * ifrs_premiums_reshape
        
        combined_renewal_expenses = base_results['be_results']['be_commissions'] + ifrs_renewal_fixed_expenses + ifrs_renewal_prem_expenses

         # Calculate claim expense
        ifrs_claim_expense = IFRS17_Claim_expenses * deaths

        #BEL Calculation (Gross of reinsurance and adjusted for I17 Expenses)
        # Calculate the BEL CF
        ifrs_bel_cf =  ifrs_death_benefits + ifrs_surrender_benefits + ifrs_initial_expenses + combined_renewal_expenses + ifrs_claim_expense - ifrs_premiums_reshape

        # Calculate BEL at Onerous Tagging Rate
        bel_at_onerous_tagging_rate = ifrs_bel_cf - ((ifrs_premiums_reshape - ifrs_initial_expenses - combined_renewal_expenses) * ifrs_ccil_rate)

        # Reverse arrays for backward calculation
        bel_at_onerous_tagging_rate_rev = bel_at_onerous_tagging_rate[:, ::-1]  # Shape: (num_policies, num_months)
        
        # Create an array to store reversed discount rates for all policies
        discount_rates_rev_array = np.zeros_like(ifrs_ccil_rate_array)

        # Populate the array with reversed rates for each policy
        for policy_idx in range(num_policies):
            ifrs_ccil_rate = ifrs_ccil_rate_array[policy_idx]
            discount_rates_rev_array[policy_idx] = ifrs_ccil_rate[::-1]

        # Function to discount cash flows for a single policy
        def discount_policy_cashflows(net_cash_flow_rev,discount_rates_rev):
            def discount_step(carry, inputs):
                discount_rate, net_cf = inputs
                pv_next = carry
                pv = (pv_next + net_cf) / (1 + discount_rate)
                return pv, pv

            init_carry = 0.0

            _, discounted_net_cf_rev = lax.scan(
                discount_step,
                init_carry,
                (discount_rates_rev, net_cash_flow_rev)
            )

            return discounted_net_cf_rev

        # Apply the function to each policy
        discounted_bel_at_onerous_tagging_rate_rev = jax.vmap(discount_policy_cashflows)(bel_at_onerous_tagging_rate_rev,discount_rates_rev_array)

        # Reverse back to original order
        discounted_bel_at_onerous_tagging_rate = discounted_bel_at_onerous_tagging_rate_rev[:, ::-1]

        # Shift the array by one row up
        discounted_bel_at_onerous_tagging_rate_shifted_up = discounted_bel_at_onerous_tagging_rate[:, 1:]

        discounted_bel_at_onerous_tagging_rate_shifted_up = np.hstack([discounted_bel_at_onerous_tagging_rate_shifted_up, np.zeros((discounted_bel_at_onerous_tagging_rate.shape[0], 1))])

        # Calculate BEL PP at Onerous tagging rate
        if self.product in ['RIDER_CI', 'RIDER_ADB', 'RIDER_ATPD']:
            if jnp.all(rider_option == 2):
                net_cumulative_critical_illness = base_results['decrements_BE']['net_cumulative_critical_illness']
                bel_pp_at_onerous_tagging_rate = discounted_bel_at_onerous_tagging_rate_shifted_up/ (lives_so_end + maturities + net_cumulative_critical_illness)  # Shape: (num_policies, num_months)
            elif jnp.all(rider_option ==1):
                bel_pp_at_onerous_tagging_rate = discounted_bel_at_onerous_tagging_rate_shifted_up / (lives_so_end + maturities)  # Shape: (num_policies, num_months)
            else:
                net_cumulative_disability = base_results['decrements_BE']['net_cumulative_disability']
                bel_pp_at_onerous_tagging_rate = discounted_bel_at_onerous_tagging_rate_shifted_up / (lives_so_end + maturities + net_cumulative_disability)  # Shape: (num_policies, num_months)
        else:
            bel_pp_at_onerous_tagging_rate = discounted_bel_at_onerous_tagging_rate_shifted_up / (lives_so_end + maturities)

        # Access CRNHR output
        crnhr_mortality_rc = crnhr_output.get('mortality_rc', None)
        crnhr_lapse_up_rc = crnhr_output.get('lapse_up_rc', None)
        crnhr_lapse_down_rc = crnhr_output.get('lapse_down_rc', None)
        crnhr_mass_lapse_rc = crnhr_output.get('mass_lapse_rc', None)
        crnhr_lapse_rc = crnhr_output.get('lapse_rc', None)
        crnhr_cat_rc = crnhr_output.get('cat_rc', None)
        crnhr_expense_rc = crnhr_output.get('expense_rc', None)
        crnhr_diversified_caps = crnhr_output.get('diversified_caps', None)
        crnhr_operational_risk_monthly = crnhr_output.get('operational_risk_monthly', None)
        crnhr_economic_capital_monthly = crnhr_output.get('cost_of_ec_monthly', None)
        crnhr_cost_of_ec_monthly = crnhr_output.get('cost_of_ec_monthly', None)
        crnhr_pv_crnhr = crnhr_output.get('pv_crnhr', None)

        if self.product_name.upper() in self.RIDER_TYPES:
            crnhr_morbidity_rc = crnhr_output.get('morbidity_rc', None)


        # Calculate the PV of Expenses using Locked-In Rate
        combined_expenses_rev = combined_renewal_expenses[:, ::-1]  # Reverse for backward calculation
        discount_rates_locked_in_rev = ifrs_locked_in_rate[::-1]  # Reverse the locked-in rates

        # Function to discount expenses for a single policy
        def discount_expenses(expenses_rev):
            def discount_step(carry, inputs):
                discount_rate, expense = inputs
                pv_next = carry
                pv = (pv_next  / (1 + discount_rate)) + expense
                return pv, pv

            init_carry = 0.0

            _, discounted_expenses_rev = lax.scan(
                discount_step,
                init_carry,
                (discount_rates_locked_in_rev, expenses_rev)
            )

            return discounted_expenses_rev

        # Apply the function to each policy
        discounted_expenses_rev = jax.vmap(discount_expenses)(combined_expenses_rev)

        # Reverse back to original order
        discounted_expenses = discounted_expenses_rev[:, ::-1]
        
        discounted_expenses_shifted_up = discounted_expenses[:, 1:]

        discounted_expenses_shifted_up = np.hstack([discounted_expenses_shifted_up, np.zeros((discounted_expenses.shape[0], 1))])

        # Calculate adjusted px
        
        if self.product in ['RIDER_CI', 'RIDER_ADB', 'RIDER_ATPD']:
            if jnp.all(rider_option == 2):
                adj_px = lives_so_begin + net_cumulative_critical_illness  # Shape: (num_policies, num_months)
            elif jnp.all(rider_option ==1):
                adj_px = lives_so_begin  # Shape: (num_policies, num_months)
            else:
                adj_px = lives_so_begin + net_cumulative_disability  # Shape: (num_policies, num_months)
        else:
            adj_px = lives_so_begin


        # Retrieve additional variables
        additional_variables = ifrs17_init.get_additional_variables()

        # Access v
        ifrs_v = additional_variables['IFRS17_V']
        ifrs_stress_v = additional_variables['IFRS17_Stress_V']

        # Calculate DF
        base_df = np.zeros(num_months)
        # Assuming policy_months is a range or list of month indices
        for i in list(range(1, num_months + 1)):
            if i < 3:
                base_df[i - 1] = 1
            else:
                base_df[i - 1] = ifrs_v ** (i - 1)

        base_df_array = np.tile(base_df, len(policy_numbers))[:num_entries]
        
        stress_df = np.zeros(num_months)
        for i in list(range(1, num_months + 1)):
            if i < 3:
                stress_df[i - 1] = 1
            else:
                stress_df[i - 1] = ifrs_stress_v ** (i - 1)
        
        stress_df_array = np.tile(stress_df, len(policy_numbers))[:num_entries]
        
        num_months   = self.projection_months
        
        # Build discount-factor arrays: shape (num_months,) for base & stress
        t_index     = jnp.arange(num_months)  # [0..num_months-1]
        df_base     = base_df
        df_stress   = stress_df

        # Function to compute the annuity-factor “vector” for one policy
        # e.g. a reversed cumulative sum of (adjusted_px * discount_factors).
        def annuity_factor_for_one_policy(px_for_policy: jnp.ndarray, df: jnp.ndarray) -> jnp.ndarray:
            rev_mult = px_for_policy[::-1] * df[::-1]      # shape (num_months,)
            rev_cumsum    = jnp.cumsum(rev_mult, axis=0) # partial sums in reverse
            partial_sums  = rev_cumsum[::-1]                  # shape (num_months,)

            return partial_sums / (df*px_for_policy )

        # Vectorize across all policies using jax.vmap
        annuity_factors_base_array = jax.vmap(lambda px: annuity_factor_for_one_policy(px, df_base))(adj_px)
        
         # Access stress expense
        stress_expense = additional_variables['IFRS17_Stress_Expense']
        
        annuity_factors_stress_array = jax.vmap(lambda px: annuity_factor_for_one_policy(px, df_stress))(adj_px)
        annuity_factors_stress_array = annuity_factors_stress_array*stress_expense

        # Access extra inflation
        stress_inflation = additional_variables['IFRS17_Stress_Inflation']

        ifrs_stress_inflation = np.zeros(num_months)
        for i in list(range(1, num_months + 1)):
            if i < 3:
                ifrs_stress_inflation[i - 1] = 1
            else:
                ifrs_stress_inflation[i - 1] = (1 + stress_inflation) ** (i - 2)

        ifrs_stress_inflation_array = np.tile(ifrs_stress_inflation, len(policy_numbers))[:num_entries]
       
        # Calculate stress expense
        ifrs_stress_expense = ifrs_renewal_fixed_expenses + ifrs_renewal_prem_expenses*stress_expense*ifrs_stress_inflation

        # Calculate the PV of Stress Expenses using Locked-In Rate
        ifrs_stress_expense_rev = ifrs_stress_expense[:, ::-1]  # Reverse for backward calculation
        discount_rates_locked_in_rev = ifrs_locked_in_rate[::-1]  # Reverse the locked-in rates

        # Function to discount expenses for a single policy
        def discount_expenses(stress_expenses_rev):
            def discount_step(carry, inputs):
                discount_rate, expense = inputs
                pv_next = carry
                pv = pv_next / (1 + discount_rate) + expense
                return pv, pv

            init_carry = 0.0

            _, discounted_stress_expenses_rev = lax.scan(
                discount_step,
                init_carry,
                (discount_rates_locked_in_rev, stress_expenses_rev)
            )

            return discounted_stress_expenses_rev

        # Apply the function to each policy
        discounted_stress_expenses_rev = jax.vmap(discount_expenses)(ifrs_stress_expense_rev)

        # Reverse back to original order
        discounted_stress_expenses = discounted_stress_expenses_rev[:, ::-1]

        discounted_stress_expenses_shifted_up = discounted_stress_expenses[:, 1:]

        discounted_stress_expenses_shifted_up = np.hstack([discounted_stress_expenses_shifted_up, np.zeros((discounted_stress_expenses.shape[0], 1))])

        infl_factor = (1 + rates['Inflation_Factor']) ** ((policy_attrs['projection_steps'] - 1)/12) 

        #Calculate Expense Capital
        if self.product == "GCL":
            ifrs_expense_captial = (ifrs_renewal_fixed_expenses_undec + ifrs_renewal_prem_expenses) * infl_factor * (annuity_factors_stress_array - annuity_factors_base_array) * lives_so_end
        else:
            ifrs_expense_captial = discounted_stress_expenses_shifted_up - discounted_expenses_shifted_up

        #Calculte (BEL+ RA) for Onerosity
        bel_ra_onerous = bel_pp_at_onerous_tagging_rate + crnhr_pv_crnhr

        #Calculate PV Ins Outgo @ Onerosity rate
        ifrs_death_benefits_rev_onerous = Insurance_Component_Outgo[:, ::-1]  # Reverse for backward calculation
        
        # Create an array to store reversed discount rates for all policies
        db_discount_rates_rev_onerous_array = np.zeros_like(ifrs_ccil_rate_array)

        # Populate the array with reversed rates for each policy
        for policy_idx in range(num_policies):
            ifrs_ccil_rate = ifrs_ccil_rate_array[policy_idx]
            db_discount_rates_rev_onerous_array[policy_idx] = ifrs_ccil_rate[::-1]  # Shape: (num_months,)

        # Function to discount death benefit for a single policy
        def discount_death_benefit_onerous(death_benefits_rev,db_discount_rates_rev_onerous):
            def discount_step(carry, inputs):
                discount_rate, death_benefit = inputs
                pv_next = carry
                pv = (pv_next + death_benefit) / (1 + discount_rate)
                return pv, pv

            init_carry = 0.0

            _, discounted_death_benefit_rev = lax.scan(
                discount_step,
                init_carry,
                (db_discount_rates_rev_onerous, death_benefits_rev)
            )

            return discounted_death_benefit_rev

        # Apply the function to each policy
        discounted_death_benefit_rev_onerous = jax.vmap(discount_death_benefit_onerous)(ifrs_death_benefits_rev_onerous,db_discount_rates_rev_onerous_array)

        # Reverse back to original order
        discounted_death_benefit_onerous = discounted_death_benefit_rev_onerous[:, ::-1]

        discounted_death_benefit_onerous_shifted_up = discounted_death_benefit_onerous[:, 1:]

        discounted_death_benefit_onerous_shifted_up = np.hstack([discounted_death_benefit_onerous_shifted_up, np.zeros((discounted_death_benefit_onerous.shape[0], 1))])

        # Calculate PV Ins Outgo @ Locked-in rate
        ifrs_death_benefits_rev_locked_in = Insurance_Component_Outgo[:, ::-1]  # Reverse for backward calculation
        db_discount_rates_rev_locked_in = ifrs_locked_in_rate[::-1]  # Shape: (num_months,)

        # Function to discount expenses for a single policy
        def discount_death_benefit_locked_in(death_benefits_rev):
            def discount_step(carry, inputs):
                discount_rate, death_benefit = inputs
                pv_next = carry
                pv = (pv_next + death_benefit) / (1 + discount_rate)
                return pv, pv

            init_carry = 0.0

            _, discounted_death_benefit_rev = lax.scan(
                discount_step,
                init_carry,
                (db_discount_rates_rev_locked_in, death_benefits_rev)
            )

            return discounted_death_benefit_rev

        # Apply the function to each policy
        discounted_death_benefit_rev_locked_in = jax.vmap(discount_death_benefit_locked_in)(ifrs_death_benefits_rev_locked_in)

        # Reverse back to original order
        discounted_death_benefit_at_locked_in_rate = discounted_death_benefit_rev_locked_in[:, ::-1]

        discounted_death_benefit_at_locked_in_rate_shifted_up = discounted_death_benefit_at_locked_in_rate[:, 1:]

        discounted_death_benefit_at_locked_in_rate_shifted_up = np.hstack([discounted_death_benefit_at_locked_in_rate_shifted_up, np.zeros((discounted_death_benefit_at_locked_in_rate.shape[0], 1))])
        
        # Calculate PV Outgo @ Locked-in
        ifrs_outgo = ifrs_death_benefits + ifrs_surrender_benefits + ifrs_claim_expense + (ifrs_initial_expenses + combined_renewal_expenses) * (1 + ifrs_locked_in_rate) 
        ifrs_outgo_rev_locked_in = ifrs_outgo[:, ::-1]  # Reverse for backward calculation
        outgo_discount_rates_rev_lcoked_in = ifrs_locked_in_rate[::-1]  # Shape: (num_months,)

        # Function to discount expenses for a single policy
        def discount_outgo_locked_in(outgo_rev):
            def discount_step(carry, inputs):
                discount_rate, outgo = inputs
                pv_next = carry
                pv = (pv_next + outgo) / (1 + discount_rate)
                return pv, pv

            init_carry = 0.0

            _, discounted_outgo_rev = lax.scan(
                discount_step,
                init_carry,
                (outgo_discount_rates_rev_lcoked_in, outgo_rev)
            )

            return discounted_outgo_rev

        # Apply the function to each policy
        discounted_outgo_rev_locked_in = jax.vmap(discount_outgo_locked_in)(ifrs_outgo_rev_locked_in)

        # Reverse back to original order
        discounted_outgo_at_locked_in_rate = discounted_outgo_rev_locked_in[:, ::-1]

        discounted_outgo_at_locked_in_rate_shifted_up = discounted_outgo_at_locked_in_rate[:, 1:]

        discounted_outgo_at_locked_in_rate_shifted_up = np.hstack([discounted_outgo_at_locked_in_rate_shifted_up, np.zeros((discounted_outgo_at_locked_in_rate.shape[0], 1))])

        # Calculate PV Outgo PP @ Locked-in
        if self.product_name.upper() == 'GCL':
            outgo_pp_at_locked_in_rate = discounted_outgo_at_locked_in_rate_shifted_up / (lives_so_end)
        elif self.product in ['RIDER_CI', 'RIDER_ADB', 'RIDER_ATPD']:
            if jnp.all(rider_option == 2):
                outgo_pp_at_locked_in_rate = discounted_outgo_at_locked_in_rate_shifted_up/ (lives_so_end + maturities + net_cumulative_critical_illness)  # Shape: (num_policies, num_months)
            elif jnp.all(rider_option ==1):
                outgo_pp_at_locked_in_rate = discounted_outgo_at_locked_in_rate_shifted_up / (lives_so_end + maturities)  # Shape: (num_policies, num_months)
            else:
                outgo_pp_at_locked_in_rate = discounted_outgo_at_locked_in_rate_shifted_up / (lives_so_end + maturities + net_cumulative_disability)  # Shape: (num_policies, num_months)
        else:    
            outgo_pp_at_locked_in_rate = discounted_outgo_at_locked_in_rate_shifted_up / (lives_so_end + maturities)

        # Calculate BEL @ Locked-in
        bel_at_locked_in = ifrs_bel_cf - (ifrs_premiums_reshape - ifrs_initial_expenses - combined_renewal_expenses) * ifrs_locked_in_rate

         # Reverse arrays for backward calculation
        bel_at_locked_in_rate_rev = bel_at_locked_in[:, ::-1]  # Shape: (num_policies, num_months)
        bel_discount_rates_rev_locked_in = ifrs_locked_in_rate[::-1]  # Shape: (num_months,)

        # Function to discount cash flows for a single policy
        def discount_bel_cashflows_locked_in(bel_cash_flow_rev):
            def discount_step(carry, inputs):
                discount_rate, bel_cf = inputs
                pv_next = carry
                pv = (pv_next + bel_cf) / (1 + discount_rate)
                return pv, pv

            init_carry = 0.0

            _, discounted_bel_cf_rev = lax.scan(
                discount_step,
                init_carry,
                (bel_discount_rates_rev_locked_in, bel_cash_flow_rev)
            )

            return discounted_bel_cf_rev

        # Apply the function to each policy
        discounted_bel_at_locked_in_rate_rev = jax.vmap(discount_bel_cashflows_locked_in)(bel_at_locked_in_rate_rev)

        # Reverse back to original order
        discounted_bel_at_locked_in_rate = discounted_bel_at_locked_in_rate_rev[:, ::-1]

        discounted_bel_at_locked_in_rate_shifted_up = discounted_bel_at_locked_in_rate[:, 1:]

        discounted_bel_at_locked_in_rate_shifted_up = np.hstack([discounted_bel_at_locked_in_rate_shifted_up, np.zeros((discounted_bel_at_locked_in_rate.shape[0], 1))])

        # Calculate BEL PP @ Locked-in
        if self.product_name.upper() == 'GCL':
            bel_pp_at_locked_in_rate = discounted_bel_at_locked_in_rate_shifted_up / (lives_so_end)
        elif self.product in ['RIDER_CI', 'RIDER_ADB', 'RIDER_ATPD']:
            if jnp.all(rider_option == 2):
                bel_pp_at_locked_in_rate = discounted_bel_at_locked_in_rate_shifted_up/ (lives_so_end + maturities + net_cumulative_critical_illness)  # Shape: (num_policies, num_months)
            elif jnp.all(rider_option ==1):
                bel_pp_at_locked_in_rate = discounted_bel_at_locked_in_rate_shifted_up / (lives_so_end + maturities)  # Shape: (num_policies, num_months)
            else:
                bel_pp_at_locked_in_rate = discounted_bel_at_locked_in_rate_shifted_up / (lives_so_end + maturities + net_cumulative_disability)  # Shape: (num_policies, num_months)
        else:
            bel_pp_at_locked_in_rate = discounted_bel_at_locked_in_rate_shifted_up / (lives_so_end + maturities)

        # Calculate RA @ Locked-in
        ifrs_ra_locked_in = discounted_death_benefit_at_locked_in_rate_shifted_up*additional_variables['IFRS17_RA_Ratio']

        # Calculate RA PP @ Locked-in
        if self.product_name.upper() == 'GCL':
            ifrs_ra_pp_at_locked_in_rate = ifrs_ra_locked_in / (lives_so_end)
        elif self.product in ['RIDER_CI', 'RIDER_ADB', 'RIDER_ATPD']:
            if jnp.all(rider_option == 2):
                ifrs_ra_pp_at_locked_in_rate = ifrs_ra_locked_in/ (lives_so_end + maturities + net_cumulative_critical_illness)  # Shape: (num_policies, num_months)
            elif jnp.all(rider_option ==1):
                ifrs_ra_pp_at_locked_in_rate = ifrs_ra_locked_in / (lives_so_end + maturities)  # Shape: (num_policies, num_months)
            else:
                ifrs_ra_pp_at_locked_in_rate = ifrs_ra_locked_in / (lives_so_end + maturities + net_cumulative_disability)  # Shape: (num_policies, num_months)
        else:
            ifrs_ra_pp_at_locked_in_rate = ifrs_ra_locked_in / (lives_so_end + maturities)

        # Calculate PV Ins Outgo @ Current rate
        ifrs_death_benefits_rev_current_rate = Insurance_Component_Outgo[:, ::-1]  # Reverse for backward calculation
        db_discount_rates_rev_current_rate = ifrs_current_rate[::-1]  # Shape: (num_months,)

        # Function to discount expenses for a single policy
        def discount_death_benefit_current_rate(death_benefits_rev_current_rate):
            def discount_step(carry, inputs):
                discount_rate, death_benefit = inputs
                pv_next = carry
                pv = (pv_next + death_benefit) / (1 + discount_rate)
                return pv, pv

            init_carry = 0.0

            _, discounted_death_benefit_rev = lax.scan(
                discount_step,
                init_carry,
                (db_discount_rates_rev_current_rate, death_benefits_rev_current_rate)
            )

            return discounted_death_benefit_rev

        # Apply the function to each policy
        discounted_death_benefit_rev_current_rate = jax.vmap(discount_death_benefit_current_rate)(ifrs_death_benefits_rev_current_rate)

        # Reverse back to original order
        discounted_death_benefit_at_current_rate = discounted_death_benefit_rev_current_rate[:, ::-1]

        discounted_death_benefit_at_current_rate_shifted_up = discounted_death_benefit_at_current_rate[:, 1:]

        discounted_death_benefit_at_current_rate_shifted_up = np.hstack([discounted_death_benefit_at_current_rate_shifted_up, np.zeros((discounted_death_benefit_at_current_rate.shape[0], 1))])

        #Calculate PV Ins Outgo PP @ Current rate
        if self.product_name.upper() == 'GCL':
            ifrs_outgo_pp_at_current_rate = discounted_death_benefit_at_current_rate_shifted_up / (lives_so_end)
        elif self.product in ['RIDER_CI', 'RIDER_ADB', 'RIDER_ATPD']:
            if jnp.all(rider_option == 2):
                ifrs_outgo_pp_at_current_rate = discounted_death_benefit_at_current_rate_shifted_up/ (lives_so_end + maturities + net_cumulative_critical_illness)  # Shape: (num_policies, num_months)
            elif jnp.all(rider_option ==1):
                ifrs_outgo_pp_at_current_rate = discounted_death_benefit_at_current_rate_shifted_up / (lives_so_end + maturities)  # Shape: (num_policies, num_months)
            else:
                ifrs_outgo_pp_at_current_rate = discounted_death_benefit_at_current_rate_shifted_up / (lives_so_end + maturities + net_cumulative_disability)  # Shape: (num_policies, num_months)
        else:
            ifrs_outgo_pp_at_current_rate = discounted_death_benefit_at_current_rate_shifted_up / (lives_so_end + maturities)

        #Calculate BEL @ Current
        bel_at_current_rate = ifrs_bel_cf - (ifrs_premiums_reshape - ifrs_initial_expenses - combined_renewal_expenses) * ifrs_current_rate

        # Reverse arrays for backward calculation
        bel_at_current_rate_rev = bel_at_current_rate[:, ::-1]  # Shape: (num_policies, num_months)
        bel_discount_rates_rev_current_rate = ifrs_current_rate[::-1]  # Shape: (num_months,)

        # Function to discount cash flows for a single policy
        def discount_bel_cashflows_current_rate(bel_cash_flow_rev):
            def discount_step(carry, inputs):
                discount_rate, bel_cf = inputs
                pv_next = carry
                pv = (pv_next + bel_cf) / (1 + discount_rate)
                return pv, pv

            init_carry = 0.0

            _, discounted_bel_cf_rev = lax.scan(
                discount_step,
                init_carry,
                (bel_discount_rates_rev_current_rate, bel_cash_flow_rev)
            )

            return discounted_bel_cf_rev

        # Apply the function to each policy
        discounted_bel_at_current_rate_rev = jax.vmap(discount_bel_cashflows_current_rate)(bel_at_current_rate_rev)

        # Reverse back to original order
        discounted_bel_at_current_rate = discounted_bel_at_current_rate_rev[:, ::-1]

        discounted_bel_at_current_rate_shifted_up = discounted_bel_at_current_rate[:, 1:]

        discounted_bel_at_current_rate_shifted_up = np.hstack([discounted_bel_at_current_rate_shifted_up, np.zeros((discounted_bel_at_current_rate.shape[0], 1))])

        # Calculate BEL PP @ Current
        if self.product_name.upper() == 'GCL':
            bel_pp_at_current_rate = discounted_bel_at_current_rate_shifted_up / (lives_so_end)
        elif self.product in ['RIDER_CI', 'RIDER_ADB', 'RIDER_ATPD']:
            if jnp.all(rider_option == 2):
                bel_pp_at_current_rate = discounted_bel_at_current_rate_shifted_up/ (lives_so_end + maturities + net_cumulative_critical_illness)  # Shape: (num_policies, num_months)
            elif jnp.all(rider_option ==1):
                bel_pp_at_current_rate = discounted_bel_at_current_rate_shifted_up / (lives_so_end + maturities)  # Shape: (num_policies, num_months)
            else:
                bel_pp_at_current_rate = discounted_bel_at_current_rate_shifted_up / (lives_so_end + maturities + net_cumulative_disability)  # Shape: (num_policies, num_months)
        else:
            bel_pp_at_current_rate = discounted_bel_at_current_rate_shifted_up / (lives_so_end + maturities)

        #Calculate RA PP @ Current
        ifrs_ra_pp_at_current_rate = ifrs_outgo_pp_at_current_rate*additional_variables['IFRS17_RA_Ratio']

        # Calculate No. of Policies at Per End
        ifrs_no_of_policies_at_per_end = lives_so_end

        policy_term_ind = jnp.where(policy_attrs['policy_months']<=policy_attrs['policy_terms_months'][:, None],1,0)

        #Calculate Death Benefit IF
        if self.product in ['RIDER_CI', 'RIDER_ADB', 'RIDER_ATPD']:
            if jnp.all(rider_option == 2):
                ci_benefit = sum_assureds
                wop_benefit = (policy_attrs['base_premiums'] * modal_factor) * premium_due_mask * (policy_attrs['projection_steps']>0) * policy_term_ind # Shape: (num_policies, num_months)
                ifrs_death_benefits_IF = (ci_benefit + wop_benefit) * ifrs_no_of_policies_at_per_end
                ifrs_death_benefits_IF = ifrs_death_benefits_IF.at[:,:1].set(0.0)   # To match at Seriatim level
            elif jnp.all(rider_option ==1):
                adb_benefit = sum_assureds * (policy_attrs['projection_steps']>0) # Shape: (num_policies, num_months)
                ifrs_death_benefits_IF = adb_benefit * ifrs_no_of_policies_at_per_end
                ifrs_death_benefits_IF = ifrs_death_benefits_IF.at[:,:1].set(0.0)   # To match at Seriatim level
            else:
                tpd_benefit = sum_assureds
                wop_benefit = (policy_attrs['base_premiums'] * modal_factor) * premium_due_mask * (policy_attrs['projection_steps']>0) * policy_term_ind # Shape: (num_policies, num_months)
                ifrs_death_benefits_IF = (tpd_benefit + wop_benefit) * ifrs_no_of_policies_at_per_end
                ifrs_death_benefits_IF = ifrs_death_benefits_IF.at[:,:1].set(0.0)   # To match at Seriatim level
        else:
            ifrs_death_benefits_IF = sum_assureds * ifrs_no_of_policies_at_per_end
            ifrs_death_benefits_IF = ifrs_death_benefits_IF.at[:,:1].set(0.0)   # To match at Seriatim level

        #Calculate PV Coverage Units @ Locked-In
        cu_at_locked_in_rev = ifrs_death_benefits_IF[:, ::-1]  # Shape: (num_policies, num_months)
        cu_discount_rates_rev_locked_in = ifrs_locked_in_rate[::-1]  # Shape: (num_months,)

        # Function to discount cash flows for a single policy
        def discount_cu_locked_in_rate(cu_rev):
            def discount_step(carry, inputs):
                discount_rate, cu_cf = inputs
                pv_next = carry
                pv = (pv_next + cu_cf) / (1 + discount_rate)
                return pv, pv

            init_carry = 0.0

            _, discounted_bel_cf_rev = lax.scan(
                discount_step,
                init_carry,
                (cu_discount_rates_rev_locked_in, cu_rev)
            )

            return discounted_bel_cf_rev

        # Apply the function to each policy
        discounted_cu_at_locked_in_rate_rev = jax.vmap(discount_cu_locked_in_rate)(cu_at_locked_in_rev)

        # Reverse back to original order
        discounted_cu_at_locked_in_rate = discounted_cu_at_locked_in_rate_rev[:, ::-1]

        discounted_cu_at_locked_in_rate_shifted_up = discounted_cu_at_locked_in_rate[:, 1:]

        discounted_cu_at_locked_in_rate_shifted_up = np.hstack([discounted_cu_at_locked_in_rate_shifted_up, np.zeros((discounted_cu_at_locked_in_rate.shape[0], 1))])

        # Calculate the number of policies at the valuation date
        ifrs_no_of_policies_at_val_date = np.zeros_like(lives_so_end)

        for policy_idx in range(lives_so_end.shape[0]):  # Iterate over each policy
            # Initialize the policies array for the current policy
            ifrs_no_of_policies_at_val_date_projected = np.zeros(lives_so_end.shape[1])

            # Use the initial value from 'lives_so_end' as the starting point for the first projection step
            ifrs_no_of_policies_at_val_date_projected[0] = lives_so_end[policy_idx, 0]

            # Loop through each time step and calculate the policies for this policy
            for proj in range(1, lives_so_end.shape[1]):
                # Skip processing if lives_so_end for the current projection becomes zero
                if lives_so_end[policy_idx, proj] == 0:
                    continue

                # Check if the previous period has a value greater than 0
                if lives_so_end[policy_idx, proj - 1] != 0:
                    # Only apply the projection if the current period value is also non-zero
                    if lives_so_end[policy_idx, proj] != 0:
                        ifrs_no_of_policies_at_val_date_projected[proj] = (
                            ifrs_no_of_policies_at_val_date_projected[proj - 1]
                            * (lives_so_end[policy_idx, proj] / lives_so_end[policy_idx, proj - 1])
                        )
                    else:
                        # If current period is zero, keep the previous value
                        ifrs_no_of_policies_at_val_date_projected[proj] = ifrs_no_of_policies_at_val_date_projected[proj - 1]
                else:
                    # If the previous value is zero, carry forward the same value
                    ifrs_no_of_policies_at_val_date_projected[proj] = ifrs_no_of_policies_at_val_date_projected[proj - 1]

            # Store the results in the final projected array for the current policy
            ifrs_no_of_policies_at_val_date[policy_idx, :] = ifrs_no_of_policies_at_val_date_projected
        
        #Calculate Death Benefit IF as at val end
        if self.product in ['RIDER_CI', 'RIDER_ADB', 'RIDER_ATPD']:
            if jnp.all(rider_option == 2):
                ci_benefit = sum_assureds
                wop_benefit = (policy_attrs['base_premiums'] * modal_factor) * premium_due_mask * (policy_attrs['projection_steps']>0) * policy_term_ind # Shape: (num_policies, num_months)
                ifrs_death_benefits_IF_val_end = (ci_benefit + wop_benefit) * ifrs_no_of_policies_at_val_date
                ifrs_death_benefits_IF_val_end = ifrs_death_benefits_IF.at[:,:1].set(0.0)   # To match at Seriatim level
            elif jnp.all(rider_option ==1):
                adb_benefit = sum_assureds * (policy_attrs['projection_steps']>0) # Shape: (num_policies, num_months)
                ifrs_death_benefits_IF_val_end = adb_benefit * ifrs_no_of_policies_at_val_date
                ifrs_death_benefits_IF_val_end = ifrs_death_benefits_IF.at[:,:1].set(0.0)   # To match at Seriatim level
            else:
                tpd_benefit = sum_assureds
                wop_benefit = (policy_attrs['base_premiums'] * modal_factor) * premium_due_mask * (policy_attrs['projection_steps']>0) * policy_term_ind # Shape: (num_policies, num_months)
                ifrs_death_benefits_IF_val_end = (tpd_benefit + wop_benefit) * ifrs_no_of_policies_at_val_date
                ifrs_death_benefits_IF_val_end = ifrs_death_benefits_IF.at[:,:1].set(0.0)   # To match at Seriatim level
        else:
            ifrs_death_benefits_IF_val_end = sum_assureds * ifrs_no_of_policies_at_val_date
            ifrs_death_benefits_IF_val_end = ifrs_death_benefits_IF_val_end.at[:,:1].set(0.0)  # To match at Seriatim level

        #Calculate PV Coverage Units at Val date @ Locked-In
        cu_at_locked_in_rev_val_end = ifrs_death_benefits_IF_val_end[:, ::-1]  # Shape: (num_policies, num_months)
        cu_discount_rates_rev_locked_in_val_end = ifrs_locked_in_rate[::-1]  # Shape: (num_months,)
        

        # Function to discount cash flows for a single policy
        def discount_cu_locked_in_rate_val_end(cu_rev):
            def discount_step(carry, inputs):
                discount_rate, cu_cf = inputs
                pv_next = carry
                pv = (pv_next + cu_cf) / (1 + discount_rate)
                return pv, pv

            init_carry = 0.0

            _, discounted_bel_cf_rev = lax.scan(
                discount_step,
                init_carry,
                (cu_discount_rates_rev_locked_in_val_end, cu_rev)
            )

            return discounted_bel_cf_rev

        # Apply the function to each policy
        discounted_cu_at_locked_in_rate_rev_val_end = jax.vmap(discount_cu_locked_in_rate_val_end)(cu_at_locked_in_rev_val_end)

        # Reverse back to original order
        discounted_cu_at_locked_in_rate_val_end = discounted_cu_at_locked_in_rate_rev_val_end[:, ::-1]

        discounted_cu_at_locked_in_rate_val_end_shifted_up = discounted_cu_at_locked_in_rate_val_end[:, 1:]

        discounted_cu_at_locked_in_rate_val_end_shifted_up = np.hstack([discounted_cu_at_locked_in_rate_val_end_shifted_up, np.zeros((discounted_cu_at_locked_in_rate_val_end.shape[0], 1))])

        #Calculate Acc Future Cashflows (w/o discounting)
        ifrs_acc_future_cashflows = jnp.cumsum(ifrs_bel_cf[:, ::-1], axis=1)[:, ::-1]

        #Calculate Acc Future Cashflows PP (w/o discounting)
        if self.product_name.upper() == 'GCL':
            ifrs_acc_future_cashflows_pp = ifrs_acc_future_cashflows / (lives_so_end)
        elif self.product in ['RIDER_CI', 'RIDER_ADB', 'RIDER_ATPD']:
            if jnp.all(rider_option == 2):
                ifrs_acc_future_cashflows_pp = ifrs_acc_future_cashflows/ (lives_so_end + maturities + net_cumulative_critical_illness)  # Shape: (num_policies, num_months)
            elif jnp.all(rider_option ==1):
                ifrs_acc_future_cashflows_pp = ifrs_acc_future_cashflows / (lives_so_end + maturities)  # Shape: (num_policies, num_months)
            else:
                ifrs_acc_future_cashflows_pp = ifrs_acc_future_cashflows / (lives_so_end + maturities + net_cumulative_disability)  # Shape: (num_policies, num_months)
        else:
            ifrs_acc_future_cashflows_pp = ifrs_acc_future_cashflows / (lives_so_end + maturities)

        #Calculate Acq CFs at locked in rate
        ifrs_acq_cf_locked_in = ifrs_initial_expenses * (1+ifrs_locked_in_rate)

        #Calculate PV Acq Exp @ Locked-In
        ifrs_acq_cf_locked_in_rev = ifrs_acq_cf_locked_in[:, ::-1]  # Shape: (num_policies, num_months)
        acq_discount_rates_rev_locked_in = ifrs_locked_in_rate[::-1]  # Shape: (num_months,)

        # Function to discount cash flows for a single policy
        def discount_acq_exp_locked_in_rate(acq_exp_rev):
            def discount_step(carry, inputs):
                discount_rate, acq_exp = inputs
                pv_next = carry
                pv = (pv_next + (acq_exp * (1 + discount_rate))) / (1 + discount_rate)
                return pv, pv

            init_carry = 0.0

            _, discounted_bel_cf_rev = lax.scan(
                discount_step,
                init_carry,
                (acq_discount_rates_rev_locked_in, acq_exp_rev)
            )

            return discounted_bel_cf_rev

        # Apply the function to each policy
        discounted_ifrs_acq_cf_locked_in_rev = jax.vmap(discount_acq_exp_locked_in_rate)(ifrs_acq_cf_locked_in_rev)

        # Reverse back to original order
        discounted_ifrs_acq_cf_locked_in = discounted_ifrs_acq_cf_locked_in_rev[:, ::-1]

        #Calculate Reinsurance
        
        ifrs_ri_premium_outgo = reinsurance_mortality_rates * reins_sum_assured * lives_so_begin
        ifrs_ri_premium_outgo = ifrs_ri_premium_outgo.at[:, 0].set(0.0)

        #Calculate RI Death Recovery

        if self.product in ['RIDER_CI', 'RIDER_ADB', 'RIDER_ATPD']:
            if jnp.all(rider_option == 2):
                critical_illness = base_results['decrements_BE']['critical_illness']
                ifrs_ri_death_recovery = reins_sum_assured * critical_illness
            elif jnp.all(rider_option ==1):
                adb  = base_results['decrements_BE']['adb']
                ifrs_ri_death_recovery = reins_sum_assured * adb
            else:
                disability = base_results['decrements_BE']['disability']
                ifrs_ri_death_recovery = reins_sum_assured * disability
        else:
            ifrs_ri_death_recovery = reins_sum_assured * deaths

        #Calculate RI Net CF
        ifrs_ri_net_cf = ifrs_ri_premium_outgo - ifrs_ri_death_recovery

        #Calculate PV of RI Recov @ locked in
        ifrs_ri_death_recovery_rev = ifrs_ri_death_recovery[:, ::-1]  # Reverse for backward calculation
        ri_death_recovery_discount_rates_rev_locked_in = ifrs_locked_in_rate[::-1]  # Shape: (num_months,)

        # Function to discount cash flows for a single policy
        def discount_ri_death_recovery_locked_in_rate(ri_death_recovery_rev):
            def discount_step(carry, inputs):
                discount_rate, ri_recovery = inputs
                pv_next = carry
                pv = (pv_next + ri_recovery) / (1 + discount_rate)
                return pv, pv

            init_carry = 0.0

            _, discounted_bel_cf_rev = lax.scan(
                discount_step,
                init_carry,
                (ri_death_recovery_discount_rates_rev_locked_in, ri_death_recovery_rev)
            )

            return discounted_bel_cf_rev

        # Apply the function to each policy
        discounted_ifrs_ri_death_recovery_rev = jax.vmap(discount_ri_death_recovery_locked_in_rate)(ifrs_ri_death_recovery_rev)

        # Reverse back to original order
        discounted_ifrs_ri_death_recovery_locked_in = discounted_ifrs_ri_death_recovery_rev[:, ::-1]

        discounted_ifrs_ri_death_recovery_locked_in_shifted_up = discounted_ifrs_ri_death_recovery_locked_in[:, 1:]

        discounted_ifrs_ri_death_recovery_locked_in_shifted_up = np.hstack([discounted_ifrs_ri_death_recovery_locked_in_shifted_up, np.zeros((discounted_ifrs_ri_death_recovery_locked_in.shape[0], 1))])

        # Calculate PV of RI Recov PP @ locked in
        
        if self.product in ['RIDER_CI', 'RIDER_ADB', 'RIDER_ATPD']:
            if jnp.all(rider_option == 2):
                ri_death_recovery_pp_at_locked_in_rate = discounted_ifrs_ri_death_recovery_locked_in_shifted_up/ (lives_so_end + maturities + net_cumulative_critical_illness)  # Shape: (num_policies, num_months)
            elif jnp.all(rider_option ==1):
                ri_death_recovery_pp_at_locked_in_rate = discounted_ifrs_ri_death_recovery_locked_in_shifted_up / (lives_so_end + maturities)  # Shape: (num_policies, num_months)
            else:
                ri_death_recovery_pp_at_locked_in_rate = discounted_ifrs_ri_death_recovery_locked_in_shifted_up / (lives_so_end + maturities + net_cumulative_disability)  # Shape: (num_policies, num_months)
        else:
            ri_death_recovery_pp_at_locked_in_rate = discounted_ifrs_ri_death_recovery_locked_in_shifted_up / (lives_so_end + maturities)


        # Calculate BEL @ locked in
        ifrs_ri_bel_rev = ifrs_ri_net_cf[:, ::-1]  # Reverse for backward calculation
        ri_bel_discount_rates_rev_locked_in = ifrs_locked_in_rate[::-1]  # Shape: (num_months,)

        # Function to discount cash flows for a single policy
        def discount_ri_bel_locked_in_rate(ri_bel_rev):
            def discount_step(carry, inputs):
                discount_rate, ri_bel = inputs
                pv_next = carry
                pv = (pv_next + ri_bel) / (1 + discount_rate)
                return pv, pv

            init_carry = 0.0

            _, discounted_bel_cf_rev = lax.scan(
                discount_step,
                init_carry,
                (ri_bel_discount_rates_rev_locked_in, ri_bel_rev)
            )

            return discounted_bel_cf_rev

        # Apply the function to each policy
        discounted_ifrs_ri_bel_rev = jax.vmap(discount_ri_bel_locked_in_rate)(ifrs_ri_bel_rev)

        # Reverse back to original order
        discounted_ifrs_ri_bel_rev_locked_in = discounted_ifrs_ri_bel_rev[:, ::-1]

        discounted_ifrs_ri_bel_rev_locked_in_shifted_up = discounted_ifrs_ri_bel_rev_locked_in[:, 1:]

        discounted_ifrs_ri_bel_rev_locked_in_shifted_up = np.hstack([discounted_ifrs_ri_bel_rev_locked_in_shifted_up, np.zeros((discounted_ifrs_ri_bel_rev_locked_in.shape[0], 1))])

        # Calculate BEL PP @ Locked-in
        
        if self.product in ['RIDER_CI', 'RIDER_ADB', 'RIDER_ATPD']:
            if jnp.all(rider_option == 2):
                ri_BEL_pp_at_locked_in_rate = discounted_ifrs_ri_bel_rev_locked_in_shifted_up/ (lives_so_end + maturities + net_cumulative_critical_illness)  # Shape: (num_policies, num_months)
            elif jnp.all(rider_option ==1):
                ri_BEL_pp_at_locked_in_rate = discounted_ifrs_ri_bel_rev_locked_in_shifted_up / (lives_so_end + maturities)  # Shape: (num_policies, num_months)
            else:
                ri_BEL_pp_at_locked_in_rate = discounted_ifrs_ri_bel_rev_locked_in_shifted_up / (lives_so_end + maturities + net_cumulative_disability)  # Shape: (num_policies, num_months)
        else:
            ri_BEL_pp_at_locked_in_rate = discounted_ifrs_ri_bel_rev_locked_in_shifted_up / (lives_so_end + maturities)



        # Calculate RA @ locked in
        ifrs_ri_ra_locked_in = discounted_ifrs_ri_death_recovery_locked_in_shifted_up * additional_variables['IFRS17_RI_RA_Ratio']

        # Calculate RA PP @ locked in
        ifrs_ri_ra_pp_at_locked_in_rate = ri_death_recovery_pp_at_locked_in_rate * additional_variables['IFRS17_RI_RA_Ratio']

        # Calculate PV of RI Recov @ current rate
        ifrs_ri_death_recovery_rev_current_rate = ifrs_ri_death_recovery[:, ::-1]  # Reverse for backward calculation
        ri_death_recovery_discount_rates_rev_current_rate = ifrs_current_rate[::-1]  # Shape: (num_months,)

        # Function to discount cash flows for a single policy
        def discount_ri_death_recovery_current_rate(ri_death_recovery_rev):
            def discount_step(carry, inputs):
                discount_rate, ri_recovery = inputs
                pv_next = carry
                pv = (pv_next + ri_recovery) / (1 + discount_rate)
                return pv, pv

            init_carry = 0.0

            _, discounted_bel_cf_rev = lax.scan(
                discount_step,
                init_carry,
                (ri_death_recovery_discount_rates_rev_current_rate, ri_death_recovery_rev)
            )

            return discounted_bel_cf_rev

        # Apply the function to each policy
        discounted_ifrs_ri_death_recovery_rev_current_rate = jax.vmap(discount_ri_death_recovery_current_rate)(ifrs_ri_death_recovery_rev_current_rate)

        # Reverse back to original order
        discounted_ifrs_ri_death_recovery_current_rate = discounted_ifrs_ri_death_recovery_rev_current_rate[:, ::-1]

        discounted_ifrs_ri_death_recovery_current_rate_shifted_up = discounted_ifrs_ri_death_recovery_current_rate[:, 1:]

        discounted_ifrs_ri_death_recovery_current_rate_shifted_up = np.hstack([discounted_ifrs_ri_death_recovery_current_rate_shifted_up, np.zeros((discounted_ifrs_ri_death_recovery_current_rate.shape[0], 1))])

        # Calculate PV of RI Recov PP@ current rate
        
        if self.product in ['RIDER_CI', 'RIDER_ADB', 'RIDER_ATPD']:
            if jnp.all(rider_option == 2):
                ri_death_recovery_pp_at_current_rate = discounted_ifrs_ri_death_recovery_current_rate_shifted_up/ (lives_so_end + maturities + net_cumulative_critical_illness)  # Shape: (num_policies, num_months)
            elif jnp.all(rider_option ==1):
                ri_death_recovery_pp_at_current_rate = discounted_ifrs_ri_death_recovery_current_rate_shifted_up / (lives_so_end + maturities)  # Shape: (num_policies, num_months)
            else:
                ri_death_recovery_pp_at_current_rate = discounted_ifrs_ri_death_recovery_current_rate_shifted_up / (lives_so_end + maturities + net_cumulative_disability)  # Shape: (num_policies, num_months)
        else:
            ri_death_recovery_pp_at_current_rate = discounted_ifrs_ri_death_recovery_current_rate_shifted_up / (lives_so_end + maturities)


        # Calculate BEL @ current rate	
        ifrs_ri_bel_rev_current_rate = ifrs_ri_net_cf[:, ::-1]  # Reverse for backward calculation
        ri_bel_discount_rates_rev_current_rate = ifrs_current_rate[::-1]  # Shape: (num_months,)

        # Function to discount cash flows for a single policy
        def discount_ri_bel_current_rate(ri_bel_rev):
            def discount_step(carry, inputs):
                discount_rate, ri_bel = inputs
                pv_next = carry
                pv = (pv_next + ri_bel) / (1 + discount_rate)
                return pv, pv

            init_carry = 0.0

            _, discounted_bel_cf_rev = lax.scan(
                discount_step,
                init_carry,
                (ri_bel_discount_rates_rev_current_rate, ri_bel_rev)
            )

            return discounted_bel_cf_rev

        # Apply the function to each policy
        discounted_ifrs_ri_bel_rev_current_rate = jax.vmap(discount_ri_bel_current_rate)(ifrs_ri_bel_rev_current_rate)

        # Reverse back to original order
        discounted_ifrs_ri_bel_rev_current_rate = discounted_ifrs_ri_bel_rev_current_rate[:, ::-1]

        discounted_ifrs_ri_bel_rev_current_rate_shifted_up = discounted_ifrs_ri_bel_rev_current_rate[:, 1:]

        discounted_ifrs_ri_bel_rev_current_rate_shifted_up = np.hstack([discounted_ifrs_ri_bel_rev_current_rate_shifted_up, np.zeros((discounted_ifrs_ri_bel_rev_current_rate.shape[0], 1))])

        # Calculate BEL PP @ current rate
        
        if self.product in ['RIDER_CI', 'RIDER_ADB', 'RIDER_ATPD']:
            if jnp.all(rider_option == 2):
                ri_BEL_pp_at_current_rate = discounted_ifrs_ri_bel_rev_current_rate_shifted_up/ (lives_so_end + maturities + net_cumulative_critical_illness)  # Shape: (num_policies, num_months)
            elif jnp.all(rider_option ==1):
                ri_BEL_pp_at_current_rate = discounted_ifrs_ri_bel_rev_current_rate_shifted_up / (lives_so_end + maturities)  # Shape: (num_policies, num_months)
            else:
                ri_BEL_pp_at_current_rate = discounted_ifrs_ri_bel_rev_current_rate_shifted_up / (lives_so_end + maturities + net_cumulative_disability)  # Shape: (num_policies, num_months)
        else:
            ri_BEL_pp_at_current_rate = discounted_ifrs_ri_bel_rev_current_rate_shifted_up / (lives_so_end + maturities)


        # Calculate RA @ current rate	
        ifrs_ri_ra_current_rate = discounted_ifrs_ri_death_recovery_current_rate_shifted_up * additional_variables['IFRS17_RI_RA_Ratio']

        # Calculate RA PP @ current rate
        ifrs_ri_ra_pp_at_current_rate = ri_death_recovery_pp_at_current_rate * additional_variables['IFRS17_RI_RA_Ratio']

        # Coverage units BOP
        # Calculate RI SA IF

        if self.product == 'RIDER_ATPD':
            ifrs_ri_sa_bop = (tpd_benefit + wop_benefit) * ifrs_no_of_policies_at_per_end
        else:
            ifrs_ri_sa_bop = reins_sum_assured * ifrs_no_of_policies_at_per_end

        # Calculate PV RI SA IF
        ifrs_ri_sa_rev_bop = ifrs_ri_sa_bop[:, ::-1]  # Reverse for backward calculation
        ri_sa_discount_rates_rev_bop = ifrs_locked_in_rate[::-1]  # Shape: (num_months,)

        # Function to discount cash flows for a single policy
        def discount_ri_sa_locked_in_rate(ri_sa_rev):
            def discount_step(carry, inputs):
                discount_rate, ri_sa = inputs
                pv_next = carry
                pv = (pv_next + ri_sa) / (1 + discount_rate)
                return pv, pv

            init_carry = 0.0

            _, discounted_bel_cf_rev = lax.scan(
                discount_step,
                init_carry,
                (ri_sa_discount_rates_rev_bop, ri_sa_rev)
            )

            return discounted_bel_cf_rev

        # Apply the function to each policy
        discounted_ifrs_ri_sa_rev_bop = jax.vmap(discount_ri_sa_locked_in_rate)(ifrs_ri_sa_rev_bop)

        # Reverse back to original order
        discounted_ifrs_ri_sa_bop = discounted_ifrs_ri_sa_rev_bop[:, ::-1]

        discounted_ifrs_ri_sa_bop_shifted_up = discounted_ifrs_ri_sa_bop[:, 1:]

        discounted_ifrs_ri_sa_bop_shifted_up = np.hstack([discounted_ifrs_ri_sa_bop_shifted_up, np.zeros((discounted_ifrs_ri_sa_bop.shape[0], 1))])

        # Coverage units EOP
        # Calculate RI SA IF
        if self.product == 'RIDER_ATPD':
            ifrs_ri_sa_eop = (tpd_benefit + wop_benefit) * ifrs_no_of_policies_at_val_date
        else:
            ifrs_ri_sa_eop = reins_sum_assured * ifrs_no_of_policies_at_val_date

        #ifrs_ri_sa_eop = reins_sum_assured * ifrs_no_of_policies_at_val_date
        ifrs_ri_sa_eop = ifrs_ri_sa_eop.at[:,:1].set(0.0)  # To match at Seriatim level

        # Calculate PV RI SA IF
        ifrs_ri_sa_rev_eop = ifrs_ri_sa_eop[:, ::-1]  # Reverse for backward calculation
        ri_sa_discount_rates_rev_eop = ifrs_locked_in_rate[::-1]  # Shape: (num_months,)

        # Function to discount cash flows for a single policy
        def discount_ri_sa_locked_in_rate_eop(ri_sa_rev):
            def discount_step(carry, inputs):
                discount_rate, ri_sa = inputs
                pv_next = carry
                pv = (pv_next + ri_sa) / (1 + discount_rate)
                return pv, pv

            init_carry = 0.0

            _, discounted_bel_cf_rev = lax.scan(
                discount_step,
                init_carry,
                (ri_sa_discount_rates_rev_eop, ri_sa_rev)
            )

            return discounted_bel_cf_rev

        # Apply the function to each policy
        discounted_ifrs_ri_sa_rev_eop = jax.vmap(discount_ri_sa_locked_in_rate_eop)(ifrs_ri_sa_rev_eop)

        # Reverse back to original order
        discounted_ifrs_ri_sa_eop = discounted_ifrs_ri_sa_rev_eop[:, ::-1]

        discounted_ifrs_ri_sa_eop_shifted_up = discounted_ifrs_ri_sa_eop[:, 1:]

        discounted_ifrs_ri_sa_eop_shifted_up = np.hstack([discounted_ifrs_ri_sa_eop_shifted_up, np.zeros((discounted_ifrs_ri_sa_eop.shape[0], 1))])

        # Calculate Acc Future RI Cashflows (w/o discounting)
        ifrs_acc_future_ri_cashflows = jnp.cumsum(ifrs_ri_net_cf[:, ::-1], axis=1)[:, ::-1]

        # Calculate Acc Future RI Cashflows PP (w/o discounting)
        
        if self.product in ['RIDER_CI', 'RIDER_ADB', 'RIDER_ATPD']:
            if jnp.all(rider_option == 2):
                ifrs_acc_future_ri_cashflows_pp = ifrs_acc_future_ri_cashflows/ (lives_so_end + maturities + net_cumulative_critical_illness)  # Shape: (num_policies, num_months)
            elif jnp.all(rider_option ==1):
                ifrs_acc_future_ri_cashflows_pp = ifrs_acc_future_ri_cashflows / (lives_so_end + maturities)  # Shape: (num_policies, num_months)
            else:
                ifrs_acc_future_ri_cashflows_pp = ifrs_acc_future_ri_cashflows / (lives_so_end + maturities + net_cumulative_disability)  # Shape: (num_policies, num_months)
        else:
            ifrs_acc_future_ri_cashflows_pp = ifrs_acc_future_ri_cashflows / (lives_so_end + maturities)



        # Calculate PV of RI Death Recovery
        # same as PV of RI Death Recovery @ locked in rate

        # Calculate PV of Total Death Outgo
        ifrs_total_outgo_rev = ifrs_death_benefits[:, ::-1]  # Reverse for backward calculation
        total_outgo_discount_rates_rev = ifrs_locked_in_rate[::-1]  # Shape: (num_months,)

        # Function to discount cash flows for a single policy
        def discount_total_outgo_locked_in_rate(total_outgo_rev):
            def discount_step(carry, inputs):
                discount_rate, ri_sa = inputs
                pv_next = carry
                pv = (pv_next + ri_sa) / (1 + discount_rate)
                return pv, pv

            init_carry = 0.0

            _, discounted_bel_cf_rev = lax.scan(
                discount_step,
                init_carry,
                (total_outgo_discount_rates_rev, total_outgo_rev)
            )

            return discounted_bel_cf_rev

        # Apply the function to each policy
        discounted_ifrs_total_outgo_rev = jax.vmap(discount_total_outgo_locked_in_rate)(ifrs_total_outgo_rev)

        # Reverse back to original order
        discounted_ifrs_total_outgo = discounted_ifrs_total_outgo_rev[:, ::-1]

        discounted_ifrs_total_outgo_shifted_up = discounted_ifrs_total_outgo[:, 1:]

        discounted_ifrs_total_outgo_shifted_up = np.hstack([discounted_ifrs_total_outgo_shifted_up, np.zeros((discounted_ifrs_total_outgo.shape[0], 1))])

        # Caclulate PV Premium
        ifrs_premium_rev = ifrs_premiums_reshape[:, ::-1]  # Reverse along the second axis (columns)
        premium_discount_rates_rev = ifrs_locked_in_rate[::-1]  # Shape: (num_months,)

        # Function to discount cash flows for a single policy
        def discount_premium_locked_in_rate(premium_rev):
            def discount_step(carry, inputs):
                discount_rate, prem = inputs
                pv_next = carry
                pv = (pv_next / (1 + discount_rate)) + prem
                return pv, pv

            init_carry = 0.0

            _, discounted_bel_cf_rev = lax.scan(
                discount_step,
                init_carry,
                (premium_discount_rates_rev, premium_rev)
            )

            return discounted_bel_cf_rev

        # Apply the function to each policy
        discounted_ifrs_prem_rev = jax.vmap(discount_premium_locked_in_rate)(ifrs_premium_rev)

        # Reverse back to original order
        discounted_ifrs_prem = discounted_ifrs_prem_rev[:, ::-1]

        discounted_ifrs_prem_shifted_up = discounted_ifrs_prem[:, 1:]

        discounted_ifrs_prem_shifted_up = np.hstack([discounted_ifrs_prem_shifted_up, np.zeros((discounted_ifrs_prem.shape[0], 1))])

        # Calculate PV Maint Exp
        ifrs_maint_exp_rev = combined_renewal_expenses[:, ::-1]  # Reverse for backward calculation
        maint_exp_discount_rates_rev = ifrs_locked_in_rate[::-1]  # Shape: (num_months,)

        # Function to discount cash flows for a single policy
        def discount_maint_exp_locked_in_rate(maint_exp_rev):
            def discount_step(carry, inputs):
                discount_rate, exp = inputs
                pv_next = carry
                pv = (pv_next / (1 + discount_rate)) + exp
                return pv, pv

            init_carry = 0.0

            _, discounted_bel_cf_rev = lax.scan(
                discount_step,
                init_carry,
                (maint_exp_discount_rates_rev, maint_exp_rev)
            )

            return discounted_bel_cf_rev

        # Apply the function to each policy
        discounted_ifrs_maint_exp_rev = jax.vmap(discount_maint_exp_locked_in_rate)(ifrs_maint_exp_rev)

        # Reverse back to original order
        discounted_ifrs_maint_exp = discounted_ifrs_maint_exp_rev[:, ::-1]

        discounted_ifrs_maint_exp_shifted_up = discounted_ifrs_maint_exp[:, 1:]

        discounted_ifrs_maint_exp_shifted_up = np.hstack([discounted_ifrs_maint_exp_shifted_up, np.zeros((discounted_ifrs_maint_exp.shape[0], 1))])

        # Calculate Seriatim Variables
        # RA_Onerosity
        ifrs_ra_onerous_seriatim = discounted_death_benefit_onerous * additional_variables['IFRS17_RA_Ratio']



        # Calculate GCL Variables
        # Calculate PV Ins Outgo @ Locked-in rate PP 
        ifrs_outgo_pp_at_locked_in_rate = discounted_death_benefit_at_locked_in_rate / (lives_so_end)

        # Calculate PV Outgo PP @ Current
        outgo_pp_at_current_rate = discounted_death_benefit_at_current_rate / (lives_so_end)

        # Calculate PV Prem
        gcl_ifrs_premium_rev = ifrs_premiums_reshape[:, ::-1]  # Reverse along the second axis (columns)
        gcl_premium_discount_rates_rev = ifrs_locked_in_rate[::-1]  # Shape: (num_months,)

        # Function to discount cash flows for a single policy
        def discount_gcl_premium_locked_in_rate(premium_rev):
            def discount_step(carry, inputs):
                discount_rate, prem = inputs
                pv_next = carry
                pv = (pv_next + (prem * (1 + discount_rate))) / (1 + discount_rate)
                return pv, pv

            init_carry = 0.0

            _, discounted_bel_cf_rev = lax.scan(
                discount_step,
                init_carry,
                (gcl_premium_discount_rates_rev, premium_rev)
            )

            return discounted_bel_cf_rev

        # Apply the function to each policy
        gcl_discounted_ifrs_prem_rev = jax.vmap(discount_gcl_premium_locked_in_rate)(gcl_ifrs_premium_rev)

        # Reverse back to original order
        gcl_discounted_ifrs_prem = gcl_discounted_ifrs_prem_rev[:, ::-1]

        # Calculate PV Outgo PP @ Onerosity rate
        ifrs_outgo_pp_at_onerous_rate = discounted_death_benefit_onerous /  (lives_so_end)

        # Calculate PV Claim CFs at locked in rate
        gcl_ifrs_claim_cf = ifrs_death_benefits + ifrs_surrender_benefits
        gcl_ifrs_claim_cf_rev = gcl_ifrs_claim_cf[:, ::-1]  # Reverse along the second axis (columns)
        gcl_claim_discount_rates_rev = ifrs_locked_in_rate[::-1]  # Shape: (num_months,)

        # Function to discount cash flows for a single policy
        def discount_gcl_claim_locked_in_rate(claim_rev):
            def discount_step(carry, inputs):
                discount_rate, claim = inputs
                pv_next = carry
                pv = (pv_next + claim) / (1 + discount_rate)
                return pv, pv

            init_carry = 0.0

            _, discounted_bel_cf_rev = lax.scan(
                discount_step,
                init_carry,
                (gcl_claim_discount_rates_rev, claim_rev)
            )

            return discounted_bel_cf_rev

        # Apply the function to each policy
        gcl_discounted_ifrs_claim_rev = jax.vmap(discount_gcl_claim_locked_in_rate)(gcl_ifrs_claim_cf_rev)

        # Reverse back to original order
        gcl_discounted_ifrs_claim = gcl_discounted_ifrs_claim_rev[:, ::-1]

        # Calculate Commission
        gcl_ifrs_commission =  base_results['be_results']['be_commissions'] * ifrs17_init.ifrs17_multiplier_initial_commission

        # Calculate PV of Commission at locked in rate
        gcl_ifrs_commission_cf_rev = gcl_ifrs_commission[:, ::-1]  # Reverse along the second axis (columns)
        gcl_commisssion_discount_rates_rev = ifrs_locked_in_rate[::-1]  # Shape: (num_months,)

        # Function to discount cash flows for a single policy
        def discount_gcl_commisssion_locked_in_rate(commission_rev):
            def discount_step(carry, inputs):
                discount_rate, commission = inputs
                pv_next = carry
                pv = (pv_next + (commission * (1 + discount_rate)) ) / (1 + discount_rate)
                return pv, pv

            init_carry = 0.0

            _, discounted_bel_cf_rev = lax.scan(
                discount_step,
                init_carry,
                (gcl_commisssion_discount_rates_rev, commission_rev)
            )

            return discounted_bel_cf_rev

        # Apply the function to each policy
        gcl_discounted_ifrs_commission_rev = jax.vmap(discount_gcl_commisssion_locked_in_rate)(gcl_ifrs_commission_cf_rev)

        # Reverse back to original order
        gcl_discounted_ifrs_commission = gcl_discounted_ifrs_commission_rev[:, ::-1]

        # Calculate PV Expense CFs at locked in rate
        gcl_ifrs_maint_exp_rev = combined_renewal_expenses[:, ::-1]  # Reverse for backward calculation
        gcl_maint_exp_discount_rates_rev = ifrs_locked_in_rate[::-1]  # Shape: (num_months,)

        # Function to discount cash flows for a single policy
        def discount_maint_exp_locked_in_rate(maint_exp_rev):
            def discount_step(carry, inputs):
                discount_rate, exp = inputs
                pv_next = carry
                pv = (pv_next + (exp * (1 + discount_rate))) / (1 + discount_rate)
                return pv, pv

            init_carry = 0.0

            _, discounted_bel_cf_rev = lax.scan(
                discount_step,
                init_carry,
                (gcl_maint_exp_discount_rates_rev, maint_exp_rev)
            )

            return discounted_bel_cf_rev

        # Apply the function to each policy
        gcl_discounted_ifrs_maint_exp_rev = jax.vmap(discount_maint_exp_locked_in_rate)(gcl_ifrs_maint_exp_rev)

        # Reverse back to original order
        gcl_discounted_ifrs_maint_exp = gcl_discounted_ifrs_maint_exp_rev[:, ::-1]




        ifrs_output['IFRS17_Policy_Number'] = policy_numbers.flatten()
        ifrs_output['IFRS17_Policy_Months'] = policy_months.flatten()
        ifrs_output['IFRS17_Calendar_Month'] = calendar_months.flatten()
        ifrs_output['IFRS17_Projection_Step'] = projection_steps.flatten()
        ifrs_output['IFRS17_Current_Rate'] = ifrs_current_rate_array.flatten()
        ifrs_output['IFRS17_Locked_In_Rate'] = ifrs_locked_in_rate_array.flatten()
        ifrs_output['IFRS17_Onerous_Tagging_CCIL_Rate'] = ifrs_ccil_rate_array.flatten()
        ifrs_output['IFRS17_Lives_Beginning'] = lives_so_begin.flatten()
        ifrs_output['IFRS17_Deaths'] = deaths.flatten()
        ifrs_output['IFRS17_Lapses'] = lapses.flatten()
        ifrs_output['IFRS17_Maturities'] = maturities.flatten()
        ifrs_output['IFRS17_Lives_End'] = lives_so_end.flatten()
        ifrs_output['IFRS17_premiums'] = ifrs_premiums
        ifrs_output['IFRS17_Insurance_Component_Outgo'] = Insurance_Component_Outgo.flatten()   
        ifrs_output['IFRS17_Investment_Component_Outgo'] = Investment_Component_Outgo.flatten()
        ifrs_output['IFRS17_Acquisiton_Expenses_(incl initial commission)'] = ifrs_initial_expenses.flatten()
        ifrs_output['IFRS17_Maintenance_Expenses_(incl renewal commission)'] = combined_renewal_expenses.flatten()
        ifrs_output['IFRS17_Claim_Expense'] = ifrs_claim_expense.flatten()
        ifrs_output['IFRS17_BEL_CF'] = ifrs_bel_cf.flatten()
        ifrs_output['IFRS17_BEL_at_Onerous_Tagging_Rate'] = discounted_bel_at_onerous_tagging_rate_shifted_up.flatten()
        ifrs_output['IFRS17_BEL_PP_at_Onerous_Tagging_Rate'] = bel_pp_at_onerous_tagging_rate.flatten()
        ifrs_output['IFRS17_Lapse_Up'] = crnhr_lapse_up_rc.flatten()
        ifrs_output['IFRS17_Lapse_Down'] = crnhr_lapse_down_rc.flatten()
        ifrs_output['IFRS17_Mass_Lapse'] = crnhr_mass_lapse_rc.flatten()
        ifrs_output['IFRS17_Lapse'] = crnhr_lapse_rc.flatten()
        ifrs_output['IFRS17_Mortality'] = crnhr_mortality_rc.flatten()

        if self.product_name.upper() in self.RIDER_TYPES:
            ifrs_output['IFRS17_Morbidity'] = crnhr_morbidity_rc.flatten()

        ifrs_output['IFRS17_Expense'] = crnhr_expense_rc.flatten()
        ifrs_output['IFRS17_CAT'] = crnhr_cat_rc.flatten()
        ifrs_output['IFRS17_Diversified_Risk_Capital'] = crnhr_diversified_caps.flatten()
        ifrs_output['IFRS17_Cost_of_Economic_Capital'] = crnhr_economic_capital_monthly.flatten()
        ifrs_output['IFRS17_PV_CRNHR'] = crnhr_pv_crnhr.flatten()
        ifrs_output['IFRS17_PV_of_Expenses'] = discounted_expenses_shifted_up.flatten()
        ifrs_output['IFRS17_Adjusted_px'] = adj_px.flatten()
        ifrs_output['IFRS17_Base_DF'] = base_df_array.flatten()
        ifrs_output['IFRS17_Stress_DF'] = stress_df_array.flatten()
        ifrs_output['IFRS17_Annuity_Factor_Base'] = annuity_factors_base_array.flatten()
        ifrs_output['IFRS17_Annuity_Factor_Stress'] = annuity_factors_stress_array.flatten()
        ifrs_output['IFRS17_Extra_Inflation'] = ifrs_stress_inflation_array.flatten()
        ifrs_output['IFRS17_Stressed_Expenses'] = ifrs_stress_expense.flatten()
        ifrs_output['IFRS17_PV_of_Stressed_expenses'] = discounted_stress_expenses_shifted_up.flatten()
        ifrs_output['IFRS17_Expense_Capital'] = ifrs_expense_captial.flatten()
        ifrs_output['IFRS17_(BEL+ RA)_for_Onerosity'] = bel_ra_onerous.flatten()
        ifrs_output['IFRS17_PV_Ins_Outgo_@_Onerosity_rate'] = discounted_death_benefit_onerous_shifted_up.flatten()
        ifrs_output['IFRS17_PV_Ins_Outgo_@_Locked-in rate'] = discounted_death_benefit_at_locked_in_rate_shifted_up.flatten()
        ifrs_output['IFRS17_PV_Outgo_@_Locked-in'] = discounted_outgo_at_locked_in_rate_shifted_up.flatten()
        ifrs_output['IFRS17_PV_Outgo_PP_@_Locked-in'] = outgo_pp_at_locked_in_rate.flatten()
        ifrs_output['IFRS17_BEL_@_Locked-in'] = discounted_bel_at_locked_in_rate_shifted_up.flatten()
        ifrs_output['IFRS17_BEL_PP_@_Locked-in'] = bel_pp_at_locked_in_rate.flatten()
        ifrs_output['IFRS17_RA_@_Locked-in'] = ifrs_ra_locked_in.flatten()
        ifrs_output['IFRS17_RA_PP_@_Locked-in'] = ifrs_ra_pp_at_locked_in_rate.flatten()
        ifrs_output['IFRS17_PV_Ins_Outgo_@_Current_rate'] = discounted_death_benefit_at_current_rate_shifted_up.flatten()
        ifrs_output['IFRS17_PV_Ins_Outgo_PP_@_Current_rate'] = ifrs_outgo_pp_at_current_rate.flatten()
        ifrs_output['IFRS17_BEL_@_Current'] = discounted_bel_at_current_rate_shifted_up.flatten()
        ifrs_output['IFRS17_BEL_PP_@_Current'] = bel_pp_at_current_rate.flatten()
        ifrs_output['IFRS17_RA_PP_@_Current'] = ifrs_ra_pp_at_current_rate.flatten()
        ifrs_output['IFRS17_No._of_Policies_at_Per_End'] = ifrs_no_of_policies_at_per_end.flatten()
        ifrs_output['IFRS17_Death_Benefit_IF'] = ifrs_death_benefits_IF.flatten()
        ifrs_output['IFRS17_PV_Coverage_Units_@_Locked-In'] = discounted_cu_at_locked_in_rate_shifted_up.flatten()
        ifrs_output['IFRS17_No._of_Policies_at_Val_Date'] = ifrs_no_of_policies_at_val_date.flatten()
        ifrs_output['IFRS17_Death_Benefit_IF_as_at_val_end'] = ifrs_death_benefits_IF_val_end.flatten()
        ifrs_output['IFRS17_PV_Coverage_Units_at_Val_date_@_Locked-In'] = discounted_cu_at_locked_in_rate_val_end_shifted_up.flatten()
        ifrs_output['IFRS17_Acc_Future_Cashflows_(w/o discounting)'] = ifrs_acc_future_cashflows.flatten()
        ifrs_output['IFRS17_Acc_Future_Cashflows_PP_(w/o discounting)'] = ifrs_acc_future_cashflows_pp.flatten()
        ifrs_output['IFRS17_Acq_CFs_at_locked_in_rate'] = discounted_ifrs_acq_cf_locked_in.flatten()
        ifrs_output['IFRS17_RI_Premium_Outgo'] = ifrs_ri_premium_outgo.flatten()
        ifrs_output['IFRS17_RI_Death_Recovery'] = ifrs_ri_death_recovery.flatten()
        ifrs_output['IFRS17_RI_Net_CF'] = ifrs_ri_net_cf.flatten()
        ifrs_output['IFRS17_PV_of_RI_Recov_@_locked_in'] = discounted_ifrs_ri_death_recovery_locked_in_shifted_up.flatten()
        ifrs_output['IFRS17_PV_of_RI_Recov_PP_@_locked_in'] = ri_death_recovery_pp_at_locked_in_rate.flatten()
        ifrs_output['IFRS17_BEL_@_locked_in(net_cf)_RI'] = discounted_ifrs_ri_bel_rev_locked_in_shifted_up.flatten()
        ifrs_output['IFRS17_BEL_PP_@_Locked_in(net_cf)_RI'] = ri_BEL_pp_at_locked_in_rate.flatten()
        ifrs_output['IFRS17_RA_@_Locked_in_RI'] = ifrs_ri_ra_locked_in.flatten()
        ifrs_output['IFRS17_RA_PP_@_locked_in_RI'] = ifrs_ri_ra_pp_at_locked_in_rate.flatten()
        ifrs_output['IFRS17_PV_of_RI_Recov_@_current_rate'] = discounted_ifrs_ri_death_recovery_current_rate_shifted_up.flatten()
        ifrs_output['IFRS17_PV_of_RI_Recov_PP_@_current_rate'] = ri_death_recovery_pp_at_current_rate.flatten()
        ifrs_output['IFRS17_BEL_@_current_rate_RI'] = discounted_ifrs_ri_bel_rev_current_rate_shifted_up.flatten()
        ifrs_output['IFRS17_BEL_PP_@_current_rate_RI'] = ri_BEL_pp_at_current_rate.flatten()
        ifrs_output['IFRS17_RA_@_current_rate_RI'] = ifrs_ri_ra_current_rate.flatten()
        ifrs_output['IFRS17_RA_PP_@_current_rate_RI'] = ifrs_ri_ra_pp_at_current_rate.flatten()
        ifrs_output['IFRS17_RI_SA_IF_BOP'] = ifrs_ri_sa_bop.flatten()
        ifrs_output['IFRS17_PV_RI_SA_IF_BOP'] = discounted_ifrs_ri_sa_bop_shifted_up.flatten()
        ifrs_output['IFRS17_RI_SA_IF_EOP'] = ifrs_ri_sa_eop.flatten()
        ifrs_output['IFRS17_PV_RI_SA_IF_EOP'] = discounted_ifrs_ri_sa_eop_shifted_up.flatten()
        ifrs_output['IFRS17_Acc_Future_RI_Cashflows_(w/o discounting)'] = ifrs_acc_future_ri_cashflows.flatten()
        ifrs_output['IFRS17_Acc_Future_RI_Cashflows_PP_(w/o discounting)'] = ifrs_acc_future_ri_cashflows_pp.flatten()
        ifrs_output['IFRS17_PV_of_RI_Death_Recovery'] = discounted_ifrs_ri_death_recovery_locked_in_shifted_up.flatten()
        ifrs_output['IFRS17_PV_of_Total_Death_Outgo'] = discounted_ifrs_total_outgo_shifted_up.flatten()
        ifrs_output['IFRS17_PV_Premium'] = discounted_ifrs_prem_shifted_up.flatten()
        ifrs_output['IFRS17_PV_Maint_Exp'] = discounted_ifrs_maint_exp_shifted_up.flatten()
        ifrs_output['IFRS17_RA_Onerosity_Seriatim'] = ifrs_ra_onerous_seriatim.flatten()
        ifrs_output['IFRS17_Annual_Locked_In_Rate_Dur_M_Seriatim'] = ifrs_annual_locked_in_rate # for seriatim

        if self.product_name.upper() == 'GCL':
            ifrs_output['IFRS17_PV_Ins_Outgo_@_Locked_in_rate_PP'] = ifrs_outgo_pp_at_locked_in_rate.flatten()
            ifrs_output['IFRS17_PV_Outgo_@_Current'] = discounted_death_benefit_at_current_rate.flatten()
            ifrs_output['IFRS17_PV_Outgo_PP_@_Current'] = outgo_pp_at_current_rate.flatten()
            ifrs_output['IFRS17_RA_@_Current'] = ifrs_ra_pp_at_current_rate.flatten()
            ifrs_output['IFRS17_PV_Claim'] = discounted_death_benefit_at_locked_in_rate_shifted_up.flatten()
            ifrs_output['IFRS17_PV_Prem'] = gcl_discounted_ifrs_prem.flatten()
            ifrs_output['IFRS17_PV_Acq_Exp'] = discounted_ifrs_acq_cf_locked_in.flatten()
            ifrs_output['IFRS17_PV_Outgo_PP_@_Onerosity_rate'] = ifrs_outgo_pp_at_onerous_rate.flatten()
            ifrs_output['IFRS17_PV_Claim_CFs_at_locked_in_rate'] = gcl_discounted_ifrs_claim.flatten()
            ifrs_output['IFRS17_Commission'] = gcl_ifrs_commission.flatten()
            ifrs_output['IFRS17_PV_of_Comm'] = gcl_discounted_ifrs_commission.flatten()
            ifrs_output['IFRS17_PV_Expense_CFs_at_locked_in_rate'] = gcl_discounted_ifrs_maint_exp.flatten()

        return ifrs_output