# src/policy_data.py
import jax
import pandas as pd, numpy as np
import jax.numpy as jnp
from abc import ABC, abstractmethod
from typing import List, Dict, Any
from datetime import datetime
from pathlib import Path
from src.config import TableIndex, RunConfig
from src.jax_config import FLOAT_DTYPE, INT_DTYPE
from datetime import datetime


_POLICY_DATA_TABLE_MAPPING = {
    'BASE_TERM': 'Policy_Data_Term',
    'RIDER_ADB': 'Policy_Data_ADB',
    'RIDER_CI': 'Policy_Data_CI',
    'RIDER_ATPD': 'Policy_Data_ATPD',
    'GCL': 'Policy_Data_GCL'
}

def get_policy_data_table_name(product_name: str) -> str:
    """Get the table name for a given product's policy data.
    
    Args:
        product_name (str): The name of the product (case insensitive)
        
    Returns:
        str: The corresponding table name for the product's policy data
        
    Raises:
        ValueError: If the product name is not recognized
    """
    product_key = product_name.upper()
    if product_key not in _POLICY_DATA_TABLE_MAPPING:
        raise ValueError(f"Unknown product type: {product_name}")
    return _POLICY_DATA_TABLE_MAPPING[product_key]


class BasePolicyData(ABC):
    def __init__(self, policy_data_file: str, table_index: TableIndex, config: RunConfig):
        self.policy_data_file = policy_data_file
        self.table_index = table_index
        self.root_folder = config.root_folder
        self.valuation_date = config.valuation_date
        self.config = config
        self.data = None
        self.policy_df = None

    def pricing_override(self):
        self.data['Duration_in_Months'] = jnp.zeros_like(self.data['Duration_in_Months'])
        self.policy_df['Policy Start Date'] = self.valuation_date

    @abstractmethod
    def load_data(self):
        pass

    @abstractmethod
    def preprocess_data(self):
        pass

class GCLPolicyData(BasePolicyData):
    def __init__(self, policy_data_file: str, table_index: TableIndex, config: RunConfig):
        # Call the parent constructor so that self.config is set
        super().__init__(policy_data_file, table_index, config)
        self.data = {}
        self.policy_numbers = None
        
    def load_data(self):
        self.policy_df = self.table_index.read_table(self.policy_data_file)

    def load_bplan_premiums(self):
        self.bplan_prem_df = self.table_index.read_table('Bplan_Premiums')
        self.bplan_prem_df['Month'] = self.bplan_prem_df['Month'].astype(str)
        self.bplan_prem_df['Year'] = self.bplan_prem_df['Year'].astype(str)
        self.bplan_prem_df['Prem_Allocation'] = self.bplan_prem_df['BASE_TERM'].astype(FLOAT_DTYPE)

    def preprocess_data(self):
        df = self.policy_df
        df.columns = df.columns.str.replace(' ','_')

        # Additional fields from prompt:
        # Mortality - IALM loading vs flat dedn (assume column name: Mortality_-_IALM_loading_vs_flat_dedn)
        # Convert it to integer flag:
        df['Mortality_Flag'] = df['Mortality_-_IALM_loading_vs_flat_dedn'].fillna(0).astype(INT_DTYPE)

        # Moratorium_Period_(months), Interest_Accrue, Reducing_SA are already present, ensure numeric:
        numeric_cols = ['Premium','Loan_Amount','EMI_amount','Interest_Rate','Age_at_Policy_Start','Policy_Term_(Years)','PT_(Month)','Moratorium_Period_(months)','Reducing_SA','Mortality_Flag']
        for c in numeric_cols:
            df[c]=pd.to_numeric(df[c],errors='coerce').astype(FLOAT_DTYPE)

        # Convert 'Interest_Accrue' and 'Mode' also to numeric if not already:
        df['Interest_Accrue'] = pd.to_numeric(df['Interest_Accrue'],errors='coerce').fillna(0).astype(INT_DTYPE)
        df['Mode'] = pd.to_numeric(df['Mode'],errors='coerce').fillna(1).astype(INT_DTYPE)

        # Gender/Smoker map as before:
        GENDER_MAP = {'M':0,'F':1}
        SMOKER_MAP = {'NS':0,'S':1}
        df['Gender_Code'] = df['Gender'].map(GENDER_MAP).fillna(1).astype(INT_DTYPE)
        df['Smoking_Status_Code'] = df['Smoker'].map(SMOKER_MAP).fillna(0).astype(INT_DTYPE)
        if self.config.run_type == 'BusinessPlanning':
            df = self.bplan_columns(df)

        # Duration_in_Months=0 (no start date given)
        # df['Duration_in_Months']=0
        # df['Distribution_Channel']=1

        def calculate_month_difference(start_date, end_date):
            start_date = datetime.strptime(start_date, "%d-%m-%Y").date()
            delta_years = end_date.year - start_date.year
            delta_months = end_date.month - start_date.month
            delta_days = end_date.day - start_date.day
            total_months = delta_years * 12 + delta_months
            # If the day difference is negative, subtract one month
            # if delta_days < 0:
            #   total_months -= 1
            # return max(total_months + 1, 0)
            return (total_months+1)
        # Calculate Duration_in_Months
        df['Duration_in_Months'] = df.apply(
            lambda row: calculate_month_difference(row['Policy_start_date'], self.valuation_date),
            axis=1
        ).astype(INT_DTYPE)
        # Ensure no negative durations
        # df['Duration_in_Months'] = df['Duration_in_Months'].clip(lower=0).astype(INT_DTYPE)

        # Store arrays
        self.data['Policy_Term'] = jnp.array(df['Policy_Term_(Years)'],dtype=FLOAT_DTYPE)
        self.data['Premium'] = jnp.array(df['Premium'],dtype=FLOAT_DTYPE)
        self.data['Loan_Amount'] = jnp.array(df['Loan_Amount'],dtype=FLOAT_DTYPE)
        self.data['EMI_amount'] = jnp.array(df['EMI_amount'],dtype=FLOAT_DTYPE)
        self.data['Interest_Rate'] = jnp.array(df['Interest_Rate'],dtype=FLOAT_DTYPE)
        self.data['Mode'] = jnp.array(df['Mode'],dtype=INT_DTYPE)
        self.data['Age_at_Policy_Start'] = jnp.array(df['Age_at_Policy_Start'],dtype=INT_DTYPE)
        self.data['Moratorium_Period_(months)'] = jnp.array(df['Moratorium_Period_(months)'],dtype=INT_DTYPE)
        self.data['Interest_Accrue'] = jnp.array(df['Interest_Accrue'],dtype=INT_DTYPE)
        self.data['Reducing_SA'] = jnp.array(df['Reducing_SA'],dtype=INT_DTYPE)
        self.data['EMR_(Extra_mortality_Rate)'] = jnp.array(df['EMR_(Extra_mortality_Rate)'],dtype=FLOAT_DTYPE)
        self.data['Mortality_Flag'] = jnp.array(df['Mortality_Flag'],dtype=INT_DTYPE)
        self.data['Gender_Code'] = jnp.array(df['Gender_Code'],dtype=INT_DTYPE)
        self.data['Smoking_Status_Code'] = jnp.array(df['Smoking_Status_Code'],dtype=INT_DTYPE)
        self.data['Duration_in_Months'] = jnp.array(df['Duration_in_Months'],dtype=INT_DTYPE)
        self.data['Moratorium_Period_ind'] = np.maximum(0,self.data['Moratorium_Period_(months)']-self.data['Duration_in_Months'])
        self.data['Distribution_Channel'] = jnp.array(df['Distribution_Channel'],dtype=INT_DTYPE)
        if self.config.run_type == 'BusinessPlanning':
            self.data['no_of_pol'] = jnp.array(df['no_of_pol'].values, dtype=FLOAT_DTYPE)
            self.sales_key = df['key'].values
        else:
            self.sales_key = None

        # Compute monthly loan outstanding schedule (Loan_Schedule) if needed
        # If Reducing_SA=1, loan reduces monthly:
        # loan(t)=max(loan(t-1)*(1+Interest_Rate/12 * Interest_Accrue)-EMI*(t>=Moratorium?),0)
        # If Reducing_SA=0 => loan remains level=Loan_Amount
        # We'll compute here and store in self.data['Loan_Schedule'].

        num_policies = df.shape[0]
        projection_months = self.config.projection_term*12
        loan_amount = self.data['Loan_Amount']
        interest_rate = self.data['Interest_Rate']
        emi = self.data['EMI_amount']
        moratorium = self.data['Moratorium_Period_ind']
        interest_accrue = self.data['Interest_Accrue']
        red_flag = self.data['Reducing_SA']

        # Initialize a jnp array for loan schedule:
        loan_schedule = jnp.zeros((num_policies,projection_months),dtype=FLOAT_DTYPE)
        loan_schedule = loan_schedule.at[:,0].set(loan_amount)

        def update_loan(carry, x):
            # x=month index
            prev_loan = carry
            # pay_emi if x>=moratorium
            pay_emi = (x>=moratorium[:,None]).astype(FLOAT_DTYPE)
            new_loan = jnp.where(red_flag[:,None]==1,
                                 jnp.maximum(prev_loan*(1+interest_rate[:,None]/12*interest_accrue[:,None]) - emi[:,None]*pay_emi,0.0),
                                 loan_amount[:,None])
            return new_loan,new_loan

        _,loan_out = jax.lax.scan(update_loan, loan_schedule[:,[0]], jnp.arange(1,projection_months))
        loan_out = loan_out.swapaxes(0,1)[:,:,0]
        loan_schedule = loan_schedule.at[:,1:].set(loan_out)
        self.data['Loan_Schedule'] = loan_schedule
        indices = self.data['Duration_in_Months']
        row_indices = jnp.arange(loan_schedule.shape[0])
        loan_os = loan_schedule[row_indices, indices]
        self.data['loan_os'] = loan_os

        self.policy_numbers = df['Policy_ID'].values

    def bplan_columns(self, df):
        df['Weights'] = df['Weights'].astype(FLOAT_DTYPE)
        self.load_bplan_premiums()
        df['Year'] = df['Year'].astype(str)
        df['Month'] = df['Month'].astype(str)
        df['key'] = df['Year'] + '_' + df['Month']
        self.bplan_prem_df['key'] = self.bplan_prem_df['Year'] + '_' + self.bplan_prem_df['Month']
        df = df.merge(self.bplan_prem_df[['key', 'Prem_Allocation']], on='key', how='left')
        df['no_of_pol'] = (df['Prem_Allocation']/df['Premium'])*df['Weights']*(1_00_00_000)
        return df


class TermPolicyData(BasePolicyData):
    def __init__(self, policy_data_file: str, table_index: TableIndex, config: RunConfig):
        super().__init__(policy_data_file, table_index, config)
        self.data = {}  # Dictionary to hold JAX arrays
        self.mortality_support_table = None

    def load_data(self):
        # Load policy data using table index
        self.policy_df = self.table_index.read_table(self.policy_data_file)
        # Convert dates from dd/mm/yyyy to datetime objects
        self.policy_df['Policy Start Date'] = pd.to_datetime(
            self.policy_df['Policy Start Date'], dayfirst=True, errors='coerce'
        )
        self.policy_df['Date of Birth'] = pd.to_datetime(
            self.policy_df['Date of Birth'], dayfirst=True, errors='coerce'
        )
        # Load mortality support table
        self.load_mortality_support_table()
        self.load_reins_mortality_support_table()

    def load_mortality_support_table(self):
        # Load mortality support table using table index
        self.mortality_support_table = self.table_index.read_table('Mortality_Support_Term')
        # Ensure columns are correctly typed
        self.mortality_support_table['Band_Lower Limit'] = self.mortality_support_table['Band_Lower Limit'].astype(FLOAT_DTYPE)
        self.mortality_support_table['Band_Upper Limit'] = self.mortality_support_table['Band_Upper Limit'].replace(0, np.inf).astype(FLOAT_DTYPE)
        self.mortality_support_table['Is_Smoker'] = self.mortality_support_table['Is_Smoker'].astype(INT_DTYPE)
        self.mortality_support_table['Value'] = self.mortality_support_table['Value'].astype(FLOAT_DTYPE)

    def load_reins_mortality_support_table(self):
        # Get file from table index
        self.reins_mortality_support_table = self.table_index.read_table('Reinsurance_Mortality_Support_Term')
        # Ensure columns are correctly typed
        self.reins_mortality_support_table['Band_Lower Limit'] = self.reins_mortality_support_table['Band_Lower Limit'].astype(FLOAT_DTYPE)
        self.reins_mortality_support_table['Band_Upper Limit'] = self.reins_mortality_support_table['Band_Upper Limit'].replace(0, np.inf).astype(FLOAT_DTYPE)
        self.reins_mortality_support_table['Is_Smoker'] = self.reins_mortality_support_table['Is_Smoker'].astype(INT_DTYPE)
        self.reins_mortality_support_table['Value'] = self.reins_mortality_support_table['Value'].astype(FLOAT_DTYPE)

    def load_bplan_premiums(self):
        self.bplan_prem_df = self.table_index.read_table('Bplan_Premiums')
        self.bplan_prem_df['Month'] = self.bplan_prem_df['Month'].astype(str)
        self.bplan_prem_df['Year'] = self.bplan_prem_df['Year'].astype(str)
        self.bplan_prem_df['Prem_Allocation'] = self.bplan_prem_df['BASE_TERM'].astype(FLOAT_DTYPE)

    def preprocess_data(self):
        df = self.policy_df

        # Standardize column names by replacing spaces with underscores
        df.columns = df.columns.str.replace(' ', '_')

        # Map categorical data to numerical values
        GENDER_MAP = {'M': 0, 'F': 1, 'Male': 0, 'Female': 1}
        SMOKING_STATUS_MAP = {'NS': 0, 'S': 1, 'Non-Smoker': 0, 'Smoker': 1}
        PREMIUM_FREQUENCY_MAP = {1: 1, 12: 12}  # 1 for annual, 12 for monthly, etc.

        df['Gender_Code'] = df['Gender'].map(GENDER_MAP).astype(INT_DTYPE)
        df['Smoking_Status_Code'] = df['Smoking_Status'].map(SMOKING_STATUS_MAP).astype(INT_DTYPE)
        df['Premium_Frequency'] = df['Premium_Frequency'].astype(INT_DTYPE)
        df['Distribution_Channel'] = df['Distribution_Channel'].astype(INT_DTYPE)

        # Override Date of Birth with Age at Policy Start
        df['Age_at_Entry'] = df['Age_at_Policy_Start'].astype(INT_DTYPE)

        # **Clean and Convert 'Sum_Assured' to Numeric**
        df['Sum_Assured'] = df['Sum_Assured'].astype(str).str.replace(',', '')
        df['Sum_Assured'] = pd.to_numeric(df['Sum_Assured'], errors='coerce')
        df['Sum_Assured'] = df['Sum_Assured'].astype(FLOAT_DTYPE)

        # Check and clean 'Premium Amount' if necessary
        df['Premium_Amount'] = df['Premium_Amount'].astype(str).str.replace(',', '')
        df['Premium_Amount'] = pd.to_numeric(df['Premium_Amount'], errors='coerce')
        df['Premium_Amount'] = df['Premium_Amount'].astype(FLOAT_DTYPE)

        # Calculate EMR using the mortality support table
        df['EMR'] = df.apply(self.calculate_emr, axis=1)
        df['reins_EMR'] = df.apply(self.calculate_reins_emr, axis=1)
        if self.config.run_type == 'BusinessPlanning':
            df = self.bplan_columns(df)

        # **Store Policy Numbers Separately**
        self.policy_numbers = df['Policy_Number'].values  # Keep as NumPy array
        
        # Calculate Duration_in_Months with partial months
        def calculate_month_difference(start_date, end_date):
            delta_years = end_date.year - start_date.year
            delta_months = end_date.month - start_date.month
            delta_days = end_date.day - start_date.day
            total_months = delta_years * 12 + delta_months
            # If the day difference is negative, subtract one month
            # if delta_days < 0:
            #   total_months -= 1
            # return max(total_months + 1, 0)
            return (total_months+1)
        # Calculate Duration_in_Months
        df['Duration_in_Months'] = df.apply(
            lambda row: calculate_month_difference(row['Policy_Start_Date'], self.valuation_date),
            axis=1
        ).astype(INT_DTYPE)
        # Ensure no negative durations
        # df['Duration_in_Months'] = df['Duration_in_Months'].clip(lower=0).astype(INT_DTYPE)

        # Store data in JAX arrays
        self.data['Policy_Term'] = jnp.array(df['Policy_Term_(Years)'].values, dtype=FLOAT_DTYPE)
        self.data['Premium_Payment_Term'] = jnp.array(df['Premium_Payment_Term'].values, dtype=INT_DTYPE)
        self.data['Sum_Assured'] = jnp.array(df['Sum_Assured'].values, dtype=FLOAT_DTYPE)
        self.data['Premium_Amount'] = jnp.array(df['Premium_Amount'].values, dtype=FLOAT_DTYPE)
        self.data['Premium_Frequency'] = jnp.array(df['Premium_Frequency'].values, dtype=INT_DTYPE)
        self.data['Distribution_Channel'] = jnp.array(df['Distribution_Channel'].values, dtype=INT_DTYPE)
        self.data['Age_at_Entry'] = jnp.array(df['Age_at_Entry'].values, dtype=INT_DTYPE)
        self.data['Gender_Code'] = jnp.array(df['Gender_Code'].values, dtype=INT_DTYPE)
        self.data['Smoking_Status_Code'] = jnp.array(df['Smoking_Status_Code'].values, dtype=INT_DTYPE)
        self.data['EMR'] = jnp.array(df['EMR'].values, dtype=FLOAT_DTYPE)
        self.data['reins_EMR'] = jnp.array(df['reins_EMR'].values, dtype=FLOAT_DTYPE)
        self.data['Policy_Status'] = df['Policy_Status'].values
        # Store Duration_in_Months in data
        self.data['Duration_in_Months'] = jnp.array(df['Duration_in_Months'].values, dtype=INT_DTYPE)
        if self.config.run_type == 'BusinessPlanning':
            self.data['no_of_pol'] = jnp.array(df['no_of_pol'].values, dtype=FLOAT_DTYPE)
            self.sales_key = df['key'].values
        else:
            self.sales_key = None
        # Add other necessary fields as needed

    def calculate_emr(self, row):
        """
        Calculate the Extra Mortality Rate (EMR) for a policy using the mortality support table.
        """
        sum_assured = row['Sum_Assured']
        smoking_status = row['Smoking_Status_Code']

        # Determine the mortality proportion based on the support table
        mortality_proportion = self.lookup_mortality_proportion(
            sum_assured, smoking_status
        )
        return mortality_proportion

    def lookup_mortality_proportion(self, sum_assured, smoking_status):
        """
        Use the mortality support table to find the mortality proportion for a given policy.
        """
        # Filter based on Sum Assured bands and Smoking Status
        df = self.mortality_support_table

        # Handle the open-ended upper limit (Band_Upper Limit == inf)
        df_filtered = df[
            (df['Band_Lower Limit'] <= sum_assured) &
            (df['Band_Upper Limit'] >= sum_assured) &
            (df['Is_Smoker'] == smoking_status)
        ]

        if not df_filtered.empty:
            value = df_filtered['Value'].iloc[0]
            return value
        else:
            # Default value if no matching record is found
            return 1.0
        
    def calculate_reins_emr(self, row):
        """
        Calculate the Extra Mortality Rate (EMR) for a policy using the mortality support table.
        """
        sum_assured = row['Sum_Assured']
        smoking_status = row['Smoking_Status_Code']

        # Determine the mortality proportion based on the support table
        reins_mortality_proportion = self.lookup_reins_mortality_proportion(
            sum_assured, smoking_status
        )
        return reins_mortality_proportion

    def lookup_reins_mortality_proportion(self, sum_assured, smoking_status):
        """
        Use the mortality support table to find the mortality proportion for a given policy.
        """
        # Filter based on Sum Assured bands and Smoking Status
        df = self.reins_mortality_support_table

        # Handle the open-ended upper limit (Band_Upper Limit == inf)
        df_filtered = df[
            (df['Band_Lower Limit'] <= sum_assured) &
            (df['Band_Upper Limit'] >= sum_assured) &
            (df['Is_Smoker'] == smoking_status)
        ]

        if not df_filtered.empty:
            value = df_filtered['Value'].iloc[0]
            return value
        else:
            # Default value if no matching record is found
            return 1.0
        
    def bplan_columns(self, df):
        df['Weights'] = df['Weights'].astype(FLOAT_DTYPE)
        self.load_bplan_premiums()
        df['Year'] = df['Year'].astype(str)
        df['Month'] = df['Month'].astype(str)
        df['key'] = df['Year'] + '_' + df['Month']
        self.bplan_prem_df['key'] = self.bplan_prem_df['Year'] + '_' + self.bplan_prem_df['Month']
        df = df.merge(self.bplan_prem_df[['key', 'Prem_Allocation']], on='key', how='left')
        df['no_of_pol'] = (df['Prem_Allocation']/df['Premium_Amount'])*df['Weights']*(1_00_00_000)
        return df

class RiderPolicyData(BasePolicyData):
    def __init__(self, policy_data_file: str, table_index: TableIndex, config: RunConfig):
        super().__init__(policy_data_file, table_index, config)
        self.data = {}  # Dictionary to hold JAX arrays
        self.policy_numbers = None

    def load_data(self):
        # Load rider policy data using table index
        self.policy_df = self.table_index.read_table(self.policy_data_file)
        # Convert dates from dd/mm/yyyy to datetime objects
        self.policy_df['Policy Start Date'] = pd.to_datetime(
            self.policy_df['Policy Start Date'], format='%d-%m-%Y'
        )
        self.policy_df['Date of Birth'] = pd.to_datetime(
            self.policy_df['Date of Birth'], format='%d-%m-%Y'
        )

    def load_bplan_premiums(self):
        self.bplan_prem_df = self.table_index.read_table('Bplan_Premiums')
        self.bplan_prem_df['Month'] = self.bplan_prem_df['Month'].astype(str)
        self.bplan_prem_df['Year'] = self.bplan_prem_df['Year'].astype(str)
        self.bplan_prem_df['Prem_Allocation'] = self.bplan_prem_df['BASE_TERM'].astype(FLOAT_DTYPE)

    def preprocess_data(self):
        df = self.policy_df

        # Standardize column names
        df.columns = df.columns.str.replace(' ', '_')

        # Map categorical data
        GENDER_MAP = {'M': 0, 'F': 1, 'Male': 0, 'Female': 1}
        SMOKING_STATUS_MAP = {'NS': 0, 'S': 1, 'Non-Smoker': 0, 'Smoker': 1}

        df['Gender_Code'] = df['Gender'].map(GENDER_MAP).astype(INT_DTYPE)
        df['Smoking_Status_Code'] = df['Smoking_Status'].map(SMOKING_STATUS_MAP).astype(INT_DTYPE)
        df['Premium_Frequency'] = df['Premium_Frequency'].astype(INT_DTYPE)
        df['Distribution_Channel'] = df['Distribution_Channel'].astype(INT_DTYPE)
        df['Age_at_Entry'] = df['Age_at_Policy_Start'].astype(INT_DTYPE)
        if self.config.run_type == 'BusinessPlanning':
            df = self.bplan_columns(df)

        # Clean and convert numeric fields
        numeric_fields = ['Sum_Assured', 'Rider_Premium', 'Base_Premium']
        for field in numeric_fields:
            df[field] = df[field].astype(str).str.replace(',', '')
            df[field] = pd.to_numeric(df[field], errors='coerce').astype(FLOAT_DTYPE)

        # Store Policy Numbers
        self.policy_numbers = df['Policy_Number'].values

        # Calculate Duration_in_Months
        def calculate_month_difference(start_date, end_date):
            delta_years = end_date.year - start_date.year
            delta_months = end_date.month - start_date.month
            delta_days = end_date.day - start_date.day
            total_months = delta_years * 12 + delta_months
            if delta_days < 0:
                total_months -= 1
            # return max(total_months + 1, 0)
            return (total_months+1)
        
        df['Duration_in_Months'] = df.apply(
            lambda row: calculate_month_difference(row['Policy_Start_Date'], self.valuation_date),
            axis=1
        ).astype(INT_DTYPE)
        # df['Duration_in_Months'] = df['Duration_in_Months'].clip(lower=0).astype(INT_DTYPE)

        # Store data in JAX arrays
        self.data['Policy_Term'] = jnp.array(df['Policy_Term_(Years)'].values, dtype=FLOAT_DTYPE)
        self.data['Premium_Payment_Term'] = jnp.array(df['Premium_Payment_Term'].values, dtype=INT_DTYPE)
        self.data['Sum_Assured'] = jnp.array(df['Sum_Assured'].values, dtype=FLOAT_DTYPE)
        self.data['Rider_Premium'] = jnp.array(df['Rider_Premium'].values, dtype=FLOAT_DTYPE)
        self.data['Base_Premium'] = jnp.array(df['Base_Premium'].values, dtype=FLOAT_DTYPE)
        self.data['Premium_Frequency'] = jnp.array(df['Premium_Frequency'].values, dtype=INT_DTYPE)
        self.data['Distribution_Channel'] = jnp.array(df['Distribution_Channel'].values, dtype=INT_DTYPE)
        self.data['Age_at_Entry'] = jnp.array(df['Age_at_Entry'].values, dtype=INT_DTYPE)
        self.data['Gender_Code'] = jnp.array(df['Gender_Code'].values, dtype=INT_DTYPE)
        self.data['Smoking_Status_Code'] = jnp.array(df['Smoking_Status_Code'].values, dtype=INT_DTYPE)
        self.data['Policy_Status'] = df['Policy_Status'].values
        # Store Duration_in_Months in data
        self.data['Duration_in_Months'] = jnp.array(df['Duration_in_Months'].values, dtype=INT_DTYPE)

        # Additional fields specific to riders
        self.data['Rider_Option'] = jnp.array(df['Rider_Option'], dtype=INT_DTYPE)
        if self.config.run_type == 'BusinessPlanning':
            self.data['no_of_pol'] = jnp.array(df['no_of_pol'].values, dtype=FLOAT_DTYPE)
            self.sales_key = df['key'].values
        else:
            self.sales_key = None

        # Handle 'Policy_Status' if available
        if 'Policy_Status' in df.columns:
            self.data['Policy_Status'] = df['Policy_Status'].values
        else:
            self.data['Policy_Status'] = "Inforce"  # Default to 'Inforce' if not present

        # Implement additional preprocessing as needed

    def bplan_columns(self, df):
        df['Weights'] = df['Weights'].astype(FLOAT_DTYPE)
        self.load_bplan_premiums()
        df['Year'] = df['Year'].astype(str)
        df['Month'] = df['Month'].astype(str)
        df['key'] = df['Year'] + '_' + df['Month']
        self.bplan_prem_df['key'] = self.bplan_prem_df['Year'] + '_' + self.bplan_prem_df['Month']
        df = df.merge(self.bplan_prem_df[['key', 'Prem_Allocation']], on='key', how='left')
        df['no_of_pol'] = (df['Prem_Allocation']/df['Rider_Premium'])*df['Weights']*(1_00_00_000)
        return df


class Inforce:
    def __init__(self, table_index: TableIndex, config: RunConfig, product_name: str):
        self.table_index = table_index
        self.config = config
        self.policy_data_file = get_policy_data_table_name(product_name)
        self.root_folder = config.root_folder
        self.valuation_date = config.valuation_date
        self.product_name = product_name.upper()

        # Initialize policy data
        if self.product_name == 'BASE_TERM':
            self.policy_data = TermPolicyData(self.policy_data_file, table_index, config)
        elif self.product_name in ['RIDER_CI', 'RIDER_ADB', 'RIDER_ATPD']:
            self.policy_data = RiderPolicyData(self.policy_data_file, table_index, config)
        elif self.product_name in ['GCL','GCL']:
            self.policy_data = GCLPolicyData(self.policy_data_file, table_index, config)
        else:
            raise NotImplementedError(f"Product '{self.product_name}' not supported yet.")

        self.policy_data.load_data()
        self.policy_data.preprocess_data()
        self.policy_numbers = self.policy_data.policy_numbers
        self.sales_key = self.policy_data.sales_key
        self.data = self.policy_data.data