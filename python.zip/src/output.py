# src/output.py

import pandas as pd
from pathlib import Path
import numpy as np
from typing import Dict, Any, Optional, List
import jax.numpy as jnp
from src.assumptions import IFRS17
from src.logger import Logger
from datetime import datetime
import mysql.connector


# ✅ Insert metadata into final_report_metadata table
def insert_final_report_metadata(run_config, table_name):
    """Insert metadata entry into final_report_metadata table."""
    try:
        conn = mysql.connector.connect(
            host=run_config.data_source_config.get('db_host', 'localhost'),
            user=run_config.data_source_config.get('db_user', 'root'),
            password=run_config.data_source_config.get('db_password', ''),
            database=run_config.data_source_config.get('db_name', 'python_model'),
            port=run_config.data_source_config.get('db_port', 3306)
        )
        cursor = conn.cursor()

        insert_query = """
            INSERT INTO final_report_metadata
            (table_name, run_type, valuation_date, output_run_date, output_run_time, user_id)
            VALUES (%s, %s, %s, %s, %s, %s)
        """
        now = datetime.now()
        user_id = getattr(run_config, "created_by", None) or getattr(run_config, "submitted_by", None) or "system"

        cursor.execute(
            insert_query,
            (
                table_name,
                run_config.run_type,
                run_config.valuation_date.strftime("%Y-%m-%d"),
                now.date(),
                now.time().strftime("%H:%M:%S"),
                user_id
            )
        )
        conn.commit()
        cursor.close()
        conn.close()
        print(f"✅ Metadata inserted for table: {table_name}")
    except Exception as e:
        print(f"⚠️ Failed to insert metadata for {table_name}: {e}")


class Output:
    def __init__(self, output_path, product_name, sensitivity, config, table_index):
        self.output_path = Path(output_path)
        self.product_name = product_name
        self.variables = {}
        self.sensitivity = sensitivity
        self.config = config
        self.time_zero_variables = {}
        self.ifrs_variables = {}
        self.table_index = table_index
        self.logger = Logger()
        self._timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        self._use_timestamp = isinstance(getattr(self.config, 'data_source_config', None), dict)

    def _should_use_sql_output(self) -> bool:
        cfg = getattr(self.config, 'data_source_config', None)
        if not isinstance(cfg, dict):
            return False
        source_type = cfg.get('source_type')
        if str(source_type).lower() != 'sql':
            return False
        host = cfg.get('db_host') or cfg.get('host') or cfg.get('server')
        user = cfg.get('db_user') or cfg.get('username') or cfg.get('user')
        pwd = cfg.get('db_password') or cfg.get('password')
        db = cfg.get('db_name') or cfg.get('database') or cfg.get('db')
        return bool(host and user and pwd and db)

    def _get_sql_conn_info(self) -> Optional[dict]:
        cfg = getattr(self.config, 'data_source_config', None)
        if not self._should_use_sql_output():
            return None
        info = {
            'host': cfg.get('db_host'),
            'user': cfg.get('db_user'),
            'password': cfg.get('db_password'),
            'database': cfg.get('db_name'),
            'port': cfg.get('db_port', 3306)
        }
        info['engine'] = 'mysql'
        return info

    def _sanitize_table_name(self, name: str) -> str:
        safe = ''.join(ch if (ch.isalnum() or ch == '_') else '_' for ch in name)
        return safe.lower().strip('_')[:128]

    def _write_dataframe(self, df: pd.DataFrame, base_filename: str) -> None:
        name_with_ts = f"{base_filename}_{self._timestamp}" if self._use_timestamp else base_filename
        if self._should_use_sql_output():
            info = self._get_sql_conn_info()
            table = self._sanitize_table_name(name_with_ts)
            try:
                from sqlalchemy import create_engine
                engine_url = f"mysql+mysqlconnector://{info['user']}:{info['password']}@{info['host']}:{info['port']}/{info['database']}"
                engine = create_engine(engine_url, pool_pre_ping=True)

                df = df.replace([np.inf, -np.inf], np.nan)
                with engine.begin() as conn:
                    df.to_sql(name=table, con=conn, if_exists='replace', index=False, method='multi', chunksize=1000)

                self.logger.info(f"Output written to SQL table '{table}' on {info['host']}")
                insert_final_report_metadata(self.config, table)
                return
            except Exception as e:
                self.logger.warning(f"SQL write failed for table '{table}'. Falling back to CSV. Error: {str(e)}")

        self.output_path.mkdir(parents=True, exist_ok=True)
        output_file = self.output_path / f"{name_with_ts}.csv"
        df.to_csv(output_file, index=False)
        self.logger.info(f"Output written to CSV '{output_file}'")
        insert_final_report_metadata(self.config, name_with_ts)

    # ---------------- Core Logic ----------------

    def store_results(self, data: Dict[str, Any], time_zero_data: Dict[str, Any] = None):
        for key, value in data.items():
            if not hasattr(value, "ndim"):
                continue
            if key.startswith("IFRS17_"):
                new_key = key
                if new_key not in self.ifrs_variables:
                    self.ifrs_variables[new_key] = [value]
                else:
                    self.ifrs_variables[new_key].append(value)
            else:
                if key not in self.variables:
                    self.variables[key] = [value]
                else:
                    self.variables[key].append(value)

        if time_zero_data is not None:
            for key, value in time_zero_data.items():
                if key not in self.time_zero_variables:
                    self.time_zero_variables[key] = [value]
                else:
                    self.time_zero_variables[key].append(value)

    def print_ifrs_output(self):
        combined_data = {}
        for key, values in self.ifrs_variables.items():
            combined_data[key] = np.concatenate(values, axis=0)
        df = pd.DataFrame(combined_data)
        base_name = f"{self.product_name}_{self.sensitivity}_IFRS_output"
        self._write_dataframe(df, base_name)

    def print_output(self, inforce):
        combined_data = {k: np.concatenate(v, axis=0) for k, v in self.variables.items()}
        df = pd.DataFrame(combined_data)

        if self.time_zero_variables:
            combined_data_time_zero = {k: np.concatenate(v, axis=0) for k, v in self.time_zero_variables.items()}
            df_time_zero = pd.DataFrame(combined_data_time_zero)
        else:
            df_time_zero = None

        base_name = f"{self.product_name}_{self.sensitivity}_output"
        self._write_dataframe(df, base_name)

        self.generate_aggregate_output(df)
        self.generate_seriatim_output(df, df_time_zero, inforce)

        if self.config.run_type == 'IFRS':
            self.print_ifrs_output()

    def generate_aggregate_output(self, df: pd.DataFrame):
        df = df.drop(['Policy_Number', 'Policy_Month', 'Calendar_Month', 'Modal_Factor'], axis=1, errors='ignore')
        aggregate_df = df.groupby('Projection_Step').sum().reset_index()
        base_name = f"{self.product_name}_{self.sensitivity}_aggregate_output"
        self._write_dataframe(aggregate_df, base_name)

    def generate_seriatim_output(self, df: pd.DataFrame, df_time_zero: pd.DataFrame, inforce):
        seriatim_output_vars = ['MCEV_pvfp_BE', 'MCEV_pv_premium_BE', 'MCEV_bel_BE']
        premium_vars = ['cashflows_be_premiums_BE', 'Modal_Factor']

        seriatim_df = df[df['Projection_Step'] == 0][['Policy_Number'] + seriatim_output_vars]
        premium_df = df[df['Projection_Step'] == 1][['Policy_Number'] + premium_vars]

        # ✅ Flatten or convert multi-dimensional arrays before creating a DataFrame
        flat_data = {}
        for k, v in inforce.data.items():
            # Convert JAX arrays to numpy
            if hasattr(v, "shape") and not isinstance(v, np.ndarray):
                v = np.array(v)

            # Handle 2D or higher dimensional arrays safely
            if isinstance(v, np.ndarray) and v.ndim > 1:
                flat_data[k] = [v[i].tolist() for i in range(v.shape[0])]
            # Handle plain Python lists of lists
            elif isinstance(v, list) and len(v) > 0 and isinstance(v[0], (list, np.ndarray)):
                flat_data[k] = [list(x) for x in v]
            else:
                flat_data[k] = v

        policy_data_df = pd.DataFrame(flat_data)
        policy_data_df['Policy_Number'] = inforce.policy_numbers

        premium_data_df = pd.merge(premium_df, policy_data_df, how='inner', on='Policy_Number')

        premium_data_df['Annualised_premium'] = (
            premium_data_df['cashflows_be_premiums_BE'] / premium_data_df['Modal_Factor']
        ) * premium_data_df.get('Premium_Frequency', 1)

        ap_df = premium_data_df[['Annualised_premium', 'Policy_Number']]

        if df_time_zero is not None:
            seriatim_df = pd.merge(seriatim_df, df_time_zero, how='inner', on='Policy_Number')

        seriatim_df = pd.merge(seriatim_df, ap_df, how='inner', on='Policy_Number')

        base_name = f"{self.product_name}_{self.sensitivity}_seriatim_output"
        self._write_dataframe(seriatim_df, base_name)

    def return_bplan_output(self):
        combined_data = {k: np.concatenate(v, axis=0) for k, v in self.variables.items()}
        return pd.DataFrame(combined_data)

    def print_bplan_output(self, df: pd.DataFrame):
        base_name = f"{self.product_name}_{self.sensitivity}_bplan_output"
        self._write_dataframe(df, base_name)
