# rider_calc_engine.py

import jax
import jax.numpy as jnp
from jax import lax
import numpy as np
from typing import Dict, Any
from src.base_calc_engine import CalculationEngine
from src.jax_config import FLOAT_DTYPE, INT_DTYPE
from src.assumptions import IFRS17


class RiderCalculationEngine(CalculationEngine):
    """
    Performs calculations for rider products (e.g., Critical Illness, ATPD, ADB).
    """

    ZERO_ARRAY = None  # Will be initialized in the prepare_policy_data method

    def run_batch(self, batch_policy_data: Dict[str, jnp.ndarray], batch_policy_numbers: Any):
        """
        Performs calculations for a single batch of rider policies.
        """
        # Prepare policy data
        policy_attrs = self.prepare_policy_data(batch_policy_data)

        # Initialize zero array
        self.ZERO_ARRAY = jnp.zeros((policy_attrs['num_policies'], self.projection_months), dtype=FLOAT_DTYPE)

        # Compute rates
        rates = self.compute_rates(policy_attrs)

        # First projection section: Calculate decrements and cash flows for Reserving layer
        decrements_reserving = self.calculate_decrements(policy_attrs, rates, layer='Reserving')

        # Cashflows for Reserving layer (gross of reinsurance)
        reinsurance_results= None
        gross_cf_reserving = self.calculate_cash_flows(policy_attrs, rates, decrements_reserving, reinsurance_results, layer='Reserving')

        # First backward pass: Calculate discounted cash flows and Gross Reserve PP
        gross_reserves = self.calculate_discounted_cf_reserves(policy_attrs, rates, decrements_reserving, gross_cf_reserving)

        # Second forward pass: Calculate reinsurance cashflows and net CF with reinsurance
        reinsurance_results = self.calculate_reinsurance_cashflows(policy_attrs, rates, decrements_reserving, gross_cf_reserving, gross_reserves)

        # Second backward pass: Calculate net reserves
        net_reserves = self.calculate_net_reserves(policy_attrs, rates, decrements_reserving, reinsurance_results, gross_reserves)

        # Third forward pass: BE Layer cashflows, reserves, solvency capital, 
        decrements_BE = self.calculate_decrements(policy_attrs, rates, layer='BE')
        reinsurance_results_BE = self.calculate_reinsurance_cashflows(policy_attrs, rates, decrements_BE, gross_cf_reserving, gross_reserves)
        be_results = self.calculate_be_layer(policy_attrs, rates, decrements_BE, reinsurance_results_BE, gross_reserves['gross_reserve_pp'], net_reserves['net_reserve_pp'])

        # Third backward pass: Calculate MCEV, BEL, PVFP, and FCC
        pv_results = self.calculate_pv_variables(policy_attrs, rates, be_results, reinsurance_results_BE, decrements_BE, batch_policy_numbers=batch_policy_numbers)

        results_dict = {
            'policy_attrs': policy_attrs,
            'rates': rates,
            'gross_cf_reserving': gross_cf_reserving,
            'gross_reserves': gross_reserves,
            'reinsurance_results': reinsurance_results,
            'net_reserves': net_reserves,
            'decrements_reserving': decrements_reserving,
            'decrements_BE': decrements_BE,
            'reinsurance_results_BE': reinsurance_results_BE,
            'be_results': be_results,
            'pv_results': pv_results
        }

        return results_dict

    def create_output_df(self, batch_policy_numbers, results_dict: Dict[str, Any]):
        """
        Combines results from the three passes of the rider calculation and formats them into a pandas DataFrame.

        Parameters
        ----------
        batch_policy_numbers : array
            Policy numbers in the batch.
        results_dict : dict
            Dictionary of results from the rider calculation.

        Returns
        -------
        dict
            Combined results dictionary for the batch, with the following keys:

            * Policy_Number
            * Policy_Month
            * Calendar_Month
            * Projection_Step
            * output variables with suitable prefixes and suffixes
        """

        policy_attrs = results_dict['policy_attrs']
        rates = results_dict['rates']
        gross_cf_reserving = results_dict['gross_cf_reserving']
        reinsurance_results = results_dict['reinsurance_results']
        gross_reserves = results_dict['gross_reserves']
        net_reserves = results_dict['net_reserves']
        decrements_reserving = results_dict['decrements_reserving']
        decrements_BE = results_dict['decrements_BE']
        reinsurance_results_BE = results_dict['reinsurance_results_BE']
        be_results = results_dict['be_results']
        pv_results = results_dict['pv_results']
        # Combine results
        projection_steps = policy_attrs['projection_steps']
        combined_data = {
            'Policy_Number': np.repeat(batch_policy_numbers, projection_steps.size),
            'Policy_Month': np.array(policy_attrs['policy_months']).reshape(-1),
            'Calendar_Month': np.tile(policy_attrs['calendar_months'], len(batch_policy_numbers)),
            'Projection_Step': np.tile(np.arange(projection_steps.size), len(batch_policy_numbers)),
            'Modal_Factor': np.array(rates['modal_factor']).reshape(-1),
        }

        # Add BE decrements with suffix
        for key, value in decrements_reserving.items():
            combined_data[f"decrements_{key}_reserving"] = np.array(value).flatten()

        # Add BE cashflows with suffix
        for key, value in gross_cf_reserving.items():
            combined_data[f"cashflows_{key}_reserving"] = np.array(value).flatten()

        # Add Reserving decrements with suffix
        for key, value in gross_reserves.items():
            combined_data[f"cashflows_{key}_reserving"] = np.array(value).flatten()

        # Add Reserving cashflows with suffix
        for key, value in reinsurance_results.items():
            combined_data[f"cashflows_{key}_reserving"] = np.array(value).flatten()

        # Add reserves
        for key, value in net_reserves.items():
            combined_data[f"cashflows_{key}_reserving"]  = np.array(value).flatten()

        # Add solvency capital calculations
        for key, value in be_results.items():
            combined_data[f"cashflows_{key}_BE"]  = np.array(value).flatten()

        # Add profit calculations
        for key, value in pv_results.items():
            combined_data[f"MCEV_{key}_BE"]  = np.array(value).flatten()
            # Add Reserving cashflows with suffix

        for key, value in reinsurance_results_BE.items():
            combined_data[f"cashflows_{key}_BE"] = np.array(value).flatten()

        # Add MCEV calculations
        for key, value in decrements_BE.items():
            combined_data[f"decrements_{key}_BE"] = np.array(value).flatten()

        # Store combined results
        return combined_data

    def create_bplan_output_df(self, batch_policy_numbers, results_dict: Dict[str, Any], sales_key):
        """Create output dataframes"""

        policy_attrs = results_dict['policy_attrs']
        be_results = results_dict['be_results']
        pv_results = results_dict['pv_results']

        # Prepare data for output
        projection_steps = policy_attrs['projection_steps']
        combined_data = {
            'Policy_Number': np.repeat(batch_policy_numbers, projection_steps.size/len(batch_policy_numbers)),
            'Sales_Key': np.repeat(sales_key, projection_steps.size/len(batch_policy_numbers)),
            'Policy_Month': np.array(policy_attrs['policy_months']).reshape(-1),
            'Calendar_Month': np.tile(policy_attrs['calendar_months'], len(batch_policy_numbers)),
            'Financial_Year': np.tile(policy_attrs['fy'], len(batch_policy_numbers)),
            'Projection_Step': np.array(projection_steps).reshape(-1),
            'Number_of_policies': np.array(policy_attrs['no_of_pol']).reshape(-1)
        }

        # Add BE cashflow calculations
        be_results_keys_remove = ['be_reinsurance_recoveries','be_net_cf', 'be_reserves',
                                  'part1_sm', 'part2_sm','gross_sar', 'net_sar','increase_in_solvency_capital', 'interest_on_solvency_capital',
                                  'profit_before_tax', 'csr', 'tax', 'net_profit_before_sm','cost_of_capital', 'net_profit_after_sm']
        be_results_filtered = {key: value for key, value in be_results.items() if key not in be_results_keys_remove}
        for key, value in be_results_filtered.items():
            combined_data[f"{key}"]  = np.array(value).flatten()

        # Add PV calculations
        pv_results_keys_remove = ['interest_on_cashflows', 'interest_on_reserve', 'net_cf', 'profit_before_tax', 'csr', 'tax', 'net_profit', 'pvfp', 
                                  'pv_premium', 'interest_on_sm', 'tax_interest_on_sm', 'csr_interest_on_sm', 'coc', 'fcc', 'bel', 'bel_pp']
        pv_results_filtered = {key: value for key, value in pv_results.items() if key not in pv_results_keys_remove}
        for key, value in pv_results_filtered.items():
            combined_data[f"MCEV_{key}_BE"]  = np.array(value).flatten()

        # Store combined results
        return combined_data

    def prepare_policy_data(self, batch_policy_data: Dict[str, jnp.ndarray]) -> Dict[str, Any]:
        """
        Prepares and expands policy data for calculations.
        """
        num_policies = batch_policy_data['Policy_Term'].shape[0]
        time_vector = jnp.arange(0, self.projection_months)  # Shape: (num_months,)
        policy_terms_months = batch_policy_data['Policy_Term'] * 12  # Shape: (num_policies,)
        duration_in_months = batch_policy_data['Duration_in_Months']  # Shape: (num_policies,)

        # Adjust time vectors for policies
        policy_months = duration_in_months[:, None] + time_vector[None, :]  # Shape: (num_policies, num_months)

        # Create masks for in-force policies considering duration in months
        policy_masks = (policy_months <= policy_terms_months[:, None])  # Shape: (num_policies, num_months)

        # Policy years
        policy_years = ((policy_months - 1) // 12) + 1  # Shape: (num_policies, num_months)

        # Expand policy attributes across time periods
        ages = batch_policy_data['Age_at_Entry'][:, None] + ((policy_months - 1) // 12)  # Shape: (num_policies, num_months)
        genders = batch_policy_data['Gender_Code'][:, None]  # Shape: (num_policies, 1)
        genders = jnp.tile(genders, (1, self.projection_months))
        sum_assureds = batch_policy_data['Sum_Assured'][:, None]  # Shape: (num_policies, 1)
        sum_assureds = jnp.tile(sum_assureds, (1, self.projection_months))
        rider_premiums = batch_policy_data['Rider_Premium'][:, None]  # Shape: (num_policies, 1)
        rider_premiums = jnp.tile(rider_premiums, (1, self.projection_months))
        base_premiums = batch_policy_data['Base_Premium'][:, None]  # Shape: (num_policies, 1)
        base_premiums = jnp.tile(base_premiums, (1, self.projection_months))
        premium_frequencies = batch_policy_data['Premium_Frequency'][:, None]  # Shape: (num_policies, 1)
        premium_frequencies = jnp.tile(premium_frequencies, (1, self.projection_months))
        distribution_channels = batch_policy_data['Distribution_Channel'][:, None]  # Shape: (num_policies, 1)
        distribution_channels = jnp.tile(distribution_channels, (1, self.projection_months))
        rider_option = batch_policy_data['Rider_Option'][:, None]

        # Calendar Month calculation based on valuation date
        valuation_month = self.config.valuation_date.month
        calendar_months = (valuation_month - 1 + time_vector) % 12 + 1  # Shape: (num_months,)
        financial_year_ind = jnp.arange(valuation_month, self.projection_months+valuation_month) 

        def financial_year(ind,year):
            fy = []
            for i in ind:
                if i % 12==0:
                    financial_year = (int(i/12)-1) + year
                else:
                    financial_year = int(i/12) + year
                fy.append(financial_year)
            return fy
        
        fy = financial_year(financial_year_ind,self.config.valuation_date.year)

        # Projection Step: 1 to num_months
        if self.config.run_type =='BusinessPlanning':
            projection_steps = policy_months  # Shape: (num_months,)
            no_of_pol = batch_policy_data['no_of_pol'][:, None]  # Shape: (num_policies, 1)
            no_of_pol = jnp.tile(no_of_pol, (1, self.projection_months))
        else:
            projection_steps = time_vector

        policy_attrs = {
            'num_policies': num_policies,
            'time_vector': time_vector,  # Shape: (num_months,)
            'policy_masks': policy_masks,  # Shape: (num_policies, num_months)
            'policy_terms_months': policy_terms_months,  # Shape: (num_policies,)
            'policy_months': policy_months,  # Shape: (num_policies, num_months)
            'policy_years': policy_years,  # Shape: (num_policies, num_months)
            'ages': ages,  # Shape: (num_policies, num_months)
            'genders': genders,  # Shape: (num_policies, num_months)
            'sum_assureds': sum_assureds,  # Shape: (num_policies, num_months)
            'rider_premiums': rider_premiums,  # Shape: (num_policies, num_months)
            'base_premiums': base_premiums,  # Shape: (num_policies, num_months)
            'premium_frequencies': premium_frequencies,  # Shape: (num_policies, num_months)
            'distribution_channels': distribution_channels,  # Shape: (num_policies, num_months)
            'calendar_months': calendar_months,  # Shape: (num_months,)
            'fy': fy,  # Shape: (num_months,)
            'projection_steps': projection_steps,  # Shape: (num_months,)
            'rider_option' : rider_option
        }
        if self.config.run_type =='BusinessPlanning':
            bplan_fields = {
            'no_of_pol':no_of_pol,
            }
            policy_attrs.update(bplan_fields)

        return policy_attrs

    def compute_rates(self, policy_attrs: Dict[str, Any]) -> Dict[str, Any]:
        """
        Computes rates using assumption classes.
        """
        ages = policy_attrs['ages']  # Shape: (num_policies, num_months)
        genders = policy_attrs['genders']  # Shape: (num_policies, num_months)
        policy_years = policy_attrs['policy_years']  # Shape: (num_policies, num_months)
        sum_assureds = policy_attrs['sum_assureds']  # Shape: (num_policies, num_months)
        distribution_channels = policy_attrs['distribution_channels']  # Shape: (num_policies, num_months)
        policy_months = policy_attrs['policy_months']  # Shape: (num_policies, num_months)
        premium_frequencies = policy_attrs['premium_frequencies']  # Shape: (num_policies, num_months)

        # Read MAD factors and other config variables from product config
        MAD_Mortality = float(self.product_config.variables.get('MAD_Mortality', 0.0))
        MAD_Morbidity = float(self.product_config.variables.get('MAD_Morbidity', 0.0))
        MAD_Lapse = float(self.product_config.variables.get('MAD_Lapse', 0.0))
        MAD_Expense = float(self.product_config.variables.get('MAD_Expense', 0.0))
        Inflation_Factor = float(self.product_config.variables.get('Inflation', 0.0))
        Reinsurance_Retention_Limit = float(self.product_config.variables.get('Reinsurance Retention Limit abs', 0.0))
        Reinsurance_Retention_Proportion = float(self.product_config.variables.get('Reinsurance Retention Limit proportion', 1.0))
        Qx_Mortality_Proportion = float(self.product_config.variables.get('Qx Mortality Proportion', 1.0))

        # Mortality rates
        mortality_rates_base = self.assumptions['mortality'].get_annual_rate_vectorized(ages, genders)  # Shape: (num_policies, num_months)
        mortality_rates_BE = mortality_rates_base * Qx_Mortality_Proportion   # Adjusted mortality rates
        mortality_rates_reserving = (1 + MAD_Mortality) * mortality_rates_BE  # Reserving layer

        # Convert to monthly mortality rates
        monthly_mortality_rates_BE = 1 - (1 - mortality_rates_BE) ** (1 / 12) * (policy_months>0)  # Shape: (num_policies, num_months)
        monthly_mortality_rates_reserving = 1 - (1 - mortality_rates_reserving) ** (1 / 12)

        # Morbidity rates
        morbidity_rates_base = self.assumptions['morbidity'].get_annual_rate_vectorized(ages, genders)
        morbidity_rates_BE = morbidity_rates_base
        morbidity_rates_reserving = (1 + MAD_Morbidity) * morbidity_rates_BE

        # Convert to monthly morbidity rates
        monthly_morbidity_rates_BE = 1 - (1 - morbidity_rates_BE) ** (1 / 12)
        monthly_morbidity_rates_reserving = 1 - (1 - morbidity_rates_reserving) ** (1 / 12)

        # Premium Modal factors
        modal_factor = self.assumptions['modal_factor'].get_annual_rate_vectorized(premium_frequencies)  # Shape: (num_policies, num_months)

        # Lapse rates
        lapse_rates_base = self.assumptions['persistency'].get_annual_lapse_rate_vectorized(
            policy_years=policy_years,
            distribution_channels=distribution_channels
        )  # Shape: (num_policies, num_months)

        # Lapse rates are non-zero only on months prior to when premium is paid
        lapse_due_mask = jnp.where(
            (policy_months + 1) % (12 / premium_frequencies) == jnp.where(premium_frequencies == 12, 0, 1),
            1.0,
            0.0
        )
        lapse_due_mask = lapse_due_mask * (policy_months > 1).astype(FLOAT_DTYPE)
        lapse_rates_BE = lapse_rates_base * lapse_due_mask
        lapse_rates_reserving = (1 + MAD_Lapse) * lapse_rates_base * lapse_due_mask

        # Convert to monthly lapse rates
        monthly_lapse_rates_BE = 1 - (1 - lapse_rates_BE) ** (1 / premium_frequencies)
        monthly_lapse_rates_reserving = 1 - (1 - lapse_rates_reserving) ** (1 / premium_frequencies)

        # Commission rates
        commission_rates = self.assumptions['commissions'].get_commission_rate_vectorized(
            policy_years=policy_years,
            distribution_channels=distribution_channels
        )  # Shape: (num_policies, num_months)

        # Expense rates
        # Initial expenses components
        initial_expenses = self.assumptions['expense'].get_initial_expense_rates(sum_assureds)  # Use sum assured at inception
        init_fixed_expense_rate = initial_expenses.get('Fixed', 0.0)  # scalar
        init_percent_prem_expense_rate = initial_expenses.get('% of Prem', 0.0)  # scalar
        init_percent_sa_expense_rate = initial_expenses.get('% of SA', 0.0)  # scalar

        # Renewal expenses components
        renewal_expenses = self.assumptions['expense'].get_renewal_expense_rates()
        fixed_expense_rate = renewal_expenses.get('Fixed expenses', 0.0)  # scalar
        percent_prem_expense_rate = renewal_expenses.get('% of Prem', 0.0)  # scalar

        # Claim expense rate
        claim_expense_rate = renewal_expenses.get('Claim expenses', 0.0) / 100.0  # scalar

        # Fetch monthly interest rates
        monthly_ROI_rates_raw = self.assumptions['interest_rate'].get_monthly_rates('ROI')  # For BE layer
        monthly_ROI_rates = np.zeros_like(monthly_ROI_rates_raw)
        monthly_ROI_rates[1:] = monthly_ROI_rates_raw[:-1]

        monthly_VROI_rates_raw = self.assumptions['interest_rate'].get_monthly_rates('VROI')  # For Reserving layer
        monthly_VROI_rates = np.zeros_like(monthly_VROI_rates_raw)
        monthly_VROI_rates[1:] = monthly_VROI_rates_raw[:-1]
        
        monthly_CCIL_rates_raw = self.assumptions['interest_rate'].get_monthly_rates('CCIL')  # For MCEV calculations
        monthly_CCIL_rates = np.zeros_like(monthly_CCIL_rates_raw)
        monthly_CCIL_rates[1:] = monthly_CCIL_rates_raw[:-1]

        # Reinsurance morbidity rates
        reinsurance_morbidity_rates_base = self.assumptions['reinsurance_morbidity'].get_annual_rate_vectorized(ages, genders)
        monthly_reins_morbidity_rates = 1 - (1 - reinsurance_morbidity_rates_base) ** (1 / 12) * (policy_months>0)

        rates = {
            'monthly_mortality_rates_BE': monthly_mortality_rates_BE,  # Shape: (num_policies, num_months)
            'monthly_mortality_rates_reserving': monthly_mortality_rates_reserving,  # Shape: (num_policies, num_months)
            'monthly_morbidity_rates_BE': monthly_morbidity_rates_BE,
            'monthly_morbidity_rates_reserving': monthly_morbidity_rates_reserving,
            'monthly_lapse_rates_BE': monthly_lapse_rates_BE,  # Shape: (num_policies, num_months)
            'monthly_lapse_rates_reserving': monthly_lapse_rates_reserving,  # Shape: (num_policies, num_months)
            'commission_rates': commission_rates,  # Shape: (num_policies, num_months)
            'fixed_expense_rate': fixed_expense_rate,  # scalar
            'percent_prem_expense_rate': percent_prem_expense_rate,  # scalar
            'claim_expense_rate': claim_expense_rate,  # scalar
            'MAD_Expense': MAD_Expense,  # scalar
            'Inflation_Factor': Inflation_Factor,  # scalar
            'Reinsurance_Retention_Limit': Reinsurance_Retention_Limit,  # scalar
            'Reinsurance_Retention_Proportion': Reinsurance_Retention_Proportion,  # scalar
            'monthly_ROI_rates': monthly_ROI_rates,  # Shape: (num_months,)
            'monthly_VROI_rates': monthly_VROI_rates,  # Shape: (num_months,)
            'monthly_CCIL_rates': monthly_CCIL_rates,  # Shape: (num_months,)
            'monthly_reins_morbidity_rates': monthly_reins_morbidity_rates,  # Shape: (num_policies, num_months)
            'init_fixed_expense_rate': init_fixed_expense_rate,  # scalar
            'init_percent_prem_expense_rate': init_percent_prem_expense_rate,  # scalar
            'init_percent_sa_expense_rate': init_percent_sa_expense_rate,  # scalar
            'modal_factor': modal_factor,
        }

        return rates

    def calculate_decrements(self, 
        policy_attrs: Dict[str, Any],
        rates: Dict[str, Any],
        layer: str
    ) -> Dict[str, jnp.ndarray]:
        """
        Calculates decrements for the specified layer ('BE' or 'Reserving').

        Returns:
            Dict[str, jnp.ndarray]: Decrement results.
        """
        num_policies = policy_attrs['num_policies']
        num_months = policy_attrs['policy_months'].shape[1]
        policy_months = policy_attrs['policy_months']  # Shape: (num_policies, num_months)
        policy_terms_months = policy_attrs['policy_terms_months']  # Shape: (num_policies,)
        rider_option = policy_attrs['rider_option'] 

        if layer == 'BE':
            mortality_rates = rates['monthly_mortality_rates_BE']  # Shape: (num_policies, num_months)
            morbidity_rates = rates['monthly_morbidity_rates_BE']
            lapse_rates = rates['monthly_lapse_rates_BE']  # Shape: (num_policies, num_months)
        else:  # Reserving
            mortality_rates = rates['monthly_mortality_rates_reserving']  # Shape: (num_policies, num_months)
            morbidity_rates = rates['monthly_morbidity_rates_reserving']
            lapse_rates = rates['monthly_lapse_rates_reserving']  # Shape: (num_policies, num_months)

        # Apply mask to set rates at time 0 to zero
        if self.config.run_type=='BusinessPlanning':
            time_mask = (policy_attrs['projection_steps']>0).astype(FLOAT_DTYPE)
        else:
            time_mask = (policy_attrs['time_vector'][None,:]>0).astype(FLOAT_DTYPE)
        mortality_rates *= time_mask
        morbidity_rates *= time_mask
        lapse_rates *= time_mask

        # Maturities: Occur when the policy term ends
        maturities = jnp.where(
            policy_months == (policy_terms_months[:, None]),
            1.0,  # All remaining lives mature
            0.0
        )  # Shape: (num_policies, num_months)

        # Prepare inputs for scan
        inputs = (
            mortality_rates.T,
            morbidity_rates.T,
            lapse_rates.T,
            maturities.T
        )

        # Initial carry (lives at end of month -1, which is 1)
        init_carry = (
            jnp.ones(num_policies, dtype=FLOAT_DTYPE),  # lives_so_end
            jnp.zeros(num_policies, dtype=FLOAT_DTYPE),  # cumulative_critical_illness
            jnp.zeros(num_policies, dtype=FLOAT_DTYPE)   # net_cumulative_critical_illness
        )

        # Define step function
        def decrement_step_ci(carry, inputs):
            lives_prev, cumulative_ci_prev, net_cumulative_ci_prev = carry
            mortality_rate, morbidity_rate, lapse_rate, maturity = inputs

            lives_so_begin = lives_prev
            deaths = lives_so_begin * mortality_rate
            ci = (lives_so_begin - deaths) * morbidity_rate
            lapses = (lives_so_begin - deaths - ci) * lapse_rate
            maturities_actual = (lives_so_begin - deaths - ci - lapses) * maturity  # All remaining lives mature
            lives_so_end = lives_so_begin - deaths - ci - lapses - maturities_actual
            lives_so_end = jnp.maximum(lives_so_end, 0.0)

            # WOP Benefit Inforce calculations
            cumulative_ci = net_cumulative_ci_prev + ci
            deaths_out_of_ci = net_cumulative_ci_prev * mortality_rate
            net_cumulative_ci = cumulative_ci - deaths_out_of_ci
            

            outputs = (
                lives_so_begin,
                deaths,
                ci,
                lapses,
                maturities_actual,
                lives_so_end,
                cumulative_ci,
                deaths_out_of_ci,
                net_cumulative_ci
            )
            new_carry = (lives_so_end, cumulative_ci, net_cumulative_ci)
            return new_carry, outputs

        def decrement_step_adb(carry, inputs):
            lives_prev, cumulative_ci_prev, net_cumulative_ci_prev = carry
            mortality_rate, morbidity_rate, lapse_rate, maturity = inputs

            lives_so_begin = lives_prev
            deaths = lives_so_begin * mortality_rate
            adb = lives_so_begin * morbidity_rate
            lapses = (lives_so_begin - deaths) * lapse_rate
            maturities_actual = (lives_so_begin - deaths - lapses) * maturity  # All remaining lives mature
            lives_so_end = lives_so_begin - deaths - lapses - maturities_actual
            lives_so_end = jnp.maximum(lives_so_end, 0.0)            

            outputs = (
                lives_so_begin,
                deaths,
                adb,
                lapses,
                maturities_actual,
                lives_so_end,
            )

            new_carry = (lives_so_end, cumulative_ci_prev, net_cumulative_ci_prev)
            return new_carry, outputs
        
        # Define step function
        def decrement_step_tpd(carry, inputs):
            lives_prev, cumulative_tpd_prev, net_cumulative_tpd_prev = carry
            mortality_rate, morbidity_rate, lapse_rate, maturity = inputs

            lives_so_begin = lives_prev
            deaths = lives_so_begin * mortality_rate
            tpd = (lives_so_begin - deaths) * morbidity_rate
            lapses = (lives_so_begin - deaths - tpd) * lapse_rate
            maturities_actual = (lives_so_begin - deaths - tpd - lapses) * maturity  # All remaining lives mature
            lives_so_end = lives_so_begin - deaths - tpd - lapses - maturities_actual
            lives_so_end = jnp.maximum(lives_so_end, 0.0)

            # WOP Benefit Inforce calculations
            cumulative_tpd = net_cumulative_tpd_prev + tpd
            deaths_out_of_tpd = net_cumulative_tpd_prev * mortality_rate
            net_cumulative_tpd = cumulative_tpd - deaths_out_of_tpd
            

            outputs = (
                lives_so_begin,
                deaths,
                tpd,
                lapses,
                maturities_actual,
                lives_so_end,
                cumulative_tpd,
                deaths_out_of_tpd,
                net_cumulative_tpd
            )
            new_carry = (lives_so_end, cumulative_tpd, net_cumulative_tpd)
            return new_carry, outputs

        # Run scan
        if jnp.all(rider_option == 2):
            _, outputs = lax.scan(decrement_step_ci, init_carry, inputs)
            # Extract outputs
            lives_so_begin = outputs[0].T
            deaths = outputs[1].T
            critical_illness = outputs[2].T
            lapses = outputs[3].T
            maturities_actual = outputs[4].T
            lives_so_end = outputs[5].T
            cumulative_critical_illness = outputs[6].T
            deaths_out_of_critical_illness = outputs[7].T
            net_cumulative_critical_illness = outputs[8].T

            net_cumulative_critical_illness = net_cumulative_critical_illness * (policy_attrs['policy_months'] <= policy_attrs['policy_terms_months'][:, None])

            decrements = {
                'lives_so_begin': lives_so_begin,
                'deaths': deaths,
                'critical_illness': critical_illness,
                'lapses': lapses,
                'maturities': maturities_actual,
                'lives_so_end': lives_so_end,
                'cumulative_critical_illness': cumulative_critical_illness,
                'deaths_out_of_critical_illness': deaths_out_of_critical_illness,
                'net_cumulative_critical_illness': net_cumulative_critical_illness,
            }

        elif jnp.all(rider_option ==1):
            _, outputs = lax.scan(decrement_step_adb, init_carry, inputs)

            # Extract outputs
            lives_so_begin = outputs[0].T
            deaths = outputs[1].T
            adb = outputs[2].T
            lapses = outputs[3].T
            maturities_actual = outputs[4].T
            lives_so_end = outputs[5].T

            decrements = {
                'lives_so_begin': lives_so_begin,
                'deaths': deaths,
                'adb': adb,
                'lapses': lapses,
                'maturities': maturities_actual,
                'lives_so_end': lives_so_end
            }

        else:
            _, outputs = lax.scan(decrement_step_tpd, init_carry, inputs)

            lives_so_begin = outputs[0].T
            deaths = outputs[1].T
            disability = outputs[2].T
            lapses = outputs[3].T
            maturities_actual = outputs[4].T
            lives_so_end = outputs[5].T
            cumulative_disability = outputs[6].T
            deaths_out_of_disability = outputs[7].T
            net_cumulative_disability = outputs[8].T

            net_cumulative_disability = net_cumulative_disability * (policy_attrs['policy_months'] <= policy_attrs['policy_terms_months'][:, None])

            decrements = {
                'lives_so_begin': lives_so_begin,
                'deaths': deaths,
                'disability': disability,
                'lapses': lapses,
                'maturities': maturities_actual,
                'lives_so_end': lives_so_end,
                'cumulative_disability': cumulative_disability,
                'deaths_out_of_disability': deaths_out_of_disability,
                'net_cumulative_disability': net_cumulative_disability,
            }


        return decrements

    def calculate_cash_flows(
        self,
        policy_attrs: Dict[str, Any],
        rates: Dict[str, Any],
        decrements: Dict[str, jnp.ndarray],
        reinsurance_results,
        layer: str
    ) -> Dict[str, jnp.ndarray]:
        """
        Calculates cash flows for the specified layer ('BE' or 'Reserving').

        Returns:
            Dict[str, jnp.ndarray]: Cashflow results.
        """
        num_policies = policy_attrs['num_policies']
        num_months = policy_attrs['policy_months'].shape[1]

        # Extract variables
        policy_months = policy_attrs['policy_months']  # Shape: (num_policies, num_months)
        policy_years = policy_attrs['policy_years']  # Shape: (num_policies, num_months)
        sum_assureds = policy_attrs['sum_assureds']  # Shape: (num_policies, num_months)
        rider_premiums = policy_attrs['rider_premiums']  # Shape: (num_policies, num_months)
        base_premiums = policy_attrs['base_premiums']  # Shape: (num_policies, num_months)
        premium_frequencies = policy_attrs['premium_frequencies']  # Shape: (num_policies, num_months)
        rider_option = policy_attrs['rider_option']
        commission_rates = rates['commission_rates']  # Shape: (num_policies, num_months)
        fixed_expense_rate = rates['fixed_expense_rate']  # scalar
        percent_prem_expense_rate = rates['percent_prem_expense_rate']  # scalar
        claim_expense_rate = rates['claim_expense_rate']  # scalar
        Inflation_Factor = rates['Inflation_Factor']  # scalar
        MAD_Expense = rates['MAD_Expense'] if layer == 'Reserving' else 0.0  # scalar
        init_fixed_expense_rate = rates['init_fixed_expense_rate']  # scalar
        init_percent_prem_expense_rate = rates['init_percent_prem_expense_rate']  # scalar
        init_percent_sa_expense_rate = rates['init_percent_sa_expense_rate']  # scalar
        monthly_interest_rates = rates['monthly_VROI_rates'] if layer == 'Reserving' else rates['monthly_ROI_rates']
        modal_factor = rates['modal_factor']

        # Decrements
        lives_so_begin = decrements['lives_so_begin']  # Shape: (num_policies, num_months)
        deaths = decrements['deaths']  # Shape: (num_policies, num_months)
        lapses = decrements['lapses']  # Shape: (num_policies, num_months)
        if jnp.all(rider_option == 2):
            critical_illness = decrements['critical_illness']  # Shape: (num_policies, num_months)
            net_cumulative_critical_illness = decrements['net_cumulative_critical_illness']  # Shape: (num_policies, num_months)
        elif jnp.all(rider_option ==1):
            adb = decrements['adb']  # Shape: (num_policies, num_months)
        else:
            disability = decrements['disability']  # Shape: (num_policies, num_months)
            net_cumulative_disability = decrements['net_cumulative_disability']  # Shape: (num_policies, num_months)

        # Premiums: Paid throughout the year at premium frequency
        premium_due_mask = jnp.where((premium_frequencies==12), 1,(((policy_attrs['policy_months'] % (12/premium_frequencies))) == 1).astype(FLOAT_DTYPE))        
        premium_due_mask = premium_due_mask * (policy_attrs['projection_steps'] > 0).astype(FLOAT_DTYPE)  # Exclude time 0
        premiums = rider_premiums * modal_factor * premium_due_mask * lives_so_begin  # Shape: (num_policies, num_months)

        # Commissions
        commissions = premiums * commission_rates  # Shape: (num_policies, num_months)

        # Initial Expense (only in first month)
        # Compute initial expense per policy (shape: (num_policies,))
        initial_expense_per_policy = (
            init_fixed_expense_rate +
            init_percent_prem_expense_rate * rider_premiums[:, 0] +
            init_percent_sa_expense_rate * sum_assureds[:, 0]
        )
        # Expand to shape (num_policies, 1)
        initial_expense_per_policy = initial_expense_per_policy[:, None]
        # Compute initial expense (shape: (num_policies, num_months))
        initial_expense = initial_expense_per_policy * (policy_attrs['projection_steps'] > 0) * (policy_attrs['policy_months'] == 1).astype(FLOAT_DTYPE) * lives_so_begin

        # Renewal Expenses
        if jnp.all(rider_option == 2):
            net_cumulative_disability = 0
        elif jnp.all(rider_option ==1):
            net_cumulative_disability = 0
            net_cumulative_critical_illness = 0
        else:
            net_cumulative_critical_illness = 0
        renewal_expenses = (
            ((fixed_expense_rate + percent_prem_expense_rate * rider_premiums)/12) *
            (1 + Inflation_Factor) ** ((policy_attrs['projection_steps'] - 1)/12) *
            (1 + MAD_Expense)
        ) * (lives_so_begin + net_cumulative_critical_illness + net_cumulative_disability) * (policy_attrs['policy_years'] > 1) # Shape: (num_policies, num_months)


        # Claim Expenses
        claim_expenses = sum_assureds * claim_expense_rate * deaths  # Shape: (num_policies, num_months)
        policy_term_ind = jnp.where(policy_attrs['policy_months']<=policy_attrs['policy_terms_months'][:, None],1,0)

        if jnp.all(rider_option == 2):
            # Critical illness Benefit
            ci_benefit = sum_assureds * critical_illness  # Shape: (num_policies, num_months)

            # WOP Benefit (Equal to Base premium on premium payment month)
            net_cumulative_critical_illness_prev = jnp.pad(net_cumulative_critical_illness[:, :-1], ((0, 0), (1, 0)), constant_values=0.0)
            wop_benefit = (base_premiums * modal_factor) * net_cumulative_critical_illness_prev * premium_due_mask * (policy_attrs['projection_steps']>0) * policy_term_ind # Shape: (num_policies, num_months)
        
        elif jnp.all(rider_option ==1):
            adb_benefit = sum_assureds * adb * (policy_attrs['projection_steps']>0) # Shape: (num_policies, num_months)
        else:
            tpd_benefit = sum_assureds * disability
            net_cumulative_disability_prev = jnp.pad(net_cumulative_disability[:, :-1], ((0, 0), (1, 0)), constant_values=0.0)
            wop_benefit = (base_premiums * modal_factor) * net_cumulative_disability_prev * premium_due_mask * (policy_attrs['projection_steps']>0) * policy_term_ind # Shape: (num_policies, num_months)


        # Surrender Benefits (0 for riders)
        surrender_benefits = jnp.zeros_like(premiums)  # Shape: (num_policies, num_months)

        # Net Cash Flows
        if jnp.all(rider_option ==2):
            net_cash_flows = -(premiums - commissions - initial_expense - renewal_expenses - claim_expenses - ci_benefit - wop_benefit - surrender_benefits) * (policy_attrs['projection_steps']>0)
        elif jnp.all(rider_option ==1):
            net_cash_flows = -(premiums - commissions - initial_expense - renewal_expenses - claim_expenses - adb_benefit - surrender_benefits) * (policy_attrs['projection_steps']>0)
        else:
            net_cash_flows = -(premiums - commissions - initial_expense - renewal_expenses - claim_expenses - tpd_benefit - wop_benefit - surrender_benefits) * (policy_attrs['projection_steps']>0)
        
        # Interest on Cashflows
        if layer == 'BE':
            interest_on_cashflows = (premiums - commissions - initial_expense - renewal_expenses - reinsurance_results['reins_premiums']) * monthly_interest_rates 
        else:
            interest_on_cashflows = (premiums - commissions - initial_expense - renewal_expenses) * monthly_interest_rates
            
        interest_on_cashflows = interest_on_cashflows * (policy_attrs['projection_steps'] > 0)

        net_cash_flows -= interest_on_cashflows

        cashflows = {
            'premiums': premiums,
            'commissions': commissions,
            'initial_expense': initial_expense,
            'renewal_expenses': renewal_expenses,
            'claim_expenses': claim_expenses,
            'surrender_benefits': surrender_benefits,
            'interest_on_cashflows': interest_on_cashflows,
            'net_cash_flows': net_cash_flows,
        }

        if jnp.all(rider_option == 2):
            ci_fields = {
            'ci_benefit': ci_benefit,
            'wop_benefit': wop_benefit,
            }
            cashflows.update(ci_fields)

        elif jnp.all(rider_option==1):
            adb_fields = {
                'adb_benefit': adb_benefit,
            }
            cashflows.update(adb_fields)
        
        else:
            tpd_fields = {
                'tpd_benefit': tpd_benefit,
                'wop_benefit': wop_benefit,
            }
            cashflows.update(tpd_fields)

        return cashflows

    def calculate_discounted_cf_reserves(self, policy_attrs, rates, decrements, gross_cf):
        """
        First backward pass - Calculate discounted cash flows and Gross Reserve PP.
        """
        num_policies = policy_attrs['num_policies']
        num_months = policy_attrs['policy_months'].shape[1]
        rider_option = policy_attrs['rider_option']
        policy_months = policy_attrs['policy_months']

        net_cashflows = gross_cf['net_cash_flows']
        lives_so_end = decrements['lives_so_end']
        maturities = decrements['maturities']

        monthly_interest_rates = rates['monthly_VROI_rates']

        # Reverse arrays for backward calculation
        net_cash_flows_rev = net_cashflows[:, ::-1]  # Shape: (num_policies, num_months)
        discount_rates_rev = monthly_interest_rates[::-1]  # Shape: (num_months,)

        # Function to discount cash flows for a single policy
        def discount_policy_cashflows(net_cash_flow_rev):
            def discount_step(carry, inputs):
                discount_rate, net_cf = inputs
                pv_next = carry
                pv = (pv_next + net_cf) / (1 + discount_rate)
                return pv, pv

            init_carry = 0.0
        
            _, discounted_net_cf_rev = lax.scan(
                discount_step,
                init_carry,
                (discount_rates_rev, net_cash_flow_rev)
            )

            return discounted_net_cf_rev

        # Apply the function to each policy
        discounted_net_cf_rev = jax.vmap(discount_policy_cashflows)(net_cash_flows_rev)

        # Reverse back to original order
        discounted_net_cf = discounted_net_cf_rev[:, ::-1]

        discounted_net_cf = discounted_net_cf.at[:, :2].set(0.0)
    
        # Gross and Net Reserves Per Policy
        # Reserves per policy are the discounted net cashflows divided by lives at end
        if self.config.run_type in ['Valuation','CRNHR']:
            discounted_net_cf = jnp.concatenate([discounted_net_cf[:, 1:], jnp.zeros((discounted_net_cf.shape[0], 1))], axis=1)
        else:
            discounted_net_cf = jnp.concatenate([discounted_net_cf[:, 1:], jnp.zeros((discounted_net_cf.shape[0], 1))], axis=1) * (policy_attrs['projection_steps']>0)

        if jnp.all(rider_option ==2):
            net_cumulative_critical_illness = decrements['net_cumulative_critical_illness']
            gross_reserve_pp = discounted_net_cf / jnp.maximum(lives_so_end + maturities + net_cumulative_critical_illness, 1e-6)  # Shape: (num_policies, num_months)
        elif jnp.all(rider_option ==1):
            gross_reserve_pp = discounted_net_cf / jnp.maximum(lives_so_end + maturities, 1e-6)  # Shape: (num_policies, num_months)
        else:
            net_cumulative_disability = decrements['net_cumulative_disability']
            gross_reserve_pp = discounted_net_cf / jnp.maximum(lives_so_end + maturities + net_cumulative_disability, 1e-6)  # Shape: (num_policies, num_months)
        
        gross_reserve_pp = jnp.maximum(gross_reserve_pp, 0.0)  # Prevent negative reserves

        # discount_factors = jnp.cumprod(1 / (1 + monthly_interest_rates[::-1]))[::-1]

        # discounted_net_cf = net_cashflows * discount_factors[None, :]
        # discounted_cf_cumsum = jnp.cumsum(discounted_net_cf[:, ::-1], axis=1)[:, ::-1]

        # gross_reserve_pp = jnp.minimum(
        #     discounted_cf_cumsum / (lives_so_end + maturities + net_cumulative_critical_illness + 1e-8), 0.0
        # )

        # UPR calculation (not specified, but placeholder)
        upr = jnp.zeros_like(gross_reserve_pp)  # Placeholder for UPR calculation
        premium_ind = 12/policy_attrs['premium_frequencies']
        months_due = jnp.where(policy_months % 12==0, premium_ind, policy_months % 12)
        policy_term_ind = jnp.where(policy_attrs['policy_months'] < policy_attrs['policy_terms_months'][:, None],1,0)
        upr = jnp.maximum(0, policy_attrs['rider_premiums']*(premium_ind- months_due+ 0.5)/premium_ind) * (policy_attrs['projection_steps'] > 0) * policy_term_ind

        gross_reserve_pp = jnp.maximum(upr, gross_reserve_pp)

        gross_reserves = {
            'discounted_cf_reserving': discounted_net_cf,
            'gross_reserve_pp': gross_reserve_pp,
            'upr': upr,
        }

        return gross_reserves

    def calculate_reinsurance_cashflows(self, policy_attrs, rates, decrements, gross_cf, gross_reserves):
        """
        Second forward pass - Calculate reinsurance cashflows and net CF with reinsurance.
        """
        num_policies = policy_attrs['num_policies']
        rider_option = policy_attrs['rider_option']
        sum_assureds = policy_attrs['sum_assureds']
        Reinsurance_Retention_Limit = rates['Reinsurance_Retention_Limit']
        Reinsurance_Retention_Proportion = rates['Reinsurance_Retention_Proportion']

        lives_so_begin = decrements['lives_so_begin']
        net_cashflows = gross_cf['net_cash_flows']
        gross_reserve_pp = gross_reserves['gross_reserve_pp']

        # NPV of WOP Benefit
        npv_wop = self.calculate_npv_wop(policy_attrs, rates) * (policy_attrs['projection_steps']>0) # Shape: (num_policies, num_months)

        # Reinsurance Sum Assured
        gross_reserve_pp_prev = jnp.pad(gross_reserve_pp[:, :-1], ((0, 0), (1, 0)), constant_values=0.0)
        reins_sum_assured = jnp.maximum(
            sum_assureds + npv_wop - Reinsurance_Retention_Limit - gross_reserve_pp_prev,
            0.0
        ) * Reinsurance_Retention_Proportion

        # Reinsurance Morbidity Rates
        monthly_reins_morbidity_rates = rates['monthly_reins_morbidity_rates']

        # Reinsurance Premiums and Recoveries
        reins_premiums = reins_sum_assured * monthly_reins_morbidity_rates * lives_so_begin * (policy_attrs['projection_steps']>0)

        if jnp.all(rider_option==2):
            critical_illness = decrements['critical_illness']
            reins_recoveries = reins_sum_assured * critical_illness * (policy_attrs['projection_steps']>0)
        elif jnp.all(rider_option==1):
            adb = decrements['adb']
            reins_recoveries = reins_sum_assured * adb * (policy_attrs['projection_steps']>0)
        else:
            disability = decrements['disability']
            reins_recoveries = reins_sum_assured * disability * (policy_attrs['projection_steps']>0)

        net_cf_with_reinsurance = net_cashflows + reins_premiums - reins_recoveries

        reinsurance_results = {
            'reins_sum_assured': reins_sum_assured,
            'reins_premiums': reins_premiums,
            'reins_recoveries': reins_recoveries,
            'net_cf_with_reinsurance': net_cf_with_reinsurance,
        }

        return reinsurance_results

    def calculate_net_reserves(self, policy_attrs, rates, decrements, reinsurance_results, gross_reserves):
        """
        Second backward pass - Calculate net reserves.
        """
        num_policies = policy_attrs['num_policies']
        num_months = policy_attrs['policy_months'].shape[1]
        rider_option = policy_attrs['rider_option']

        net_cf_with_reinsurance = reinsurance_results['net_cf_with_reinsurance']
        lives_so_end = decrements['lives_so_end']
        maturities = decrements['maturities']

        monthly_interest_rates = rates['monthly_VROI_rates']

        net_cash_flows_rev = net_cf_with_reinsurance[:, ::-1]  # Shape: (num_policies, num_months)
        monthly_interest_rates_rev = monthly_interest_rates[::-1]  # Shape: (num_months,)

        # Function to discount cash flows for a single policy
        def discount_policy_cashflows(net_cash_flow_rev):
            def discount_step(carry, inputs):
                discount_rate, net_cf = inputs
                pv_next = carry
                pv = (pv_next + net_cf) / (1 + discount_rate)
                return pv, pv

            init_carry = 0.0

            _, discounted_net_cf_rev = lax.scan(
                discount_step,
                init_carry,
                (monthly_interest_rates_rev, net_cash_flow_rev)
            )

            return discounted_net_cf_rev

        # Apply the function to each policy
        discounted_net_cf_rev = jax.vmap(discount_policy_cashflows)(net_cash_flows_rev)

        # Reverse back to original order
        discounted_net_cf = discounted_net_cf_rev[:, ::-1]
    
        # Gross and Net Reserves Per Policy
        # Reserves per policy are the discounted net cashflows divided by lives at end
        if self.config.run_type in ['Valuation','CRNHR']:
            discounted_net_cf = jnp.concatenate([discounted_net_cf[:, 1:], jnp.zeros((discounted_net_cf.shape[0], 1))], axis=1)
        else:
            discounted_net_cf = jnp.concatenate([discounted_net_cf[:, 1:], jnp.zeros((discounted_net_cf.shape[0], 1))], axis=1) * (policy_attrs['projection_steps']>0)


        if jnp.all(rider_option == 2):
            net_cumulative_critical_illness = decrements['net_cumulative_critical_illness']
            net_reserve_pp = discounted_net_cf / jnp.maximum(lives_so_end + maturities + net_cumulative_critical_illness, 1e-6)  # Shape: (num_policies, num_months)
        elif jnp.all(rider_option ==1):
            net_reserve_pp = discounted_net_cf / jnp.maximum(lives_so_end + maturities, 1e-6)  # Shape: (num_policies, num_months)
        else:
            net_cumulative_disability = decrements['net_cumulative_disability']
            net_reserve_pp = discounted_net_cf / jnp.maximum(lives_so_end + maturities + net_cumulative_disability, 1e-6)  # Shape: (num_policies, num_months)
            
        net_reserve_pp = jnp.maximum(net_reserve_pp, 0.0)  # Prevent negative 
        net_reserve_pp = jnp.maximum(net_reserve_pp, gross_reserves['upr'])
        
        # discount_factors = jnp.cumprod(1 / (1 + monthly_interest_rates[::-1]))[::-1]

        # discounted_net_cf_with_reins = net_cf_with_reinsurance * discount_factors[None, :]
        # discounted_cf_with_reins_cumsum = jnp.cumsum(discounted_net_cf_with_reins[:, ::-1], axis=1)[:, ::-1]

        # net_reserve_pp = jnp.maximum(
        #     discounted_cf_with_reins_cumsum / (lives_so_end + maturities + net_cumulative_critical_illness + 1e-8), 0.0
        # )

        net_reserves = {
            'discounted_cf_with_reins': discounted_net_cf,
            'net_reserve_pp': net_reserve_pp,
        }

        return net_reserves

    def calculate_be_layer(self, policy_attrs, rates, decrements, reinsurance_results, gross_reserve_pp, net_reserve_pp):
        """
        Third forward pass - BE Layer cashflows, reserves, solvency capital, and profit.
        """
        num_policies = policy_attrs['num_policies']
        rider_option = policy_attrs['rider_option']
        # Use the BE layer cashflows and decrements
        be_cashflows = self.calculate_cash_flows(
            policy_attrs,
            rates,
            decrements,
            reinsurance_results,
            layer='BE'
        )
        net_cf_without_reinsurance = -be_cashflows['net_cash_flows']
        reins_sum_assured = reinsurance_results['reins_sum_assured']
        monthly_reins_morbidity_rates = rates['monthly_reins_morbidity_rates']

        # Reinsurance Premiums and Recoveries
        reins_premiums = reins_sum_assured * monthly_reins_morbidity_rates * decrements['lives_so_begin'] * (policy_attrs['projection_steps'] > 0)
        if jnp.all(rider_option==2):
            critical_illness = decrements['critical_illness']
            reins_recoveries = reins_sum_assured * critical_illness * (policy_attrs['projection_steps']>0)
        elif jnp.all(rider_option==1):
            adb = decrements['adb']
            reins_recoveries = reins_sum_assured * adb * (policy_attrs['projection_steps']>0)
        else:
            disability = decrements['disability']
            reins_recoveries = reins_sum_assured * disability * (policy_attrs['projection_steps']>0)
 
        # Update net cash flows with reinsurance
        be_cashflows['reins_premiums'] = reins_premiums
        be_cashflows['reins_recoveries'] = reins_recoveries
        be_cashflows['net_cash_flows'] = net_cf_without_reinsurance - reins_premiums + reins_recoveries

        # Reserves
        lives_so_end = decrements['lives_so_end']
        maturities = decrements['maturities']

        if jnp.all(rider_option == 2):
            net_cumulative_critical_illness = decrements['net_cumulative_critical_illness']
            be_reserves = net_reserve_pp * (lives_so_end + net_cumulative_critical_illness + maturities) * (policy_attrs['projection_steps']>0)
        elif jnp.all(rider_option ==1):
            be_reserves = net_reserve_pp * (lives_so_end + maturities) * (policy_attrs['projection_steps']>0)
        else:
            net_cumulative_disability = decrements['net_cumulative_disability']
            be_reserves = net_reserve_pp * (lives_so_end + net_cumulative_disability + maturities) * (policy_attrs['projection_steps']>0)

        be_reserves = jnp.maximum(be_reserves, 0.0)* (policy_attrs['projection_steps']>0)

        # Increase in Reserves
        reserve_shifted = jnp.concatenate(
            [self.ZERO_ARRAY[:, [0]], be_reserves[:, :-1]], axis=1)
        increase_in_reserves = be_reserves - reserve_shifted
        increase_in_reserves = increase_in_reserves.at[:, 0].set(be_reserves[:, 0]) * (policy_attrs['projection_steps']>0)

        # Interest on Reserve
        monthly_ROI_rates = rates['monthly_ROI_rates']
        interest_on_reserve = reserve_shifted * monthly_ROI_rates[None, :]
        interest_on_reserve = interest_on_reserve.at[:, 0].set(0.0) * (policy_attrs['projection_steps']>0) 

        # Solvency Capital Calculations
        required_solvency_capital, gross_sar, net_sar = self.calculate_solvency_capital(
            policy_attrs, rates, decrements, be_reserves, gross_reserve_pp, net_reserve_pp, reins_sum_assured
        )

        required_solvency_capital = required_solvency_capital.at[:, 0].set(0.0) 

        # Increase in Solvency Capital
        solvency_capital_shifted = jnp.concatenate(
            [self.ZERO_ARRAY[:, [0]], required_solvency_capital[:, :-1]], axis=1)
        increase_in_solvency_capital = required_solvency_capital - solvency_capital_shifted
        increase_in_solvency_capital = increase_in_solvency_capital.at[:, 0].set(required_solvency_capital[:, 0]) * (policy_attrs['projection_steps']>0)

        # Interest on Solvency Capital
        interest_on_solvency_capital = solvency_capital_shifted * monthly_ROI_rates[None, :]
        interest_on_solvency_capital = interest_on_solvency_capital.at[:, 0].set(0.0) * (policy_attrs['projection_steps']>0)

        # Tax and CSR on Interest on Solvency Capital
        tax_rate = float(self.product_config.variables.get('Tax Rate', 0.0))
        csr_rate = float(self.product_config.variables.get('CSR', 0.0))
        tax_on_interest = interest_on_solvency_capital * tax_rate * (policy_attrs['projection_steps']>0)
        csr_on_interest = interest_on_solvency_capital * csr_rate * (policy_attrs['projection_steps']>0)

        # Cost of Capital
        cost_of_capital = (
            increase_in_solvency_capital - interest_on_solvency_capital + tax_on_interest + csr_on_interest
        ) * (policy_attrs['projection_steps']>0)

        # Profit Calculations
        profit_before_tax = be_cashflows['net_cash_flows'] - increase_in_reserves + interest_on_reserve
        csr = profit_before_tax * csr_rate
        tax = (profit_before_tax - csr) * tax_rate
        net_profit_before_sm = profit_before_tax - csr - tax
        net_profit_after_sm = net_profit_before_sm - cost_of_capital

        be_results = {
            'be_premiums': be_cashflows['premiums'],
            'be_commissions': be_cashflows['commissions'],
            'be_initial_expense': be_cashflows['initial_expense'],
            'be_renewal_expenses': be_cashflows['renewal_expenses'],
            'be_claim_expenses': be_cashflows['claim_expenses'],
            'be_surrender_benefits': be_cashflows['surrender_benefits'],
            'be_reinsurance_premiums': be_cashflows['reins_premiums'],
            'be_reinsurance_recoveries': be_cashflows['reins_recoveries'],
            'be_interest_on_cashflows': be_cashflows['interest_on_cashflows'],
            'be_net_cf': be_cashflows['net_cash_flows'],
            'be_reserves': be_reserves,
            'increase_in_reserves': increase_in_reserves,
            'interest_on_reserves': interest_on_reserve,
            'gross_sar' : gross_sar,
            'net_sar' : net_sar,
            'required_solvency_capital': required_solvency_capital,
            'increase_in_solvency_capital': increase_in_solvency_capital,
            'interest_on_solvency_capital': interest_on_solvency_capital,
            'profit_before_tax': profit_before_tax,
            'csr': csr,
            'tax': tax,
            'net_profit_before_sm': net_profit_before_sm,
            'cost_of_capital': cost_of_capital,
            'net_profit_after_sm': net_profit_after_sm,
        }

        if jnp.all(rider_option ==2):
            ci_fields = {
            'be_ci_benefit': be_cashflows['ci_benefit'],
            'be_wop_benefit': be_cashflows['wop_benefit'],
            }
            be_results.update(ci_fields)

        elif jnp.all(rider_option ==1):
            adb_fields = {
            'be_adb_benefit': be_cashflows['adb_benefit'],
            }
            be_results.update(adb_fields)
        
        else:
            tpd_fields = {
            'be_tpd_benefit': be_cashflows['tpd_benefit'],
            'be_wop_benefit': be_cashflows['wop_benefit'],
            }
            be_results.update(tpd_fields)
            
        return be_results

    def calculate_solvency_capital(self, policy_attrs, rates, decrements, be_reserves, gross_reserve_pp, net_reserve_pp, reins_sum_assured):
        """
        Calculates solvency capital.

        Returns:
            required_solvency_capital: Solvency capital required at each time step.
        """
        sum_assureds = policy_attrs['sum_assureds']
        lives_so_end = decrements['lives_so_end']
        rider_option = policy_attrs['rider_option']
        maturities = decrements['maturities']

        if jnp.all(rider_option == 2):
            net_cumulative_critical_illness = decrements['net_cumulative_critical_illness']
            # Gross Sum at Risk
            gross_sar = sum_assureds * (lives_so_end + maturities) - be_reserves
            # Net Sum at Risk
            net_sar = (sum_assureds - reins_sum_assured) * (lives_so_end + maturities) - be_reserves
        elif jnp.all(rider_option ==1):
            gross_sar = sum_assureds * (lives_so_end + maturities) - be_reserves
            net_sar = (sum_assureds - reins_sum_assured) * (lives_so_end + maturities)- be_reserves
        else:
            net_cumulative_disability = decrements['net_cumulative_disability']
            gross_sar = sum_assureds * (lives_so_end + maturities) - be_reserves
            net_sar = (sum_assureds - reins_sum_assured) * (lives_so_end + maturities) - be_reserves

        gross_sar = np.maximum(gross_sar, 0.0)
        net_sar = np.maximum(net_sar, 0.0)

        # Solvency Margin parameters
        Solvency_Margin_1_factor = float(self.product_config.variables.get('Part 1 SM', 0.0))
        Solvency_Margin_2_factor = float(self.product_config.variables.get('Part 2 SM', 0.0))
        Part1_net_to_gross_factor = float(self.product_config.variables.get('Part 1 net to gross factor', 1.0))
        Part2_net_to_gross_factor = float(self.product_config.variables.get('Part 2 net to gross factor', 1.0))
        Solvency_Ratio = float(self.product_config.variables.get('Solvency ratio', 1.0))

        # Part 1 SM
        net_to_gross_reserve_ratio = jnp.minimum(
            1.0,
            jnp.where(
                gross_reserve_pp != 0,
                net_reserve_pp / (gross_reserve_pp + 1e-6),
                1.0
            )
        )
        net_to_gross_reserve_ratio = jnp.minimum(jnp.maximum(net_to_gross_reserve_ratio, Part1_net_to_gross_factor), 1.0)
        part1_sm = be_reserves * Solvency_Margin_1_factor * net_to_gross_reserve_ratio * Solvency_Ratio

        # Part 2 SM
        net_to_gross_sar_ratio = jnp.minimum(
            1.0,
            jnp.where(
                gross_sar != 0,
                net_sar / (gross_sar + 1e-6),
                1.0
            )
        )
        net_to_gross_sar_ratio = jnp.maximum(net_to_gross_sar_ratio, Part2_net_to_gross_factor)
        part2_sm_mask = (policy_attrs['policy_months'] < policy_attrs['policy_terms_months'][:, None])
        part2_sm = gross_sar * Solvency_Margin_2_factor * net_to_gross_sar_ratio * Solvency_Ratio * part2_sm_mask
        required_solvency_capital = part1_sm + part2_sm
        required_solvency_capital = jnp.maximum(required_solvency_capital, 0.0) 

        return required_solvency_capital, gross_sar, net_sar

    def calculate_npv_wop(self, policy_attrs: Dict[str, Any], rates) -> jnp.ndarray:
        """
        Calculates the Net Present Value (NPV) of WOP benefits using a fixed discount rate from product config.
        """
        # Get discount rate from product config
        discount_rate = float(self.product_config.variables.get('Int rate to calculate PV of WOP', 0.0))
        monthly_discount_rate = (1 + discount_rate) ** (1 / 12) - 1
        shape = np.zeros_like(rates['monthly_ROI_rates'] )
        shape = shape + 1
        shape[0] = 0
        monthly_discount_rate = monthly_discount_rate * shape
        
        # Base premiums
        premium_due_mask = jnp.where((policy_attrs['premium_frequencies']==12), 1,(((policy_attrs['policy_months'] % (12/policy_attrs['premium_frequencies']))) == 1).astype(FLOAT_DTYPE))        
        premium_due_mask = premium_due_mask * (policy_attrs['projection_steps'] > 0).astype(FLOAT_DTYPE)  # Exclude time 0
        # premium_due_mask = ((policy_attrs['policy_months'] - 1) % (12 / policy_attrs['premium_frequencies']) == 0).astype(FLOAT_DTYPE).at[:,0].set(0.)
        future_premium_mask = policy_attrs['policy_months'] <= policy_attrs['policy_terms_months'][:, None]
        
        base_premiums = (policy_attrs['base_premiums'] * rates['modal_factor']) * premium_due_mask * future_premium_mask
        base_premiums_rev = base_premiums[:, ::-1] 
        monthly_discount_rate_rev = monthly_discount_rate[::-1]

        def discount_policy_cashflows(base_premiums_rev):
            def discount_step(carry, inputs):
                discount_rate, net_cf = inputs
                pv_next = carry
                pv = (pv_next + net_cf) / (1 + discount_rate)
                return pv, pv

            init_carry = 0.0

            _, discounted_base_premiums_rev = lax.scan(
                discount_step,
                init_carry,
                (monthly_discount_rate_rev, base_premiums_rev)
            )

            return discounted_base_premiums_rev
        
        discounted_base_premiums_rev = jax.vmap(discount_policy_cashflows)(base_premiums_rev)

        npv_wop = discounted_base_premiums_rev[:, ::-1]
        npv_wop = jnp.concatenate([npv_wop[:, 1:], jnp.zeros((npv_wop.shape[0], 1))], axis=1) * (policy_attrs['projection_steps']>0)

        # remaining_months = (policy_attrs['policy_terms_months'][:, None] - policy_attrs['policy_months'] + 1).clip(min=0)  # Shape: (num_policies, num_months)

        # Present Value Factors
        # pv_factors = (1 - (1 + monthly_discount_rate) ** (-remaining_months)) / monthly_discount_rate  # Shape: (num_policies, num_months)

        # NPV of WOP benefit
        # npv_wop = base_premiums * pv_factors  # Shape: (num_policies, num_months)

        # discount_factors = (1 + monthly_discount_rate) ** jnp.arange(policy_attrs['policy_months'].shape[1])
        # discount_factors = (1 + monthly_discount_rate) ** policy_attrs['projection_steps']

        # Calculate discounted cash flows for all future periods at each time period
        # discounted_cf = base_premiums / discount_factors[None, :]  # Apply discount factors

        # NPV at each time period is the cumulative sum of future discounted cash flows
        # npv_wop = jnp.cumsum(discounted_cf[:, ::-1], axis=1)[:, ::-1] # Reverse cumulative sum
        # npv_wop = (npv_wop * discount_factors) - base_premiums

        return npv_wop

    def calculate_pv_variables(self, policy_attrs, rates, be_results, reinsurance_results, decrements, batch_policy_numbers):
        """
        Third backward pass - Calculate MCEV, BEL, PVFP, and FCC.
        """
        num_policies = policy_attrs['num_policies']
        num_months = policy_attrs['policy_months'].shape[1]
        premiums = be_results['be_premiums']
        commissions = be_results['be_commissions']
        initial_expense = be_results['be_initial_expense']
        renewal_expenses = be_results['be_renewal_expenses']
        be_reserves = be_results['be_reserves']
        be_net_cf = be_results['be_net_cf']
        be_interest_on_cashflows = be_results['be_interest_on_cashflows']
        be_inc_in_reserves = be_results['increase_in_reserves']
        required_solvency_capital = be_results['required_solvency_capital']
        net_profit_before_sm = be_results['net_profit_before_sm']
        required_solvency_capital = be_results['required_solvency_capital']
        increase_in_solvency_capital = be_results['increase_in_solvency_capital']
        interest_on_solvency_capital = be_results['interest_on_solvency_capital']
        rider_option = policy_attrs['rider_option']
        policy_months = policy_attrs['policy_months']

        monthly_CCIL_rates = rates['monthly_CCIL_rates']
        tax_rate = float(self.product_config.variables.get('Tax Rate', 0.0))
        csr_rate = float(self.product_config.variables.get('CSR', 0.0))

        interest_on_cashflows = (premiums - commissions - initial_expense - renewal_expenses - reinsurance_results['reins_premiums']) * monthly_CCIL_rates
        interest_on_cashflows = interest_on_cashflows * (policy_attrs['projection_steps'] > 0)

        reserve_shifted = jnp.concatenate(
            [self.ZERO_ARRAY[:, [0]], be_reserves[:, :-1]], axis=1)

        # Interest on Reserve
        interest_on_reserve = reserve_shifted * monthly_CCIL_rates[None, :] * (policy_attrs['projection_steps']>0)
        interest_on_reserve = interest_on_reserve.at[:, 0].set(0.0)

        net_cf = be_net_cf - be_interest_on_cashflows + interest_on_cashflows
        profit_before_tax = net_cf - be_inc_in_reserves + interest_on_reserve
        csr = profit_before_tax * csr_rate
        tax = (profit_before_tax-csr)*tax_rate
        net_profit = profit_before_tax - csr - tax

        # discount_factors = jnp.cumprod(1 / (1 + monthly_CCIL_rates[::-1]))[::-1]
        monthly_interest_rates_rev = monthly_CCIL_rates[::-1]  # Shape: (num_months,)

        def discount_policy_cashflows(cash_flow_rev):
            def discount_step(carry, inputs):
                discount_rate, net_cf = inputs
                pv_next = carry
                pv = (pv_next + net_cf) / (1 + discount_rate)
                return pv, pv

            init_carry = 0.0

            _, discounted_rev = lax.scan(
                discount_step,
                init_carry,
                (monthly_interest_rates_rev, cash_flow_rev)
            )

            return discounted_rev

        # PVFP
        net_profit_rev = net_profit[:, ::-1]  # Shape: (num_policies, num_months)
        disc_net_profit_rev = jax.vmap(discount_policy_cashflows)(net_profit_rev)
        disc_net_profit = disc_net_profit_rev[:, ::-1]
        pvfp = jnp.concatenate([disc_net_profit[:, 1:], jnp.zeros((disc_net_profit.shape[0], 1))], axis=1)

        # discounted_net_profit = net_profit_before_sm * discount_factors[None, :]
        # pvfp = jnp.cumsum(discounted_net_profit[:, ::-1], axis=1)[:, ::-1]

        # PV Premium
        def discount_premium_cashflows(cash_flow_rev):
            def discount_step(carry, inputs):
                discount_rate, net_cf = inputs
                pv_next = carry
                pv = net_cf + pv_next / (1 + discount_rate)
                return pv, pv

            init_carry = 0.0

            _, discounted_rev = lax.scan(
                discount_step,
                init_carry,
                (monthly_interest_rates_rev, cash_flow_rev)
            )

            return discounted_rev
        be_premiums = be_results['be_premiums']
        be_premiums_rev = be_premiums[:, ::-1]  # Shape: (num_policies, num_months)
        disc_be_premiums_rev = jax.vmap(discount_premium_cashflows)(be_premiums_rev)
        disc_be_premiums = disc_be_premiums_rev[:, ::-1]
        pv_premium = jnp.concatenate([disc_be_premiums[:, 1:], jnp.zeros((disc_be_premiums.shape[0], 1))], axis=1)
        
        # discounted_premiums = be_premiums * discount_factors[None, :]
        # pv_premium = jnp.cumsum(discounted_premiums[:, ::-1], axis=1)[:, ::-1]

        # BEL
        # be_net_cf = be_results['be_net_cf']
        net_cf_rev = net_cf[:, ::-1]  # Shape: (num_policies, num_months)
        disc_net_cf_rev= jax.vmap(discount_policy_cashflows)(net_cf_rev)
        disc_net_cf = disc_net_cf_rev[:, ::-1]
        bel = jnp.concatenate([disc_net_cf[:, 1:], jnp.zeros((disc_net_cf.shape[0], 1))], axis=1)
        if jnp.all(rider_option == 2):
            net_cumulative_critical_illness = decrements['net_cumulative_critical_illness']
            bel_pp = -bel / (decrements['lives_so_end'] + decrements['maturities'] + net_cumulative_critical_illness)  # Shape: (num_policies, num_months)
        elif jnp.all(rider_option ==1):
            bel_pp = -bel / (decrements['lives_so_end'] + decrements['maturities'])  # Shape: (num_policies, num_months)
        else:
            net_cumulative_disability = decrements['net_cumulative_disability']
            bel_pp = -bel / (decrements['lives_so_end'] + decrements['maturities'] + net_cumulative_disability)  # Shape: (num_policies, num_months)


        # bel_pp = -bel/(decrements['lives_so_end'] + decrements['maturities'])
        
        # discounted_be_net_cf = be_net_cf * discount_factors[None, :]
        # bel = jnp.cumsum(discounted_be_net_cf[:, ::-1], axis=1)[:, ::-1]

        # Frictional Cost of Capital (FCC)
        required_solvency_capital_shifted = jnp.concatenate(
            [self.ZERO_ARRAY[:, [0]], required_solvency_capital[:, :-1]], axis=1)
        
        interest_on_sm = required_solvency_capital_shifted * monthly_CCIL_rates
        tax_on_int_on_sm = interest_on_sm * tax_rate
        csr_on_int_on_sm = interest_on_sm * csr_rate
        coc = increase_in_solvency_capital - interest_on_sm + tax_on_int_on_sm + csr_on_int_on_sm


        # interest_on_solvency_capital_mcev = required_solvency_capital * monthly_CCIL_rates[None, :]
        # tax_on_interest_sc_mcev = interest_on_solvency_capital_mcev * tax_rate
        # csr_on_interest_sc_mcev = interest_on_solvency_capital_mcev * csr_rate
        # cost_of_capital_mcev = increase_in_solvency_capital - interest_on_solvency_capital_mcev + \
        #                        tax_on_interest_sc_mcev + csr_on_interest_sc_mcev

        coc_rev = coc[:, ::-1]  # Shape: (num_policies, num_months)
        disc_coc_rev= jax.vmap(discount_policy_cashflows)(coc_rev)
        disc_coc = disc_coc_rev[:, ::-1]
        fcc = jnp.concatenate([disc_coc[:, 1:], jnp.zeros((disc_coc.shape[0], 1))], axis=1)

        # discounted_coc_mcev = cost_of_capital_mcev * discount_factors[None, :]
        # fcc = jnp.cumsum(discounted_coc_mcev[:, ::-1], axis=1)[:, ::-1]

        # IFRS BEL
        premium_amounts = policy_attrs['base_premiums']
        sum_assureds = policy_attrs['sum_assureds']
        commission_rates = rates['commission_rates']
        ifrs_premiums = be_premiums
        deaths = decrements['deaths']
        
        #ifrs_death_benefits = sum_assureds * deaths
        if jnp.all(rider_option == 2):
            ifrs_death_benefits = be_results['be_ci_benefit'] + be_results['be_wop_benefit']
        elif jnp.all(rider_option ==1):
            ifrs_death_benefits = be_results['be_adb_benefit']
        else:
            ifrs_death_benefits = be_results['be_tpd_benefit'] + be_results['be_wop_benefit']

        ifrs_surrender_benefits = jnp.zeros_like(ifrs_premiums)
        lives_so_end = decrements['lives_so_end']
        lives_so_begin = decrements['lives_so_begin']
        maturities = decrements['maturities']
        projection_steps = policy_attrs['projection_steps']

        # Instantiate the IFRS17 class and load the data
        ifrs17_init = IFRS17(self.config.table_index, self.config, self.product_name)
        ifrs17_init.load_data()

        starting_policy_month = policy_attrs['policy_months']
        
        valuation_month = self.config.valuation_date.month

        if valuation_month > 3:
            month_shift_locked_in = abs(valuation_month - 4)
        else:
            month_shift_locked_in = abs(valuation_month - 4 + 12)

        month_shift_current = abs(month_shift_locked_in - 13)

        # Access the IFRS ROI rates
        ifrs_current_rate_raw = ifrs17_init.get_monthly_rates('if17_Current_ROI')
        ifrs_current_rate = ifrs_current_rate_raw
        ifrs_current_rate = np.concatenate([ np.zeros(month_shift_current), ifrs_current_rate[:-(month_shift_current)] ])  
        ifrs_current_rate_array = np.tile(ifrs_current_rate, (num_policies, 1)) 
        
        ifrs_locked_in_rate_raw = ifrs17_init.get_monthly_rates('if17_Locked_in_Rate')
        
        ifrs_locked_in_rate = ifrs_locked_in_rate_raw[month_shift_locked_in:]
        ifrs_locked_in_rate = np.concatenate([np.zeros(1), ifrs_locked_in_rate[:-1]])
        ifrs_locked_in_rate = np.concatenate([ ifrs_locked_in_rate, np.zeros(month_shift_locked_in)])
        ifrs_locked_in_rate_array = np.tile(ifrs_locked_in_rate, (num_policies, 1)) 
        

        ifrs_ccil_rate_raw = ifrs17_init.get_monthly_rates('if17_CCIL Fwd Rates')
        
        num_policies, projection_months = starting_policy_month.shape
        ifrs_ccil_rate_list = []

        indicator = (policy_months - 1) // 12 + 1

        for i in range(num_policies):
            # Take the first month for each policy (e.g. starting_policy_month[i, 0])
            start_month = int(starting_policy_month[i, 0])  # assuming all cols are same start for that policy

            # Start from start_month, shift by 1 (add 0 in front), remove last
            rate_slice = ifrs_ccil_rate_raw[start_month:]
            shifted = np.concatenate([np.zeros(1), rate_slice[:-1]])

            # Pad to match projection length
            if len(shifted) < projection_months:
                shifted = np.concatenate([shifted, np.zeros(projection_months - len(shifted))])
            elif len(shifted) > projection_months:
                shifted = shifted[:projection_months]

            # Add to list
            ifrs_ccil_rate_list.append(shifted)
        

        # Convert the list to a numpy array
        ifrs_ccil_rate = ifrs_ccil_rate_list[0]
        ifrs_ccil_rate_array = np.array(ifrs_ccil_rate_list)

        for policy_idx in range(num_policies):
            # DYNAMICALLY select the correct rate array for the CURRENT policy
            ifrs_ccil_rate = ifrs_ccil_rate_array[policy_idx]
            # Reverse the rates for the current policy
            ccil_discount_rates_rev = ifrs_ccil_rate[::-1]


        # Multiply the initial expense with the IFRS initial expense multiplier

        ifrs_initial_expenses = (be_results['be_initial_expense'] * ifrs17_init.ifrs17_multiplier_initial_expenses) + be_results['be_commissions']

        # Calculate the IFRS17 renewal expenses
        IFRS_Renewal_Fixed_expenses = ifrs17_init.get_renewal_expense_rates('Fixed expenses')
        IFRS17_Prem_expenses = ifrs17_init.get_renewal_expense_rates('% of Prem')
        IFRS17_Claim_expenses = ifrs17_init.get_renewal_expense_rates('Claim expenses')
        
        ifrs_renewal_fixed_expenses = IFRS_Renewal_Fixed_expenses
        # Shift ifrs_renewal_fixed_expenses down by 1 row
        ifrs_renewal_fixed_expenses = np.insert(ifrs_renewal_fixed_expenses[:-1], 0, 0.0)

        # Calculate the start month offset for each policy individually
        start_month_offsets = starting_policy_month[:, 0]  # Assuming starting_policy_month is a 2D array with shape (num_policies, num_months)
        premium_frequency = policy_attrs['premium_frequencies']

        # Adjust IFRS17_Prem_expenses for each policy based on its start month offset
        IFRS17_Prem_expenses = IFRS17_Prem_expenses.reshape(1, -1)
        adjusted_IFRS17_Prem_expenses = []
        for policy_idx, start_month_offset in enumerate(start_month_offsets):
            # Check if the premium frequency is 12 (annual)
            if premium_frequency[policy_idx, 0] >1:  # Assuming premium_frequency is a 2D array
                
                IFRS17_Prem_expenses_policy = IFRS17_Prem_expenses[:, start_month_offset - 1:]

                # Add padding to match the projection length
                padding_length = projection_months - IFRS17_Prem_expenses_policy.shape[1]
                if padding_length > 0:
                    padding = jnp.zeros((1, padding_length))
                    IFRS17_Prem_expenses_policy = jnp.concatenate([IFRS17_Prem_expenses_policy, padding], axis=1)
    
                if IFRS17_Prem_expenses_policy.ndim == 1:
                    IFRS17_Prem_expenses_policy = IFRS17_Prem_expenses_policy.reshape(1, -1) 
                
                last_value = 0

                # Iterate over the months in 12-month blocks
                for i in range(2, IFRS17_Prem_expenses_policy.shape[1], 12):  # Step by 12 months
                    # Find the first non-zero value in the current 12-month block
                    block_start = i
                    block_end = min(i + 12, IFRS17_Prem_expenses_policy.shape[1])  # Ensure we don't go out of bounds
                    block_values = IFRS17_Prem_expenses_policy[0, block_start:block_end]

                    # Check if there is any non-zero value in the block
                    non_zero_indices = jnp.where(block_values != 0)[0]
                    if len(non_zero_indices) > 0:
                        # Use the first non-zero value in the block
                        first_non_zero_value = block_values[non_zero_indices[0]]
                    else:
                        # If no non-zero value is found, use the last value from the previous block
                        first_non_zero_value = last_value

                    # Update the block with the repeated value
                    IFRS17_Prem_expenses_policy = IFRS17_Prem_expenses_policy.at[0, block_start:block_end].set(first_non_zero_value)

                    # Update the last_value for the next block
                    last_value = first_non_zero_value

            else:
                # Slice dynamically for the current policy
                IFRS17_Prem_expenses_policy = IFRS17_Prem_expenses[:, start_month_offset - 1:]
    
                # Add padding to match the projection length
                padding_length = projection_months - IFRS17_Prem_expenses_policy.shape[1]
                if padding_length > 0:
                    padding = jnp.zeros((1, padding_length))
                    IFRS17_Prem_expenses_policy = jnp.concatenate([IFRS17_Prem_expenses_policy, padding], axis=1)
    
            adjusted_IFRS17_Prem_expenses.append(IFRS17_Prem_expenses_policy)

        # Convert the list back to a single array
        adjusted_IFRS17_Prem_expenses = jnp.concatenate(adjusted_IFRS17_Prem_expenses, axis=0)


        ifrs_premiums_reshape = ifrs_premiums.reshape(-1, len(ifrs_renewal_fixed_expenses))  # Reshape with dynamic number of policies
        
        ifrs_renewal_prem_expenses = adjusted_IFRS17_Prem_expenses * ifrs_premiums_reshape
        
        combined_renewal_expenses = be_results['be_commissions'] + ifrs_renewal_fixed_expenses + ifrs_renewal_prem_expenses
        
         # Calculate claim expense
        ifrs_claim_expense = IFRS17_Claim_expenses * deaths

        #BEL Calculation (Gross of reinsurance and adjusted for I17 Expenses)
        # Calculate the BEL CF
        ifrs_bel_cf =  ifrs_death_benefits + ifrs_surrender_benefits + ifrs_initial_expenses + combined_renewal_expenses + ifrs_claim_expense - ifrs_premiums

        # Calculate BEL at Onerous Tagging Rate
        bel_at_onerous_tagging_rate = ifrs_bel_cf - ((ifrs_premiums - ifrs_initial_expenses - combined_renewal_expenses) * ifrs_ccil_rate)

         # Reverse arrays for backward calculation
        bel_at_onerous_tagging_rate_rev = bel_at_onerous_tagging_rate[:, ::-1]  # Shape: (num_policies, num_months)
        
        # Create an array to store reversed discount rates for all policies
        discount_rates_rev_array = np.zeros_like(ifrs_ccil_rate_array)

        # Populate the array with reversed rates for each policy
        for policy_idx in range(num_policies):
            ifrs_ccil_rate = ifrs_ccil_rate_array[policy_idx]
            discount_rates_rev_array[policy_idx] = ifrs_ccil_rate[::-1]

        # Function to discount cash flows for a single policy
        def discount_policy_cashflows(net_cash_flow_rev,discount_rates_rev):
            def discount_step(carry, inputs):
                discount_rate, net_cf = inputs
                pv_next = carry
                pv = (pv_next + net_cf) / (1 + discount_rate)
                return pv, pv

            init_carry = 0.0

            _, discounted_net_cf_rev = lax.scan(
                discount_step,
                init_carry,
                (discount_rates_rev, net_cash_flow_rev)
            )

            return discounted_net_cf_rev

        # Apply the function to each policy
        discounted_bel_at_onerous_tagging_rate_rev = jax.vmap(discount_policy_cashflows)(bel_at_onerous_tagging_rate_rev,discount_rates_rev_array)

        # Reverse back to original order
        discounted_bel_at_onerous_tagging_rate = discounted_bel_at_onerous_tagging_rate_rev[:, ::-1]

        # Shift the array by one row up
        discounted_bel_at_onerous_tagging_rate_shifted_up = discounted_bel_at_onerous_tagging_rate[:, 1:]

        discounted_bel_at_onerous_tagging_rate_shifted_up = np.hstack([discounted_bel_at_onerous_tagging_rate_shifted_up, np.zeros((discounted_bel_at_onerous_tagging_rate.shape[0], 1))])

        # Calculate BEL PP at Onerous tagging rate
        if jnp.all(rider_option == 2):
            net_cumulative_critical_illness = decrements['net_cumulative_critical_illness']
            bel_pp_at_onerous_tagging_rate = discounted_bel_at_onerous_tagging_rate_shifted_up/ (lives_so_end + maturities + net_cumulative_critical_illness)  # Shape: (num_policies, num_months)
        elif jnp.all(rider_option ==1):
            bel_pp_at_onerous_tagging_rate = discounted_bel_at_onerous_tagging_rate_shifted_up / (lives_so_end + maturities)  # Shape: (num_policies, num_months)
        else:
            net_cumulative_disability = decrements['net_cumulative_disability']
            bel_pp_at_onerous_tagging_rate = discounted_bel_at_onerous_tagging_rate_shifted_up / (lives_so_end + maturities + net_cumulative_disability)  # Shape: (num_policies, num_months)
        
        # discounted_be_net_cf = be_net_cf * discount_factors[None, :]
        # bel = jnp.cumsum(discounted_be_net_cf[:, ::-1], axis=1)[:, ::-1]

        # Calculate the PV of Expenses using Locked-In Rate
        combined_expenses_rev = combined_renewal_expenses[:, ::-1]  # Reverse for backward calculation
        discount_rates_locked_in_rev = ifrs_locked_in_rate[::-1]  # Reverse the locked-in rates

        # Function to discount expenses for a single policy
        def discount_expenses(expenses_rev):
            def discount_step(carry, inputs):
                discount_rate, expense = inputs
                pv_next = carry
                pv = (pv_next  / (1 + discount_rate)) + expense
                return pv, pv

            init_carry = 0.0

            _, discounted_expenses_rev = lax.scan(
                discount_step,
                init_carry,
                (discount_rates_locked_in_rev, expenses_rev)
            )

            return discounted_expenses_rev

        # Apply the function to each policy
        discounted_expenses_rev = jax.vmap(discount_expenses)(combined_expenses_rev)

        # Reverse back to original order
        discounted_expenses = discounted_expenses_rev[:, ::-1]

        discounted_expenses_shifted_up = discounted_expenses[:, 1:]

        discounted_expenses_shifted_up = np.hstack([discounted_expenses_shifted_up, np.zeros((discounted_expenses.shape[0], 1))])

        # Calculate adjusted px
        
        if jnp.all(rider_option == 2):
            adj_px = lives_so_begin + net_cumulative_critical_illness  # Shape: (num_policies, num_months)
        elif jnp.all(rider_option ==1):
            adj_px = lives_so_begin  # Shape: (num_policies, num_months)
        else:
            adj_px = lives_so_begin + net_cumulative_disability  # Shape: (num_policies, num_months)
        

        # Calculate the length of the arrays after flattening
        num_entries = policy_attrs['policy_months'].size  # Assuming policy_months is a 2D array

        # Repeat the batch_policy_numbers to match the number of entries
        policy_number_array = np.repeat(batch_policy_numbers, num_entries // len(batch_policy_numbers))
        policy_month_array = np.array(policy_attrs['policy_months']).flatten()[:num_entries]
        calendar_month_array = np.tile(policy_attrs['calendar_months'], len(batch_policy_numbers))[:num_entries]
        projection_steps = np.tile(policy_attrs['projection_steps'], len(batch_policy_numbers))[:num_entries]

        # Retrieve additional variables
        additional_variables = ifrs17_init.get_additional_variables()

        # Access v
        ifrs_v = additional_variables['IFRS17_V']
        ifrs_stress_v = additional_variables['IFRS17_Stress_V']

        # Calculate DF
        base_df = np.zeros(num_months)
        # Assuming policy_months is a range or list of month indices
        for i in list(range(1, num_months + 1)):
            if i < 3:
                base_df[i - 1] = 1
            else:
                base_df[i - 1] = ifrs_v ** (i - 1)

    
        stress_df = np.zeros(num_months)
        for i in list(range(1, num_months + 1)):
            if i < 3:
                stress_df[i - 1] = 1
            else:
                stress_df[i - 1] = ifrs_stress_v ** (i - 1)
        num_months   = self.projection_months
        
        # Build discount-factor arrays: shape (num_months,) for base & stress
        t_index     = jnp.arange(num_months)  # [0..num_months-1]
        df_base     = base_df
        df_stress   = stress_df

        # Function to compute the annuity-factor “vector” for one policy
        # e.g. a reversed cumulative sum of (adjusted_px * discount_factors).
        def annuity_factor_for_one_policy(px_for_policy: jnp.ndarray, df: jnp.ndarray) -> jnp.ndarray:
            rev_mult = px_for_policy[::-1] * df[::-1]      # shape (num_months,)
            rev_cumsum    = jnp.cumsum(rev_mult, axis=0) # partial sums in reverse
            partial_sums  = rev_cumsum[::-1]                  # shape (num_months,)

            return partial_sums / (df*px_for_policy )

        # Vectorize across all policies using jax.vmap
        annuity_factors_base_array = jax.vmap(lambda px: annuity_factor_for_one_policy(px, df_base))(adj_px)
        
         # Access stress expense
        stress_expense = additional_variables['IFRS17_Stress_Expense']
        
        annuity_factors_stress_array = jax.vmap(lambda px: annuity_factor_for_one_policy(px, df_stress))(adj_px)
        annuity_factors_stress_array = annuity_factors_stress_array*stress_expense

        # Access extra inflation
        stress_inflation = additional_variables['IFRS17_Stress_Inflation']

        # Calculate extra inflation
        ifrs_stress_inflation = np.zeros(num_months)
        for i in list(range(1, num_months + 1)):
            if i < 3:
                ifrs_stress_inflation[i - 1] = 1
            else:
                ifrs_stress_inflation[i - 1] = (1 + stress_inflation) ** (i - 2)


        # Calculate stress expense
        #stress_expense = np.tile(stress_expense, num_entries)
        stress_expense = np.full(policy_months.shape, stress_expense)
        
        ifrs_stress_expense = ifrs_renewal_fixed_expenses + ifrs_renewal_prem_expenses*stress_expense*ifrs_stress_inflation

        # Calculate the PV of Stress Expenses using Locked-In Rate
        ifrs_stress_expense_rev = ifrs_stress_expense[:, ::-1]  # Reverse for backward calculation
        discount_rates_locked_in_rev = ifrs_locked_in_rate[::-1]  # Reverse the locked-in rates

        # Function to discount expenses for a single policy
        def discount_expenses(stress_expenses_rev):
            def discount_step(carry, inputs):
                discount_rate, expense = inputs
                pv_next = carry
                pv = pv_next / (1 + discount_rate) + expense
                return pv, pv

            init_carry = 0.0

            _, discounted_stress_expenses_rev = lax.scan(
                discount_step,
                init_carry,
                (discount_rates_locked_in_rev, stress_expenses_rev)
            )

            return discounted_stress_expenses_rev

        # Apply the function to each policy
        discounted_stress_expenses_rev = jax.vmap(discount_expenses)(ifrs_stress_expense_rev)

        # Reverse back to original order
        discounted_stress_expenses = discounted_stress_expenses_rev[:, ::-1]

        discounted_stress_expenses_shifted_up = discounted_stress_expenses[:, 1:]

        discounted_stress_expenses_shifted_up = np.hstack([discounted_stress_expenses_shifted_up, np.zeros((discounted_stress_expenses.shape[0], 1))])

        # Calculate Expense Capital
        ifrs_expense_captial = discounted_stress_expenses_shifted_up - discounted_expenses_shifted_up
        

        pv_results = {
            'interest_on_cashflows':interest_on_cashflows,
            'interest_on_reserve':interest_on_reserve,
            'net_cf':net_cf,    
            'profit_before_tax':profit_before_tax,
            'csr':csr,
            'tax':tax,
            'net_profit':net_profit,
            'pvfp': pvfp,
            'pv_premium': pv_premium,
            'interest_on_sm':interest_on_sm,
            'tax_interest_on_sm': tax_on_int_on_sm,
            'csr_interest_on_sm': csr_on_int_on_sm,
            'coc':coc,
            'fcc': fcc,
            'bel': bel,
            'bel_pp':bel_pp,
            'ifrs_bel': discounted_bel_at_onerous_tagging_rate_shifted_up,
            'ifrs_bel_pp': bel_pp_at_onerous_tagging_rate,
            'ifrs_expense_capital': ifrs_expense_captial,
        }

        return pv_results
