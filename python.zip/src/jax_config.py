# jax_config.py

import jax
import jax.numpy as jnp

# Set default data types
FLOAT_DTYPE = jnp.float64
INT_DTYPE = jnp.int32

# Enable 64-bit precision if needed
jax.config.update("jax_enable_x64", True)

# Configure JIT compilation settings
JIT_COMPILE = True  # Set to False to disable JIT for debugging

# Configure parallel computation
PARALLEL = True  # Set to False if you want to run on a single CPU core