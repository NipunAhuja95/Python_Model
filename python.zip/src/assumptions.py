# src/assumptions.py

import pandas as pd
import jax.numpy as jnp
from pathlib import Path
from typing import Dict

from src.logger import Logger
from src.config import TableIndex, RunConfig
from src.jax_config import FLOAT_DTYPE, INT_DTYPE

from jax import vmap
import re

class Assumptions:
    def __init__(self, table_index: TableIndex, root_folder: Path):
        self.table_index = table_index
        self.root_folder = root_folder

    def read_table(self, table_name: str, **kwargs) -> pd.DataFrame:
        """Read a table using the table index"""
        return self.table_index.read_table(table_name, **kwargs)

    def get_file_path(self, table_name: str) -> Path:
        """
        Get file path for backward compatibility with existing code.
        This method will be deprecated in future versions.
        """
        return self.table_index.get_file_path(table_name)


class Expense(Assumptions):
    def __init__(self, table_index: TableIndex, root_folder: Path, product: str):
        super().__init__(table_index, root_folder)
        self.product = product.upper()
        self.initial_expenses = None  # JAX array for initial expenses
        self.renewal_expenses = None  # Dictionary for renewal expenses
        self.logger = Logger()

    def load_data(self):
        if self.product == 'BASE_TERM':
            expense_table_name = 'Expense_Rate_Term'
        elif self.product == 'GCL' or self.product == 'GCL':
            expense_table_name = 'Expense_Rate_GCL'
        elif self.product in ['RIDER_CI', 'RIDER_ADB', 'RIDER_ATPD']:
            expense_table_name = 'Expense_Rate_Rider'
        else:
            raise NotImplementedError(f"Expense assumptions for product '{self.product}' not implemented.")

        df = self.read_table(expense_table_name)

        # Standardize 'Expense_Type' to uppercase and strip whitespace
        df['Expense_Type'] = df['Expense_Type'].str.upper().str.strip()
        # Removed Product filtering
        # product_upper = self.product.upper().strip()

        # Filter Initial Expenses for the specified product
        initial_df = df[df['Expense_Type'] == 'INITIAL']

        if initial_df.empty:
            raise ValueError(
                f"No initial expense data found for product '{self.product}'. "
                f"Please ensure that the 'Expense_Rate_Term' contains initial expense entries for this product."
            )

        # Pivot the Initial Expenses so that each Expense_Category becomes a separate column
        try:
            initial_pivot = initial_df.pivot_table(
                index='SA',
                columns='Expense_Category',
                values='Value',
                aggfunc='first'
            ).reset_index()

            # Rename columns for consistency
            initial_pivot.columns.name = None  # Remove the pivot table name

            # Check if required columns are present
            required_columns = ['SA', '% of Prem', 'Fixed', '% of SA']
            for col in required_columns:
                if col not in initial_pivot.columns:
                    raise KeyError(f"Missing required initial expense column: '{col}' in the CSV.")

            # Convert SA to numeric, remove commas if any
            initial_pivot['SA'] = initial_pivot['SA'].astype(str).str.replace(',', '').astype(float)

            # Handle percentages: remove '%' and convert to decimal
            initial_pivot['% of Prem'] = initial_pivot['% of Prem'].astype(str).str.rstrip('%').astype(float)
            initial_pivot['% of SA'] = initial_pivot['% of SA'].astype(str).str.rstrip('%').astype(float)

            # Convert Fixed to float
            initial_pivot['Fixed'] = initial_pivot['Fixed'].astype(float)

            # Sort by SA for consistent ordering
            initial_pivot = initial_pivot.sort_values('SA').reset_index(drop=True)

            # Convert to JAX arrays
            self.initial_expenses = {
                'SA': jnp.array(initial_pivot['SA'].values, dtype=FLOAT_DTYPE),
                '% of Prem': jnp.array(initial_pivot['% of Prem'].values, dtype=FLOAT_DTYPE),
                'Fixed': jnp.array(initial_pivot['Fixed'].values, dtype=FLOAT_DTYPE),
                '% of SA': jnp.array(initial_pivot['% of SA'].values, dtype=FLOAT_DTYPE)
            }

            self.logger.info(f"Loaded Initial Expenses successfully.")

        except KeyError as e:
            self.logger.error(f"Error processing Initial Expenses: {e}")
            raise

        # Filter Renewal Expenses
        renewal_df = df[df['Expense_Type'] == 'RENEWAL'].copy()

        if renewal_df.empty:
            raise ValueError(
                f"No renewal expense data found. "
                f"Please ensure that the 'Expense_Rate_Term' contains renewal expense entries."
            )

        # Process Renewal Expenses
        try:
            # Remove '%' from 'Value' and convert to float
            renewal_df['Value'] = renewal_df['Value'].astype(str).str.replace('%', '').astype(float)
            renewal_df['Expense_Category'] = renewal_df['Expense_Category'].str.strip()

            # Create a dictionary: {Category: Value}
            renewal_expenses_dict = {}
            for _, row in renewal_df.iterrows():
                category = row['Expense_Category']
                value = row['Value']
                renewal_expenses_dict[category] = value

            self.renewal_expenses = renewal_expenses_dict
            self.logger.info("Loaded Renewal Expenses successfully.")

        except Exception as e:
            self.logger.error(f"Error processing Renewal Expenses: {e}")
            raise
    
    def get_initial_expense_rates(self, sum_assured: jnp.ndarray) -> Dict[str, jnp.ndarray]:
        """
        Retrieve initial expense rates based on Sum Assured (SA).
        Performs linear interpolation if necessary.

        Args:
            sum_assured (jnp.ndarray): Array of Sum Assured values. Shape: (num_policies, num_months)

        Returns:
            Dict[str, jnp.ndarray]: Dictionary containing '% of Prem', 'Fixed', and '% of SA' arrays.
        """
        sa = sum_assured  # Shape: (num_policies, num_months)

        # Perform linear interpolation for each rate
        # Flatten the SA array for interpolation
        sa_flat = sa.flatten()

        percent_prem = jnp.interp(sa_flat, self.initial_expenses['SA'], self.initial_expenses['% of Prem'])
        fixed = jnp.interp(sa_flat, self.initial_expenses['SA'], self.initial_expenses['Fixed'])
        percent_sa = jnp.interp(sa_flat, self.initial_expenses['SA'], self.initial_expenses['% of SA'])

        # Reshape back to original shape
        percent_prem = percent_prem.reshape(sa.shape)[:,0]
        fixed = fixed.reshape(sa.shape)[:,0]
        percent_sa = percent_sa.reshape(sa.shape)[:,0]

        return {
            '% of Prem': percent_prem,
            'Fixed': fixed,
            '% of SA': percent_sa
        }

    def get_monthly_expense_rate_vectorized(
        self,
        expense_types: str,
        distribution_channels: jnp.ndarray
    ) -> jnp.ndarray:
        """
        Retrieve monthly expense rates based on expense types and distribution channels.

        Args:
            expense_types (str): The expense category (e.g., 'Fixed expenses').
            distribution_channels (jnp.ndarray): Array of distribution channels.

        Returns:
            jnp.ndarray: Array of monthly expense rates.
        """
        # For this example, we will assume that monthly expenses do not vary by distribution channel
        # and use the expense rate directly

        # Retrieve the expense rate for the given expense_types
        if expense_types not in self.renewal_expenses:
            self.logger.warning(f"Expense type '{expense_types}' not found. Defaulting to 0.")
            expense_value = 0.0
        else:
            expense_value = self.renewal_expenses[expense_types]

        # Create an array filled with the expense_value, matching the shape of distribution_channels
        expense_rates = jnp.full(jnp.shape(distribution_channels), expense_value, dtype=FLOAT_DTYPE)

        return expense_rates

    def get_renewal_expense_rates(self) -> Dict[str, float]:
        """
        Retrieve renewal expense rates.

        Returns:
            Dict[str, float]: Dictionary containing renewal expenses.
        """
        return self.renewal_expenses

    def apply_sensitivities(self, additive_factor: float, multiplicative_factor: float):
        """
        Suppose we interpret additive_factor as an absolute addition 
        to 'Fixed' fields, and multiplicative_factor as scaling the 
        percentage-based fields. Adjust logic as needed.
        """
        # 1) initial_expenses
        if self.initial_expenses:
            # 'Fixed'
            old_fixed = self.initial_expenses['Fixed']
            self.initial_expenses['Fixed'] = (old_fixed + additive_factor) * multiplicative_factor

            # '% of Prem'
            old_pop = self.initial_expenses['% of Prem']
            self.initial_expenses['% of Prem'] = old_pop * multiplicative_factor

            # '% of SA'
            old_posa = self.initial_expenses['% of SA']
            self.initial_expenses['% of SA'] = old_posa * multiplicative_factor

        # 2) renewal_expenses
        if self.renewal_expenses:
            # 'Fixed expenses'
            if 'Fixed expenses' in self.renewal_expenses:
                val = self.renewal_expenses['Fixed expenses']
                self.renewal_expenses['Fixed expenses'] = (val + additive_factor) * multiplicative_factor

            # '% of Prem'
            if '% of Prem' in self.renewal_expenses:
                val = self.renewal_expenses['% of Prem']
                self.renewal_expenses['% of Prem'] = val * multiplicative_factor

            # 'Claim expenses'
            if 'Claim expenses' in self.renewal_expenses:
                val = self.renewal_expenses['Claim expenses']
                self.renewal_expenses['Claim expenses'] = val * multiplicative_factor

class Mortality(Assumptions):
    def __init__(self, table_index: TableIndex, root_folder: Path, product: str):
        super().__init__(table_index, root_folder)
        self.product = product.upper()
        self.mortality_table = None 
        self.max_age = None
        self.logger = Logger()
        self.mortality_support = None
        self.is_gcl = (self.product == 'GCL' or self.product == 'GCL')

    def load_data(self):
        # Load base mortality table using read_table instead of get_file_path
        try:
            df = self.read_table('Mortality_Table')
            if df is None or df.empty:
                raise ValueError("Empty mortality table data")
            
            # Assuming columns: Age, Male, Female, Transgender
            max_age = int(df['Age'].max())
            gender_map = {'Male': 0, 'Female': 1, 'Transgender': 2}
            mortality_table = jnp.zeros((max_age + 1, 3), dtype=FLOAT_DTYPE)
        except Exception as e:
            self.logger.error(f"Failed to load mortality table: {str(e)}")
        for _, row in df.iterrows():
            age = int(row['Age'])
            for g in ['Male', 'Female', 'Transgender']:
                mortality_table = mortality_table.at[age, gender_map[g]].set(float(row[g]))
        self.mortality_table = mortality_table
        self.max_age = max_age

        # If product is GCL, load the mortality support table
        if self.is_gcl:
            # 1) Read with the default header row (column names already correct)
            support_df = self.read_table('Mortality_Support_GCL')
            
            # 2) Ensure there’s no stray whitespace
            support_df.columns = support_df.columns.str.strip()
            
            # 3) Cast support columns to float
            for col in support_df.columns:
                if col != 'Age':
                    support_df[col] = support_df[col].astype(float)

            # 4) Prepare JAX buffers
            ages = support_df['Age'].values.astype(INT_DTYPE)
            max_age_support = int(ages.max())
            support_BE  = jnp.zeros((max_age_support + 1, 4), dtype=FLOAT_DTYPE)
            support_Res = jnp.zeros((max_age_support + 1, 4), dtype=FLOAT_DTYPE)

            # 5) Column‐index mapping for M_NS, M_S, F_NS, F_S
            col_map = {'M_NS': 0, 'M_S': 1, 'F_NS': 2, 'F_S': 3}

            # 6) Fill in the arrays
            for _, row in support_df.iterrows():
                age = int(row['Age'])
                # Best‐estimate (prefix BE_)
                for key, idx in col_map.items():
                    support_BE = support_BE.at[age, idx].set(row[f'BE_{key}'])
                # Reserving (prefix RE_)
                for key, idx in col_map.items():
                    support_Res = support_Res.at[age, idx].set(row[f'RE_{key}'])

            # 7) Store into your class
            self.mortality_support = {
                'BE':        support_BE,
                'Reserving': support_Res
            }

    def get_annual_rate_gcl(self, ages: jnp.ndarray, genders: jnp.ndarray, smoker_status: jnp.ndarray, basis: str = 'BE') -> jnp.ndarray:
        """
        Returns annual mortality rates for GCL product using mortality_support tables.
        If M=0,F=1 and Non-Smoker=0,Smoker=1, index into mortality_support[basis].
        """
        if basis not in ['BE','Reserving']:
            basis='BE'
        ages_clipped = jnp.clip(ages,0,self.mortality_support[basis].shape[0]-1).astype(INT_DTYPE)
        # gender:0=M,1=F; smoker:0=NS,1=S
        index_map = (genders*2) + smoker_status
        # support arrays shape: (max_age_support+1,4)
        # Flatten for indexing
        flat_idx = jnp.arange(ages_clipped.size)
        support_values = self.mortality_support[basis][ages_clipped.ravel(), index_map.ravel()].reshape(ages.shape)
        # base mortality from mortality_table:
        base_mort = self.mortality_table[jnp.clip(ages,0,self.max_age), jnp.where(genders>1,1,genders)]
        # annual rate:
        return base_mort * support_values

    def get_flat_rate_annual(self, layer: str):
        """
        Returns annual flat mortality rate for GCL if mortality_flat_flag=0
        For BE layer:0.002 per annum
        For Reserving:0.0022 per annum
        """
        if layer=='BE':
            return 0.002
        else:
            return 0.0022


    # Modify get_annual_rate_vectorized to handle GCL and flat rates:
    def get_annual_rate_vectorized(self, ages: jnp.ndarray, genders: jnp.ndarray, smoker_status: jnp.ndarray = None, basis: str = 'BE', mortality_flat_flag: jnp.ndarray = None) -> jnp.ndarray:
        """
        Vectorized method to get annual mortality rates.
        If product=GCL and mortality_flat_flag=0: use flat rate
        Else if product=GCL and mortality_flat_flag=1: use get_annual_rate_gcl
        Else use normal table (non-GCL products)
        """
        if self.is_gcl:
            # If flat_flag=1 => flat rate
            flat_rate = jnp.where(mortality_flat_flag==0, self.get_flat_rate_annual(basis), self.get_annual_rate_gcl(ages,genders,smoker_status,basis))
            return flat_rate
        else:
            # Non-GCL logic as previously implemented (already in original code)
            # Basic indexing:
            ages_clipped = jnp.clip(ages,0,self.max_age)
            genders_clipped = jnp.where(genders>1,1,genders) # fallback
            return self.mortality_table[ages_clipped, genders_clipped]

    def apply_sensitivities(self, additive_factor: float, multiplicative_factor: float):
        """
        For each age/gender in the loaded mortality_table,
        we do: rate = (rate + additive_factor) * multiplicative_factor
        """
        if self.mortality_table is None:
            return  # no table loaded, skip

        # Suppose mortality_table is a jnp array shape [max_age+1, 3]
        # Step 1: add
        self.mortality_table = self.mortality_table + additive_factor
        # Step 2: multiply
        self.mortality_table = self.mortality_table * multiplicative_factor

        # If using a dataframe, you'd do something like:
        # df['Male'] = (df['Male'] + additive_factor) * multiplicative_factor
        # etc.

class ReinsuranceMortality(Assumptions):
    def __init__(self, table_index: TableIndex, root_folder: Path, product: str):
        super().__init__(table_index, root_folder)
        self.mortality_table = None  # Shape: (max_age+1, num_genders)
        self.max_age = None
        self.product = product.upper()

    def load_data(self):

        if self.product in ['RIDER_CI', 'RIDER_ADB', 'RIDER_ATPD']:
            reins_mort_table_name = 'Reinsurance_Mortality_Table'
        elif self.product == 'BASE_TERM':
            reins_mort_table_name = 'Mortality_Table'        
        elif self.product == 'GCL' or self.product == 'GCL':
            reins_mort_table_name = 'Reinsurance_Mortality_Table_GCL'
        else:
            raise NotImplementedError(f"Reinsurance Mortality assumptions for product '{self.product}' not implemented.")
        
        df = self.read_table(reins_mort_table_name)
        # Assuming df has columns: 'Age', 'Male', 'Female', 'Transgender'
        max_age = int(df['Age'].max())
        num_genders = 3  # Male, Female, Transgender
        gender_to_index = {'Male': 0, 'Female': 1, 'Transgender': 2}
        mortality_table = jnp.zeros((max_age + 1, num_genders), dtype=FLOAT_DTYPE)
        for _, row in df.iterrows():
            age = int(row['Age'])
            for gender in ['Male', 'Female', 'Transgender']:
                gender_idx = gender_to_index[gender]
                mortality_table = mortality_table.at[age, gender_idx].set(float(row[gender]))
        self.mortality_table = mortality_table
        self.max_age = max_age

    def get_annual_rate_vectorized(self, ages: jnp.ndarray, genders: jnp.ndarray) -> jnp.ndarray:
        """
        Vectorized method to get annual reinsurance mortality rates based on ages and genders.

        Args:
            ages (jnp.ndarray): Array of ages with shape (num_policies, num_months).
            genders (jnp.ndarray): Array of gender codes with shape (num_policies, num_months).

        Returns:
            jnp.ndarray: Reinsurance mortality rates with shape (num_policies, num_months).
        """
        ages_clipped = jnp.clip(ages, 0, self.max_age).astype(INT_DTYPE)  # Shape: (num_policies, num_months)
        gender_indices = genders.astype(INT_DTYPE)  # Shape: (num_policies, num_months)
        mortality_rates = self.mortality_table[ages_clipped, gender_indices]  # Shape: (num_policies, num_months)
        return mortality_rates

    def apply_sensitivities(self, additive_factor: float, multiplicative_factor: float):
        """
        Same logic as Mortality. The reinsurance mortality rates get 
        the same additive & multiplicative as the direct rates.
        """
        if self.mortality_table is None:
            return

        self.mortality_table = self.mortality_table + additive_factor
        self.mortality_table = self.mortality_table * multiplicative_factor

class Persistency(Assumptions):
    def __init__(self, table_index: TableIndex, root_folder: Path, product: str):
        super().__init__(table_index, root_folder)
        self.product = product.upper()
        self.lapse_rates = None  # Shape: (max_policy_year, num_channels)
        self.max_policy_year = None
        self.channel_mapping = None  # JAX array for channel to index mapping

    def load_data(self):
        if self.product in ['RIDER_CI', 'RIDER_ADB', 'RIDER_ATPD', 'BASE_TERM']:
            persistency_table_name = 'Persistency_Rate_Term'
        elif self.product == 'GCL' or self.product == 'GCL':
            persistency_table_name = 'Persistency_Rate_GCL'
        else:
            raise NotImplementedError(f"Persistency assumptions for product '{self.product}' not implemented.")
        df = self.read_table(persistency_table_name)
        max_policy_year = int(df['Policy Year'].max())
        channels = sorted(df['Channel'].unique())
        num_channels = len(channels)
        channel_to_index = {channel: idx for idx, channel in enumerate(channels)}

        # Create a JAX array mapping channel numbers to indices
        max_channel = int(df['Channel'].max())
        channel_mapping = jnp.full((max_channel + 1,), -1, dtype=INT_DTYPE)  # Initialize with -1 for unknown channels
        for channel, idx in channel_to_index.items():
            channel_mapping = channel_mapping.at[channel].set(idx)
        self.channel_mapping = channel_mapping

        lapse_rates = jnp.zeros((max_policy_year, num_channels), dtype=FLOAT_DTYPE)
        for _, row in df.iterrows():
            policy_year = int(row['Policy Year'])
            channel = int(row['Channel'])
            channel_idx = channel_to_index[channel]
            lapse_rate = float(row['Lapse Rate'])
            lapse_rates = lapse_rates.at[policy_year - 1, channel_idx].set(lapse_rate)
        self.lapse_rates = lapse_rates
        self.max_policy_year = max_policy_year

    def get_annual_lapse_rate_vectorized(self, policy_years: jnp.ndarray, distribution_channels: jnp.ndarray) -> jnp.ndarray:
        """
        Vectorized method to get annual lapse rates based on policy years and distribution channels.

        Args:
            policy_years (jnp.ndarray): Array of policy years with shape (num_policies, num_months).
            distribution_channels (jnp.ndarray): Array of distribution channels with shape (num_policies, num_months).

        Returns:
            jnp.ndarray: Annual lapse rates with shape (num_policies, num_months).
        """
        # Use channel_mapping to get channel indices
        channel_indices = self.channel_mapping[distribution_channels].astype(INT_DTYPE)  # Shape: (num_policies, num_months)
        # Handle channels not found in the mapping by setting them to 0 or a default index
        channel_indices = jnp.where(channel_indices == -1, 0, channel_indices)
        policy_years_clipped = jnp.clip(policy_years, 1, self.max_policy_year).astype(INT_DTYPE)  # Shape: (num_policies, num_months)
        lapse_rates = self.lapse_rates[policy_years_clipped - 1, channel_indices]  # Shape: (num_policies, num_months)
        return lapse_rates

    def apply_sensitivities(self, additive_factor: float, multiplicative_factor: float):
        """
        The same approach: for each policy-year/channel, do 
         new_lapse = (old_lapse + additive_factor) * multiplicative_factor
        """
        if self.lapse_rates is None:
            return

        self.lapse_rates = self.lapse_rates + additive_factor
        self.lapse_rates = self.lapse_rates * multiplicative_factor

class Commissions(Assumptions):
    def __init__(self, table_index: TableIndex, root_folder: Path, product: str):
        super().__init__(table_index, root_folder)
        self.product = product.upper()
        self.commission_rates = None  # Shape: (max_policy_year, num_channels)
        self.max_policy_year = None
        self.channel_mapping = None  # JAX array for channel to index mapping

    def load_data(self):
        if self.product in ['RIDER_CI', 'RIDER_ADB', 'RIDER_ATPD', 'BASE_TERM']:
            commission_table_name = 'Commission_Rates_Term'
        elif self.product == 'GCL' or self.product == 'GCL':
            commission_table_name = 'Commission_Rates_GCL'
        else:
            raise NotImplementedError(f"Commission assumptions for product '{self.product}' not implemented.")
        df = self.read_table(commission_table_name)
        max_policy_year = int(df['Policy Year'].max())
        channels = sorted(df['Channel'].unique())
        num_channels = len(channels)
        channel_to_index = {channel: idx for idx, channel in enumerate(channels)}
        
        # Create a JAX array mapping channel numbers to indices
        max_channel = int(df['Channel'].max())
        channel_mapping = jnp.full((max_channel + 1,), -1, dtype=INT_DTYPE)  # Initialize with -1 for unknown channels
        for channel, idx in channel_to_index.items():
            channel_mapping = channel_mapping.at[channel].set(idx)
        self.channel_mapping = channel_mapping

        commission_rates = jnp.zeros((max_policy_year, num_channels), dtype=FLOAT_DTYPE)
        for _, row in df.iterrows():
            policy_year = int(row['Policy Year'])
            channel = int(row['Channel'])
            channel_idx = channel_to_index[channel]
            rate = float(row['Commission Rates'])
            commission_rates = commission_rates.at[policy_year - 1, channel_idx].set(rate)
        self.commission_rates = commission_rates
        self.max_policy_year = max_policy_year

    def get_commission_rate_vectorized(self, policy_years: jnp.ndarray, distribution_channels: jnp.ndarray) -> jnp.ndarray:
        """
        Vectorized method to get commission rates based on policy years and distribution channels.

        Args:
            policy_years (jnp.ndarray): Array of policy years with shape (num_policies, num_months).
            distribution_channels (jnp.ndarray): Array of distribution channels with shape (num_policies, num_months).

        Returns:
            jnp.ndarray: Commission rates with shape (num_policies, num_months).
        """
        # Use channel_mapping to get channel indices
        channel_indices = self.channel_mapping[distribution_channels].astype(INT_DTYPE)  # Shape: (num_policies, num_months)
        # Handle channels not found in the mapping by setting them to 0 or a default index
        channel_indices = jnp.where(channel_indices == -1, 0, channel_indices)
        policy_years_clipped = jnp.clip(policy_years, 1, self.max_policy_year).astype(INT_DTYPE)  # Shape: (num_policies, num_months)
        commission_rates = self.commission_rates[policy_years_clipped - 1, channel_indices]  # Shape: (num_policies, num_months)
        return commission_rates

class InterestRate(Assumptions):
    def __init__(self, table_index: TableIndex, config: RunConfig):
        super().__init__(table_index, config.root_folder)
        self.projection_months = config.projection_term * 12
        self.monthly_ROI_rates = None
        self.monthly_VROI_rates = None
        self.monthly_CCIL_rates = None

    def load_data(self):
        df = self.read_table('Interest_Rate')

        # Expand annual rates into monthly rates
        months_per_year = 12
        total_years = (self.projection_months + months_per_year - 1) // months_per_year

        # Ensure enough years are available
        if total_years > len(df):
            raise ValueError("Not enough years of interest rates for the projection term.")

        # Extract and expand rates
        self.monthly_ROI_rates = jnp.repeat(
            df['ROI'].values[:total_years], months_per_year)[:self.projection_months]
        self.monthly_VROI_rates = jnp.repeat(
            df['VROI'].values[:total_years], months_per_year)[:self.projection_months]
        self.monthly_CCIL_rates = jnp.repeat(
            df['CCIL Fwd Rates'].values[:total_years], months_per_year)[:self.projection_months]

        # Convert annual rates to monthly rates
        self.monthly_ROI_rates = (1 + self.monthly_ROI_rates) ** (1 / 12) - 1
        self.monthly_VROI_rates = (1 + self.monthly_VROI_rates) ** (1 / 12) - 1
        self.monthly_CCIL_rates = (1 + self.monthly_CCIL_rates) ** (1 / 12) - 1

        # Convert to JAX arrays
        self.monthly_ROI_rates = jnp.array(self.monthly_ROI_rates, dtype=FLOAT_DTYPE)
        self.monthly_VROI_rates = jnp.array(self.monthly_VROI_rates, dtype=FLOAT_DTYPE)
        self.monthly_CCIL_rates = jnp.array(self.monthly_CCIL_rates, dtype=FLOAT_DTYPE)

    def get_monthly_rates(self, rate_type: str) -> jnp.ndarray:
        if rate_type == 'ROI':
            return self.monthly_ROI_rates
        elif rate_type == 'VROI':
            return self.monthly_VROI_rates
        elif rate_type == 'CCIL':
            return self.monthly_CCIL_rates
        else:
            raise ValueError(f"Unknown rate type: {rate_type}")
        
    def apply_sensitivities(self, additive_factor: float, multiplicative_factor: float):
        """
        For each monthly rate, do new_rate = (old_rate + additive_factor) * multiplicative_factor.
        Note: Sometimes an "additive" shift to interest rates is done in basis points
        or a fraction (like +0.01 means +100 bps). Adjust logic accordingly.
        """
        if self.monthly_ROI_rates is not None:
            self.monthly_ROI_rates = (self.monthly_ROI_rates + additive_factor) * multiplicative_factor
        if self.monthly_VROI_rates is not None:
            self.monthly_VROI_rates = (self.monthly_VROI_rates + additive_factor) * multiplicative_factor
        if self.monthly_CCIL_rates is not None:
            self.monthly_CCIL_rates = (self.monthly_CCIL_rates + additive_factor) * multiplicative_factor

class Morbidity(Assumptions):
    def __init__(self, table_index: TableIndex, root_folder: Path, product: str):
        super().__init__(table_index, root_folder)
        self.morbidity_table = None  # Shape: (max_age+1, num_genders)
        self.max_age = None
        self.product = product.upper()

    def load_data(self):
        df = self.read_table('Morbidity_Table')
        # Rename columns if necessary
        df.rename(columns=lambda x: x.strip(), inplace=True)
        df.rename(columns={"Age nearest b'day (x)": 'Age'}, inplace=True)
        max_age = int(df['Age'].max())
        if self.product == 'RIDER_CI':
            gender_columns = ['Critical illness - Male', 'Critical illness - Female']
        elif self.product == 'RIDER_ADB':
            gender_columns = ['Accidental Death - Male', 'Accidental Death - Female']
        else:
            gender_columns = ['Disability Rider - Male', 'Disability Rider - Female']
        gender_to_index = {'Male': 0, 'Female': 1}
        morbidity_table = jnp.zeros((max_age + 1, 2), dtype=FLOAT_DTYPE)
        for _, row in df.iterrows():
            age = int(row['Age'])
            for gender_col in gender_columns:
                gender = 'Male' if 'Male' in gender_col else 'Female'
                gender_idx = gender_to_index[gender]
                rate = row[gender_col]
                if pd.isnull(rate):
                    rate = 0.0
                morbidity_table = morbidity_table.at[age, gender_idx].set(float(rate))
        self.morbidity_table = morbidity_table
        self.max_age = max_age

    def get_annual_rate_vectorized(self, ages: jnp.ndarray, genders: jnp.ndarray) -> jnp.ndarray:
        ages_clipped = jnp.clip(ages, 0, self.max_age).astype(INT_DTYPE)
        gender_indices = genders.astype(INT_DTYPE)
        morbidity_rates = self.morbidity_table[ages_clipped, gender_indices]
        return morbidity_rates

    def apply_sensitivities(self, additive_factor: float, multiplicative_factor: float):
        if self.morbidity_table is None:
            return

        # For each age/gender row:
        self.morbidity_table = self.morbidity_table + additive_factor
        self.morbidity_table = self.morbidity_table * multiplicative_factor

class ReinsuranceMorbidity(Assumptions):
    def __init__(self, table_index: TableIndex, root_folder: Path, product: str):
        super().__init__(table_index, root_folder)
        self.morbidity_table = None  # Shape: (max_age+1, num_genders)
        self.max_age = None
        self.product = product.upper()

    def load_data(self):
        df = self.read_table('Reinsurance_Morbidity_Table')
        # Rename columns if necessary
        df.rename(columns=lambda x: x.strip(), inplace=True)
        df.rename(columns={"Age nearest b'day (x)": 'Age'}, inplace=True)
        max_age = int(df['Age'].max())
        if self.product == 'RIDER_CI':
            gender_columns = ['Critical illness - Male', 'Critical illness - Female']
        elif self.product == 'RIDER_ADB':
            gender_columns = ['Accidental Death - Male', 'Accidental Death - Female']
        else:
            gender_columns = ['Disability Rider - Male', 'Disability Rider - Female']
        gender_to_index = {'Male': 0, 'Female': 1}
        morbidity_table = jnp.zeros((max_age + 1, 2), dtype=FLOAT_DTYPE)
        for _, row in df.iterrows():
            age = int(row['Age'])
            for gender_col in gender_columns:
                gender = 'Male' if 'Male' in gender_col else 'Female'
                gender_idx = gender_to_index[gender]
                rate = row[gender_col]
                if pd.isnull(rate):
                    rate = 0.0
                morbidity_table = morbidity_table.at[age, gender_idx].set(float(rate))
        self.morbidity_table = morbidity_table
        self.max_age = max_age

    def get_annual_rate_vectorized(self, ages: jnp.ndarray, genders: jnp.ndarray) -> jnp.ndarray:
        ages_clipped = jnp.clip(ages, 0, self.max_age).astype(INT_DTYPE)
        gender_indices = genders.astype(INT_DTYPE)
        morbidity_rates = self.morbidity_table[ages_clipped, gender_indices]
        return morbidity_rates
    
    def apply_sensitivities(self, additive_factor: float, multiplicative_factor: float):
        if self.morbidity_table is None:
            return

        self.morbidity_table = self.morbidity_table + additive_factor
        self.morbidity_table = self.morbidity_table * multiplicative_factor

class ModalFactor(Assumptions):
    def __init__(self, table_index: TableIndex, root_folder: Path, product: str):
        super().__init__(table_index, root_folder)
        self.modal_table = None  # Shape: (max_age+1, num_genders)
        self.product = product.upper()
        self.modal_factor_df=None

    def load_data(self):
        df = self.read_table('Premium_Modal_Factor')
        # Rename columns if necessary
        if self.product == 'BASE_TERM':
            modal_factor_df = df[["Frequency", "BASE_TERM"]]
        elif self.product == 'GCL' or self.product == 'GCL':
            modal_factor_df = df[["Frequency", "GCL"]]
        elif self.product == 'RIDER_ADB':
            modal_factor_df = df[["Frequency", "RIDER_ADB"]]
        elif self.product == 'RIDER_CI':
            modal_factor_df = df[["Frequency", "RIDER_CI"]]
        elif self.product == 'RIDER_ATPD':
            modal_factor_df = df[["Frequency", "RIDER_ATPD"]]
        self.modal_factor_df = modal_factor_df

    def get_annual_rate_vectorized(self, premium_frequencies: jnp.ndarray) -> jnp.ndarray:
        freq_to_product= dict(zip(self.modal_factor_df["Frequency"], self.modal_factor_df[self.product]))
        keys = jnp.array(list(freq_to_product.keys()))
        values = jnp.array(list(freq_to_product.values()))
        def map_frequency_to_product(freq):
            idx = jnp.where(keys == freq, size=1)[0]  # Find index of the frequency in keys
            return jnp.where(idx.size > 0, values[idx[0]], 0.0)
        map_func = jnp.vectorize(map_frequency_to_product)
        modal_factor = map_func(premium_frequencies)
        return modal_factor
    
class IFRS17(Assumptions):
    def __init__(self, table_index: TableIndex, config: RunConfig, product: str):
        super().__init__(table_index, config.root_folder)
        self.projection_months = config.projection_term * 12
        self.monthly_IFRS_Current_rates = None
        self.monthly_IFRS_locked_in_rates = None
        self.monthly_IFRS_CCIL_rates = None
        self.initial_expenses = None
        self.renewal_expenses = None
        self.ifrs17_multiplier_initial_expenses = None
        self.ifrs17_multiplier_renewal_expenses = None
        self.ifrs17_addition_renewal_expenses = None
        self.product = product.upper()

    def load_data(self):
        df = self.read_table('Interest_Rate_IFRS17')

        # Expand annual rates into monthly rates
        months_per_year = 12
        total_years = (self.projection_months + months_per_year - 1) // months_per_year

        # Ensure enough years are available
        if total_years > len(df):
            raise ValueError("Not enough years of IFRS interest rates for the projection term.")

        # Extract and expand rates
        self.monthly_IFRS_Current_rates = jnp.repeat(
            df['if17_Current_ROI'].values[:total_years], months_per_year)[:self.projection_months]
        self.monthly_IFRS_locked_in_rates = jnp.repeat(
            df['if17_Locked_in_Rate'].values[:total_years], months_per_year)[:self.projection_months]
        self.monthly_IFRS_CCIL_rates = jnp.repeat(
            df['if17_CCIL Fwd Rates'].values[:total_years], months_per_year)[:self.projection_months]

        # Annual locked-in-rate 
        self.annual_IFRS_locked_in_rates = jnp.repeat(
            df['if17_Locked_in_Rate'].values[:total_years], months_per_year)[:self.projection_months]
        
        # Convert annual rates to monthly rates
        self.monthly_IFRS_Current_rates = (1 + self.monthly_IFRS_Current_rates) ** (1 / 12) - 1
        self.monthly_IFRS_locked_in_rates = (1 + self.monthly_IFRS_locked_in_rates) ** (1 / 12) - 1
        self.monthly_IFRS_CCIL_rates = (1 + self.monthly_IFRS_CCIL_rates) ** (1 / 12) - 1

        # Convert to JAX arrays
        self.monthly_IFRS_Current_rates = jnp.array(self.monthly_IFRS_Current_rates, dtype=FLOAT_DTYPE)
        self.monthly_IFRS_locked_in_rates = jnp.array(self.monthly_IFRS_locked_in_rates, dtype=FLOAT_DTYPE)
        self.monthly_IFRS_CCIL_rates = jnp.array(self.monthly_IFRS_CCIL_rates, dtype=FLOAT_DTYPE)
        
       # Load initial and renewal expense assumptions
        self.load_initial_expense_data()
        self.load_renewal_expense_data()

       # Load IFRS multipliers
        self.load_ifrs_multipliers()

        # Load additional variables
        self.load_ifrs_additional_variables()

    def load_initial_expense_data(self):
        # Load initial expense assumptions
        if self.product == 'BASE_TERM':
            table_name = 'Initial_Expense_Rate_Term_IFRS17'
        elif self.product == 'GCL':
            table_name = 'Initial_Expense_Rate_GCL_IFRS17'
        elif self.product in ['RIDER_CI', 'RIDER_ADB', 'RIDER_ATPD']:
            table_name = 'Initial_Expense_Rate_Rider_IFRS17'
        else:
            raise ValueError(f"Unsupported product type: {self.product}")
        
        initial_expense_df = self.read_table(table_name)
        
        # Filter for initial expenses
        initial_expense_df = initial_expense_df[initial_expense_df['Expense_Type'].str.upper() == 'INITIAL']
        
        # Pivot the data to get expenses by Sum Assured (SA)
        pivot_df = initial_expense_df.pivot(index='SA', columns='Expense_Category', values='Value').reset_index()
        
        # Check if required columns are present
        required_columns = ['SA', '% of Prem', 'Fixed', '% of SA']
        for col in required_columns:
            if col not in pivot_df.columns:
                raise KeyError(f"Missing required initial expense column: '{col}' in the CSV.")
        
        # Process initial expense assumptions
        self.initial_expenses = {
            'SA': jnp.array(pivot_df['SA'].values, dtype=FLOAT_DTYPE),
            '% of Prem': jnp.array(pivot_df['% of Prem'].values, dtype=FLOAT_DTYPE),
            'Fixed': jnp.array(pivot_df['Fixed'].values, dtype=FLOAT_DTYPE),
            '% of SA': jnp.array(pivot_df['% of SA'].values, dtype=FLOAT_DTYPE)
        }

    def load_renewal_expense_data(self):
        # Load renewal expense assumptions
        if self.product == 'BASE_TERM':
            table_name = 'Renewal_Expense_Rate_Term_IFRS17'
        elif self.product == 'GCL':
            table_name = 'Renewal_Expense_Rate_GCL_IFRS17'
        elif self.product in ['RIDER_CI', 'RIDER_ADB', 'RIDER_ATPD']:
            table_name = 'Renewal_Expense_Rate_Rider_IFRS17'
        else:
            raise ValueError(f"Unsupported product type: {self.product}")
        
        renewal_expense_df = self.read_table(table_name)
        
        # Expand annual rates into monthly rates
        months_per_year = 12
        total_years = (self.projection_months + months_per_year - 1) // months_per_year

        # Ensure enough years are available
        if total_years > len(renewal_expense_df):
            raise ValueError("Not enough years of IFRS renewal expenses for the projection term.")
        
        # Create arrays with the desired pattern
        def expand_annual_to_monthly(annual_values):
            monthly_values = []
            for value in annual_values[:total_years]:
                monthly_values.extend([value] + [0] * (months_per_year - 1))
            return monthly_values[:self.projection_months]

        self.IFRS17_Renewal_Fixed_expenses = jnp.array(expand_annual_to_monthly(renewal_expense_df['Fixed expenses'].values), dtype=FLOAT_DTYPE)
        self.IFRS17_Prem_expenses = jnp.array(expand_annual_to_monthly(renewal_expense_df['% of Prem'].values), dtype=FLOAT_DTYPE)
        self.IFRS17_Claim_expenses = jnp.array(expand_annual_to_monthly(renewal_expense_df['Claim expenses'].values), dtype=FLOAT_DTYPE)
        
    def load_ifrs_multipliers(self):
        # Load IFRS multipliers from the product config file
        config_df = self.read_table('Product_Config')

        if self.product == 'BASE_TERM':
            column_name = 'BASE_TERM'
        elif self.product == 'GCL':
            column_name = 'GCL'
        elif self.product in ['RIDER_CI', 'RIDER_ADB', 'RIDER_ATPD']:
            column_name = self.product  # Use the product name directly as the column name
        else:
            raise ValueError(f"Unsupported product type: {self.product}")


        self.ifrs17_multiplier_initial_expenses = config_df.loc[config_df['Product Config Variable'] == 'IFRS17 Multiplier Initial Expenses', column_name].values[0]
        self.ifrs17_multiplier_renewal_expenses = config_df.loc[config_df['Product Config Variable'] == 'IFRS17 Multiplier Renewal Expenses', column_name].values[0]
        self.ifrs17_addition_renewal_expenses = config_df.loc[config_df['Product Config Variable'] == 'IFRS17 Addition Renewal Expenses', column_name].values[0]

        

    def load_ifrs_additional_variables(self):
        # Load IFRS additional variables from the product config file
        add_config_df = self.read_table('Product_Config')

        if self.product == 'BASE_TERM':
            column_name = 'BASE_TERM'
        elif self.product == 'GCL':
            column_name = 'GCL'
        elif self.product in ['RIDER_CI', 'RIDER_ADB', 'RIDER_ATPD']:
            column_name = self.product  # Use the product name directly as the column name
        else:
            raise ValueError(f"Unsupported product type: {self.product}")

        self.ifrs17_ra_ratio = add_config_df.loc[add_config_df['Product Config Variable'] == 'IFRS 17 RA Ratio', column_name].values[0]
        self.ifrs17_ri_ra_ratio = add_config_df.loc[add_config_df['Product Config Variable'] == 'IFRS 17 RI RA Ratio', column_name].values[0]
        self.ifrs17_v = add_config_df.loc[add_config_df['Product Config Variable'] == 'IFRS 17 v', column_name].values[0]
        self.ifrs17_stress_v = add_config_df.loc[add_config_df['Product Config Variable'] == 'IFRS 17 stress v', column_name].values[0]
        self.ifrs17_stress_inflation = add_config_df.loc[add_config_df['Product Config Variable'] == 'IFRS 17 stress inflation', column_name].values[0]
        self.ifrs17_stress_expense = add_config_df.loc[add_config_df['Product Config Variable'] == 'IFRS 17 stress expense', column_name].values[0]

        self.ifrs17_multiplier_initial_commission = add_config_df.loc[add_config_df['Product Config Variable'] == 'IFRS17 Multiplier Initial Commission', column_name].values[0]        

    def get_initial_expense_rates(self, sum_assured: jnp.ndarray) -> Dict[str, jnp.ndarray]:
        """
        Retrieve initial expense rates based on Sum Assured (SA).
        Performs linear interpolation if necessary.

        Args:
            sum_assured (jnp.ndarray): Array of Sum Assured values. Shape: (num_policies, num_months)

        Returns:
            Dict[str, jnp.ndarray]: Dictionary containing '% of Prem', 'Fixed', and '% of SA' arrays.
        """
        sa = sum_assured  # Shape: (num_policies, num_months)
        sa_min = self.initial_expenses['SA'][0]  
        sa_max = self.initial_expenses['SA'][-1] 

        # Perform linear interpolation for each rate
        # Flatten the SA array for interpolation
        sa_flat = sa.flatten()

        percent_prem = jnp.interp(sa_flat, self.initial_expenses['SA'], self.initial_expenses['% of Prem'])
        fixed = jnp.interp(sa_flat, self.initial_expenses['SA'], self.initial_expenses['Fixed'])
        percent_sa = jnp.interp(sa_flat, self.initial_expenses['SA'], self.initial_expenses['% of SA'])

         # Apply IFRS17 multipliers
        percent_prem *= (1+self.ifrs17_multiplier_initial_expenses)
        
        # Reshape back to original shape
        percent_prem = percent_prem.reshape(sa.shape)
        fixed = fixed.reshape(sa.shape)
        percent_sa = percent_sa.reshape(sa.shape)

        return {
            '% of Prem': percent_prem,
            'Fixed': fixed,
            '% of SA': percent_sa
        }

    def get_renewal_expense_rates(self, expense_type: str) -> jnp.ndarray:
        if expense_type == 'Fixed expenses':
            return self.IFRS17_Renewal_Fixed_expenses
        elif expense_type == '% of Prem':
            return self.IFRS17_Prem_expenses
        elif expense_type == 'Claim expenses':
            return self.IFRS17_Claim_expenses
        else:
            raise ValueError(f"Unknown rate type: {expense_type}")

    def get_monthly_rates(self, rate_type: str) -> jnp.ndarray:
        if rate_type == 'if17_Current_ROI':
            return self.monthly_IFRS_Current_rates
        elif rate_type == 'if17_Locked_in_Rate':
            return self.monthly_IFRS_locked_in_rates
        elif rate_type == 'if17_CCIL Fwd Rates':
            return self.monthly_IFRS_CCIL_rates
        else:
            raise ValueError(f"Unknown rate type: {rate_type}")
        
    def get_annual_rates(self, rate_type: str) -> jnp.ndarray:
        if rate_type == 'if17_Annual_Locked_in_Rate':
            return self.annual_IFRS_locked_in_rates
        else:
            raise ValueError(f"Unknown rate type: {rate_type}")
    
        
    def get_additional_variables(self) -> Dict[str, float]:
        """
        Retrieve additional IFRS17 variables.

        Returns:
            Dict[str, float]: Dictionary containing additional IFRS17 variables.
        """
        return {
            'IFRS17_RA_Ratio': self.ifrs17_ra_ratio,
            'IFRS17_RI_RA_Ratio': self.ifrs17_ri_ra_ratio,
            'IFRS17_V': self.ifrs17_v,
            'IFRS17_Stress_V': self.ifrs17_stress_v,
            'IFRS17_Stress_Inflation': self.ifrs17_stress_inflation,
            'IFRS17_Stress_Expense': self.ifrs17_stress_expense,
            'IFRS17_Multiplier_Initial_Commission': self.ifrs17_multiplier_initial_commission,
        }

