# logger.py

import logging
import inspect
import sys
import traceback
import warnings
import time
from pathlib import Path
from functools import wraps
from logging.handlers import RotatingFileHandler
from typing import Optional, List, Tuple
from pathlib import Path
from datetime import datetime

class SingletonMeta(type):
    """
    A metaclass that creates a Singleton base type when called.
    """
    _instances = {}
    def __call__(cls, *args, **kwargs):
        if cls not in cls._instances:
            cls._instances[cls] = super(SingletonMeta, cls).__call__(*args, **kwargs)
        return cls._instances[cls]

class Logger(metaclass=SingletonMeta):
    """
    Singleton Logger class to handle logging across the application.
    """
    def __init__(self, main_logger_name: str = 'main_logger', error_logger_name: str = 'error_logger'):
        self.main_logger = logging.getLogger(main_logger_name)
        self.error_logger = logging.getLogger(error_logger_name)
        self.setup_warning_logging()

    def setup_warning_logging(self):
        """
        Redirects Python warnings to the error_logger.
        """
        def custom_warning_handler(message, category, filename, lineno, file=None, line=None):
            warning_msg = f"WARNING: {category.__name__}: {message} (File: {filename}, Line: {lineno})"
            self.error_logger.warning(warning_msg)
        
        warnings.showwarning = custom_warning_handler

    def get_caller_info(self):
        """
        Retrieves the caller's module, class, and function name.
        """
        frame = inspect.currentframe()
        try:
            outer_frames = inspect.getouterframes(frame)
            # Index 2 corresponds to the caller of the logger method
            caller_frame = outer_frames[2]
            module = inspect.getmodule(caller_frame.frame)
            module_name = module.__name__ if module else "UnknownModule"
            
            # Attempt to retrieve class name
            class_name = ""
            if 'self' in caller_frame.frame.f_locals:
                class_name = caller_frame.frame.f_locals['self'].__class__.__name__
            
            function_name = caller_frame.function
            return module_name, class_name, function_name
        finally:
            del frame

    def info(self, message: str):
        """
        Logs an informational message to the main logger.
        """
        self.main_logger.info(message)

    def warning(self, message: str):
        """
        Logs a warning message to the error logger.
        """
        self.error_logger.warning(message)

    def error(self, message: str):
        """
        Logs an error message with detailed context to the error logger and aborts the run.
        """
        module, class_name, function_name = self.get_caller_info()
        detailed_message = f"ERROR in {module}.{class_name}.{function_name}: {message}"
        self.error_logger.error(detailed_message)
        # Abort the run
        sys.exit(1)

    def exception(self, message: str):
        """
        Logs an exception with traceback to the error logger and aborts the run.
        """
        module, class_name, function_name = self.get_caller_info()
        exc_type, exc_value, exc_traceback = sys.exc_info()
        tb = ''.join(traceback.format_exception(exc_type, exc_value, exc_traceback))
        detailed_message = f"EXCEPTION in {module}.{class_name}.{function_name}: {message}\nTraceback:\n{tb}"
        self.error_logger.error(detailed_message)
        # Abort the run
        sys.exit(1)

    def log_function(self, log: bool = False):
        """
        Decorator to log the execution time of a function.
        The log is recorded only if the 'log' flag is True.
        """
        def decorator(func):
            @wraps(func)
            def wrapper(*args, **kwargs):
                start_time = time.time()
                try:
                    result = func(*args, **kwargs)
                    return result
                except Exception as e:
                    self.exception(f"An error occurred in function '{func.__name__}'.")
                finally:
                    end_time = time.time()
                    elapsed_time = end_time - start_time
                    if log:
                        self.info(f"Function '{func.__name__}' executed in {elapsed_time:.4f} seconds.")
            return wrapper
        return decorator

def setup_logging(log_file: str = 'main.log', error_log_file: str = 'error.log'):
    """
    Configures main_logger and error_logger with appropriate handlers and formatters.

    Args:
        log_file (str | os.PathLike): Path to the main log file.
        error_log_file (str | os.PathLike): Path to the error log file.

    Returns:
        None
    """
    # Normalize and ensure directories exist
    main_log_path = Path(log_file).resolve()
    error_log_path = Path(error_log_file).resolve()
    main_log_path.parent.mkdir(parents=True, exist_ok=True)
    error_log_path.parent.mkdir(parents=True, exist_ok=True)

    # Delete existing log files if they exist (use the provided paths)
    if main_log_path.exists():
        main_log_path.unlink()
    if error_log_path.exists():
        error_log_path.unlink()

    # Create main logger
    main_logger = logging.getLogger('main_logger')
    main_logger.handlers.clear()
    main_logger.setLevel(logging.INFO)
    main_logger.propagate = False  # Prevent duplicate logs

    # Create error logger
    error_logger = logging.getLogger('error_logger')
    error_logger.handlers.clear()
    error_logger.setLevel(logging.WARNING)
    error_logger.propagate = False  # Prevent duplicate logs
    
    # Define log format
    log_format = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')

    # Setup handlers for main logger
    main_file_handler = RotatingFileHandler(str(main_log_path), mode='w', maxBytes=5*1024*1024, backupCount=5)
    main_file_handler.setLevel(logging.INFO)
    main_file_handler.setFormatter(log_format)
    main_logger.addHandler(main_file_handler)

    main_stream_handler = logging.StreamHandler()
    main_stream_handler.setLevel(logging.INFO)
    main_stream_handler.setFormatter(log_format)
    main_logger.addHandler(main_stream_handler)

    # Setup handlers for error logger
    error_file_handler = RotatingFileHandler(str(error_log_path), mode='w', maxBytes=5*1024*1024, backupCount=5)
    error_file_handler.setLevel(logging.WARNING)
    error_file_handler.setFormatter(log_format)
    error_logger.addHandler(error_file_handler)

    error_stream_handler = logging.StreamHandler()
    error_stream_handler.setLevel(logging.WARNING)
    error_stream_handler.setFormatter(log_format)
    error_logger.addHandler(error_stream_handler)


# -------------------- Internal helpers for final log export --------------------
def _lg_should_use_sql_output(run_config) -> bool:
    cfg = getattr(run_config, 'data_source_config', None)
    if not isinstance(cfg, dict):
        return False
    if str(cfg.get('source_type', '')).lower() != 'sql':
        return False
    host = cfg.get('db_host') or cfg.get('host') or cfg.get('server')
    user = cfg.get('db_user') or cfg.get('username') or cfg.get('user')
    pwd = cfg.get('db_password') or cfg.get('password')
    db = cfg.get('db_name') or cfg.get('database') or cfg.get('db')
    return bool(host and user and pwd and db)


def _lg_get_sql_conn_info(run_config) -> Optional[dict]:
    if not _lg_should_use_sql_output(run_config):
        return None
    cfg = run_config.data_source_config
    info = {
        'host': cfg.get('db_host') or cfg.get('host') or cfg.get('server'),
        'user': cfg.get('db_user') or cfg.get('username') or cfg.get('user'),
        'password': cfg.get('db_password') or cfg.get('password'),
        'database': cfg.get('db_name') or cfg.get('database') or cfg.get('db'),
        'port': cfg.get('db_port') or cfg.get('port'),
        'driver': cfg.get('driver'),
        'schema': cfg.get('schema'),
        'encrypt': cfg.get('encrypt'),
        'trust_server_certificate': cfg.get('trust_server_certificate'),
        'timeout': cfg.get('timeout'),
    }
    port = info.get('port')
    driver = (info.get('driver') or '').lower() if info.get('driver') else ''
    host_l = (info.get('host') or '').lower()
    if port == 1433 or 'mssql' in driver or 'sql server' in driver or '.database.windows.net' in host_l:
        info['engine'] = 'mssql'
    else:
        info['engine'] = 'mysql'
    return info


def _lg_get_log_files() -> List[Tuple[str, Path]]:
    files: List[Tuple[str, Path]] = []
    try:
        main_logger = logging.getLogger('main_logger')
        for h in main_logger.handlers:
            if hasattr(h, 'baseFilename'):
                files.append(('main', Path(h.baseFilename)))
                break
    except Exception:
        pass
    try:
        error_logger = logging.getLogger('error_logger')
        for h in error_logger.handlers:
            if hasattr(h, 'baseFilename'):
                files.append(('error', Path(h.baseFilename)))
                break
    except Exception:
        pass
    # Deduplicate
    seen = set()
    unique: List[Tuple[str, Path]] = []
    for t, p in files:
        if t not in seen and p:
            unique.append((t, p))
            seen.add(t)
    return unique


def _lg_parse_log_lines(log_path: Path, log_type: str, run_ts: str):
    import pandas as pd
    rows = []
    if not log_path.exists():
        return pd.DataFrame(columns=['run_ts','log_type','log_time','level','message'])
    try:
        with open(log_path, 'r', encoding='utf-8', errors='ignore') as f:
            for line in f:
                line = line.rstrip('\n')
                ts, lvl, msg = None, None, line
                parts = line.split(' - ', 2)
                if len(parts) == 3:
                    ts, lvl, msg = parts[0], parts[1], parts[2]
                rows.append({
                    'run_ts': run_ts,
                    'log_type': log_type,
                    'log_time': ts,
                    'level': lvl,
                    'message': msg,
                })
    except Exception:
        return pd.DataFrame(columns=['run_id','log_type','log_time','level','message'])
    import pandas as pd
    return pd.DataFrame(rows)


def _lg_truncate_messages_for_sql(engine, info: dict, df):
    try:
        from sqlalchemy import text as sq_text
        max_len = None
        if info.get('engine') == 'mssql':
            schema = info.get('schema') or 'dbo'
            sql = sq_text(
                'SELECT CHARACTER_MAXIMUM_LENGTH AS max_len '
                'FROM INFORMATION_SCHEMA.COLUMNS '
                "WHERE TABLE_SCHEMA = :schema AND TABLE_NAME = 'logs' AND COLUMN_NAME = 'message'"
            )
            with engine.connect() as conn:
                res = conn.execute(sql, {'schema': schema}).fetchone()
                if res and getattr(res, 'max_len', None) and int(res.max_len) > 0:
                    max_len = int(res.max_len)
        else:
            database = info.get('database')
            sql = sq_text(
                'SELECT CHARACTER_MAXIMUM_LENGTH AS max_len '
                'FROM information_schema.columns '
                "WHERE table_schema = :db AND table_name = 'logs' AND column_name = 'message'"
            )
            with engine.connect() as conn:
                res = conn.execute(sql, {'db': database}).fetchone()
                if res and getattr(res, 'max_len', None) and int(res.max_len) > 0:
                    max_len = int(res.max_len)
        if max_len is None:
            return df
        import pandas as pd
        msgs = df['message'].astype(str)
        over = msgs.str.len() > max_len
        count = int(over.sum())
        if count > 0 and max_len > 3:
            df.loc[over, 'message'] = msgs[over].str.slice(0, max_len - 3) + '...'
            logging.getLogger('error_logger').warning(f'Truncated {count} log message(s) to fit DB column length ({max_len}).')
        return df
    except Exception:
        return df


def export_logs_after_run(run_config) -> None:
    """Export main/error logs once at the end of the run.
    If SQL config is active, insert into logs table; else copy timestamped logs to output_path.
    """
    logger = Logger()
    run_ts = datetime.now().strftime('%Y%m%d_%H%M%S')
    log_files = _lg_get_log_files()
    if not log_files:
        return
    info = _lg_get_sql_conn_info(run_config)
    # Try SQL first when configured
    if info:
        try:
            from sqlalchemy import create_engine
            if info.get('engine') == 'mssql':
                driver = info.get('driver') or 'ODBC Driver 17 for SQL Server'
                driver_enc = driver.replace(' ', '+')
                host = info['host']
                port = info.get('port') or 1433
                database = info['database']
                user = info['user']
                password = info['password']
                encrypt = info.get('encrypt')
                tsc = info.get('trust_server_certificate')
                params = []
                if encrypt is not None:
                    params.append('Encrypt=' + ('yes' if str(encrypt).lower() in ['true','1','yes'] else 'no'))
                if tsc is not None:
                    params.append('TrustServerCertificate=' + ('yes' if str(tsc).lower() in ['true','1','yes'] else 'no'))
                param_qs = ('&'.join(params)) if params else ''
                if param_qs:
                    param_qs = '?' + param_qs
                engine_url = f"mssql+pyodbc://{user}:{password}@{host}:{port}/{database}?driver={driver_enc}{param_qs}"
            else:
                host = info['host']
                port = info.get('port') or 3306
                database = info['database']
                user = info['user']
                password = info['password']
                engine_url = f"mysql+mysqlconnector://{user}:{password}@{host}:{port}/{database}"
            engine = create_engine(engine_url, pool_pre_ping=True)

            import pandas as pd
            frames = [_lg_parse_log_lines(p, t, run_ts) for t, p in log_files]
            combined = pd.concat(frames, ignore_index=True) if frames else pd.DataFrame()
            if not combined.empty:
                combined['message'] = combined['message'].astype(str)
                combined = _lg_truncate_messages_for_sql(engine, info, combined)
                schema = info.get('schema') if info.get('engine') == 'mssql' else None
                with engine.begin() as conn:
                    combined.to_sql(
                        name=f'log_{run_ts}',
                        con=conn,
                        schema=schema,
                        if_exists='append',
                        index=False,
                        method='multi',
                        chunksize=1000,
                    )
                masked_host = (info['host'] or '').split(':')[0]
                target_desc = 'SQL Server' if info.get('engine') == 'mssql' else 'SQL (MySQL)'
                logger.info(f"Copied logs to {target_desc} table '{(schema + '.' if schema else '')}logs' on {masked_host}")
                return
        except Exception as e:
            logger.warning(f"SQL log export failed: {str(e)}. Falling back to file copies.")
    # Fallback: copy to output_path
    try:
        out_dir = Path(getattr(run_config, 'output_path', Path('./output')))
        out_dir.mkdir(parents=True, exist_ok=True)
        from shutil import copyfile
        for log_type, path in log_files:
            if not path.exists():
                continue
            dest = out_dir / f"{log_type}_{run_ts}.log"
            copyfile(path, dest)
        logger.info(f"Copied logs to output folder '{out_dir}' with timestamp suffix.")
    except Exception as e:
        logger.warning(f"Failed to copy logs to output folder: {str(e)}")

