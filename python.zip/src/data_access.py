from __future__ import annotations
from abc import ABC, abstractmethod
from dataclasses import dataclass
from pathlib import Path
from typing import Optional, Dict, Any, Union
import pandas as pd
from sqlalchemy import create_engine
from sqlalchemy.engine import Engine
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from src.config import TableIndex


@dataclass
class DatabaseConfig:
    host: str
    user: str
    password: str
    database: str
    port: int = 3306


class DataSource(ABC):
    @abstractmethod
    def get_table_index(self) -> pd.DataFrame:
        pass

    @abstractmethod
    def read_table(self, table_name: str) -> pd.DataFrame:
        pass

    @abstractmethod
    def get_table_path(self, table_name: str) -> str:
        pass


class CSVDataSource(DataSource):
    def __init__(self, data_folder: Path, index_filename: str = 'Index_Tbl.csv'):
        """Initialize with just the data folder path - index file is always Index_Tbl.csv inside data_folder"""
        self.data_folder = data_folder
        self.index_file_path = data_folder / index_filename
        try:
            self._table_index = pd.read_csv(self.index_file_path)
        except Exception as e:
            raise ValueError(f"Error reading index file {self.index_file_path}: {str(e)}")

    def get_table_index(self) -> pd.DataFrame:
        return self._table_index

    def get_table_path(self, table_name: str) -> str:
        """Get the full path to a table file"""
        try:
            row = self._table_index[self._table_index['TableName'] == table_name]
            if row.empty:
                raise ValueError(f"Table '{table_name}' not found in table index.")

            folder_name = row.iloc[0]['FolderName']
            file_name = row.iloc[0]['FileName']

            # Build the path
            if pd.isna(folder_name) or not folder_name:
                file_path = self.data_folder / file_name
            else:
                file_path = self.data_folder / str(folder_name) / file_name

            return str(file_path.resolve())

        except Exception as e:
            raise ValueError(f"Error getting path for table {table_name}: {str(e)}")

    def read_table(self, table_name: str, **kwargs) -> pd.DataFrame:
        try:
            file_path = self.get_table_path(table_name)
            if not file_path:
                raise ValueError(f"Invalid file path for table {table_name}")

            return pd.read_csv(file_path, **kwargs)
        except Exception as e:
            raise ValueError(f"Error reading table {table_name}: {str(e)}")


class SQLDataSource(DataSource):
    def __init__(self, db_config: DatabaseConfig):
        self.db_config = db_config
        self._engine: Optional[Engine] = None
        self._table_mapping: Dict[str, str] = {}  # logical -> physical

    def _get_engine(self) -> Engine:
        if self._engine is None:
            url = (
                f"mysql+mysqlconnector://{self.db_config.user}:{self.db_config.password}"
                f"@{self.db_config.host}:{self.db_config.port}/{self.db_config.database}"
            )
            self._engine = create_engine(url, pool_pre_ping=True)
        return self._engine

    def _ensure_mapping(self):
        """Load (or reload) logical -> physical mapping from table_index."""
        if not self._table_mapping:
            schema = self.db_config.database
            sql = f"""
            SELECT
                TableName,
                SQL_TableName
            FROM `{schema}`.`table_index`
            """
            engine = self._get_engine()
            df = pd.read_sql_query(sql, engine)
            self._table_mapping = dict(zip(df['TableName'], df['SQL_TableName']))

    def get_table_index(self) -> pd.DataFrame:
        """Return the raw index as a DataFrame."""
        self._ensure_mapping()
        return pd.DataFrame([
            {'TableName': k, 'SQL_TableName': v}
            for k, v in self._table_mapping.items()
        ])

    def get_table_path(self, table_name: str) -> str:
        """Return the fully qualified table name: `schema.physical_table`."""
        self._ensure_mapping()
        phys = self._table_mapping.get(table_name)
        if not phys:
            raise ValueError(f"Table '{table_name}' not found in table_index.")
        # Use backticks in case of special characters
        return f"`{self.db_config.database}`.`{phys}`"

    def read_table(self, table_name: str, **kwargs) -> pd.DataFrame:
        """
        Load a table into a DataFrame.
        
        kwargs passed to pandas.read_sql_query(), e.g. index_col, parse_dates.
        """
        fq_table = self.get_table_path(table_name)
        sql = f"SELECT * FROM {fq_table}"
        engine = self._get_engine()
        return pd.read_sql_query(sql, engine, **kwargs)

    def __del__(self):
        try:
            if getattr(self, '_engine', None) is not None:
                self._engine.dispose()
        except Exception:
            pass


class DataSourceFactory:
    @staticmethod
    def create_data_source(data_config: Dict[str, Any]) -> DataSource:
        """Create a DataSource instance from configuration"""
        source_type = data_config.get('source_type', 'csv')

        if source_type == 'csv':
            data_folder = Path(data_config['data_folder'])
            return CSVDataSource(data_folder)
        elif source_type == 'sql':
            db_config = DatabaseConfig(
                host=data_config.get('db_host', 'localhost'),
                user=data_config.get('db_user', 'root'),
                password=data_config.get('db_password', ''),
                database=data_config.get('db_name', 'python_model'),
                port=data_config.get('db_port', 3306)
            )
            return SQLDataSource(db_config)

        raise ValueError(f"Unsupported data source type: {source_type}")

    @staticmethod
    def create_table_index(data_config: Dict[str, Any]) -> 'TableIndex':
        """Create a TableIndex instance directly from data source config"""
        data_source = DataSourceFactory.create_data_source(data_config)
        from src.config import TableIndex  # Import here to avoid circular imports
        return TableIndex.load_table_index(data_source)

