# term_calc_engine.py

import jax
import jax.numpy as jnp
from jax import lax
import numpy as np
from typing import Dict, Any
from src.base_calc_engine import CalculationEngine
from src.jax_config import FLOAT_DTYPE, INT_DTYPE
from src.assumptions import IFRS17
import pandas as pd
import copy


class TermCalculationEngine(CalculationEngine):
    """
    Performs term product calculations.
    """
    # Class attribute for zero arrays to avoid redundant allocations
    ZERO_ARRAY = None  # Will be initialized in the prepare_policy_data method

    def run_batch(self, batch_policy_data: Dict[str, jnp.ndarray], batch_policy_numbers: Any):
        """
        Performs calculations for a single batch of term policies.
        """

        # Prepare policy data
        policy_attrs = self.prepare_policy_data(batch_policy_data)

        # Initialize zero array
        self.ZERO_ARRAY = jnp.zeros((policy_attrs['num_policies'], self.projection_months), dtype=FLOAT_DTYPE)

        # Compute rates
        rates = self.compute_rates(policy_attrs)

        # Calculate decrements and gross of reinsurance cashflows
        # Decrements for Reserving layer
        decrements_reserving = self.calculate_decrements(policy_attrs, rates, layer='Reserving')

        # Cashflows for Reserving layer (gross of reinsurance)
        reinsurance_results= None
        gross_cf_reserving = self.calculate_cash_flows(policy_attrs, rates, decrements_reserving, reinsurance_results, layer='Reserving')

        # First backward pass - Calculate discounted cash flows and Gross Reserve PP
        # gross_reserves = self.calculate_discounted_cf_reserves(policy_attrs, rates, decrements_reserving, gross_cf_reserving)
        
        # Second forward pass - Calculate reinsurance cashflows and net CF with reinsurance
        reinsurance_results = self.calculate_reinsurance_cashflows(policy_attrs, rates, decrements_reserving, gross_cf_reserving)
        
        # Second backward pass - Calculate net reserves
        net_reserves = self.calculate_net_reserves(policy_attrs, rates, decrements_reserving, reinsurance_results)

        # Decrements for BE layer
        decrements_BE = self.calculate_decrements(policy_attrs, rates, layer='BE')
        
        # Third forward pass - BE Layer cashflows, reserves, solvency capital, profit
        reinsurance_results_BE = self.calculate_reinsurance_cashflows(policy_attrs, rates, decrements_BE, gross_cf_reserving)
        be_results = self.calculate_be_layer(policy_attrs, rates, decrements_BE, reinsurance_results_BE, gross_cf_reserving['gross_reserve_pp'], net_reserves['net_reserve_pp'])

        # Third backward pass - Calculate MCEV, BEL, PVFP, and FCC
        pv_results = self.calculate_pv_variables(policy_attrs, rates, be_results, reinsurance_results_BE, decrements_BE, batch_policy_numbers=batch_policy_numbers)

        # Add IFRS calculations
        #ifrs_results = self.calculate_ifrs_layer(policy_attrs,batch_policy_numbers, rates, decrements_BE, reinsurance_results_BE, gross_cf_reserving['gross_reserve_pp'], net_reserves['net_reserve_pp'], config)

        results_dict = {
            'policy_attrs': policy_attrs,
            'rates':rates,
            'gross_cf_reserving': gross_cf_reserving,
            'reinsurance_results': reinsurance_results,
            'net_reserves': net_reserves,
            'decrements_reserving': decrements_reserving,
            'decrements_BE': decrements_BE,
            'reinsurance_results_BE': reinsurance_results_BE,
            'be_results': be_results,
            'pv_results': pv_results,
            #'ifrs_results': ifrs_results
        }

        return results_dict        
    
    def create_output_df(self, batch_policy_numbers, results_dict: Dict[str, Any]):
        """Create output dataframes"""

        policy_attrs = results_dict['policy_attrs']
        rates = results_dict['rates']
        gross_cf_reserving = results_dict['gross_cf_reserving']
        reinsurance_results = results_dict['reinsurance_results']
        net_reserves = results_dict['net_reserves']
        decrements_reserving = results_dict['decrements_reserving']
        decrements_BE = results_dict['decrements_BE']
        reinsurance_results_BE = results_dict['reinsurance_results_BE']
        be_results = results_dict['be_results']
        pv_results = results_dict['pv_results']
        #ifrs_results = results_dict['ifrs_results']

        # Prepare data for output
        projection_steps = policy_attrs['projection_steps']
        combined_data = {
            'Policy_Number': np.repeat(batch_policy_numbers, projection_steps.size),
            'Policy_Month': np.array(policy_attrs['policy_months']).reshape(-1),
            'Calendar_Month': np.tile(policy_attrs['calendar_months'], len(batch_policy_numbers)),
            'Projection_Step': np.tile(np.arange(projection_steps.size), len(batch_policy_numbers)),
            'Modal_Factor': np.array(rates['modal_factor']).reshape(-1),
        }

        # Add reserving decrements with suffix
        for key, value in decrements_reserving.items():
            combined_data[f"decrements_{key}_reserving"] = np.array(value).flatten()

        # Add reserving cashflows with suffix
        for key, value in gross_cf_reserving.items():
            combined_data[f"cashflows_{key}_reserving"] = np.array(value).flatten()

        # Add Reserving cashflows with suffix
        for key, value in reinsurance_results.items():
            combined_data[f"cashflows_{key}_reserving"] = np.array(value).flatten()

        # Add reserves
        for key, value in net_reserves.items():
            combined_data[f"cashflows_{key}_reserving"]  = np.array(value).flatten()

        # Add BE decrements with suffix
        for key, value in decrements_BE.items():
            combined_data[f"decrements_{key}_BE"] = np.array(value).flatten()

        # Add BE cashflow calculations
        for key, value in be_results.items():
            combined_data[f"cashflows_{key}_BE"]  = np.array(value).flatten()
        
        # Add BE reinsurance cashflows with suffix
        for key, value in reinsurance_results_BE.items():
            combined_data[f"cashflows_{key}_BE"] = np.array(value).flatten()

        # Add PV calculations
        for key, value in pv_results.items():
            combined_data[f"MCEV_{key}_BE"]  = np.array(value).flatten()

         # Add IFRS fields to combined_data
        #for key, value in ifrs_results.items():
            #combined_data[f"ifrs_{key}"] = np.array(value).flatten()

        # Store combined results
        return combined_data
    
    def create_bplan_output_df(self, batch_policy_numbers, results_dict: Dict[str, Any], sales_key):
        """Create output dataframes"""

        policy_attrs = results_dict['policy_attrs']
        be_results = results_dict['be_results']
        pv_results = results_dict['pv_results']

        # Prepare data for output
        projection_steps = policy_attrs['projection_steps']
        combined_data = {
            'Policy_Number': np.repeat(batch_policy_numbers, projection_steps.size/len(batch_policy_numbers)),
            'Sales_Key': np.repeat(sales_key, projection_steps.size/len(batch_policy_numbers)),
            'Policy_Month': np.array(policy_attrs['policy_months']).reshape(-1),
            'Calendar_Month': np.tile(policy_attrs['calendar_months'], len(batch_policy_numbers)),
            'Financial_Year': np.tile(policy_attrs['fy'], len(batch_policy_numbers)),
            'Projection_Step': np.array(projection_steps).reshape(-1),
            'Number_of_policies': np.array(policy_attrs['no_of_pol']).reshape(-1)
        }

        # Add BE cashflow calculations
        be_results_keys_remove = ['be_reinsurance_recoveries','be_net_cf', 'be_reserves',
                                  'part1_sm', 'part2_sm','gross_sar', 'net_sar','increase_in_solvency_capital', 'interest_on_solvency_capital',
                                  'profit_before_tax', 'csr', 'tax', 'net_profit_before_sm','cost_of_capital', 'net_profit_after_sm']
        be_results_filtered = {key: value for key, value in be_results.items() if key not in be_results_keys_remove}
        for key, value in be_results_filtered.items():
            combined_data[f"{key}"]  = np.array(value).flatten()

        # Add PV calculations
        pv_results_keys_remove = ['interest_on_cashflows', 'interest_on_reserve', 'net_cf', 'profit_before_tax', 'csr', 'tax', 'net_profit', 'pvfp', 
                                  'pv_premium', 'interest_on_sm', 'tax_interest_on_sm', 'csr_interest_on_sm', 'coc', 'fcc', 'bel', 'bel_pp']
        pv_results_filtered = {key: value for key, value in pv_results.items() if key not in pv_results_keys_remove}
        for key, value in pv_results_filtered.items():
            combined_data[f"MCEV_{key}_BE"]  = np.array(value).flatten()

        # Store combined results
        return combined_data


    def prepare_policy_data(self, batch_policy_data: Dict[str, jnp.ndarray]) -> Dict[str, Any]:
        """
        Prepares and expands policy data for calculations.
        """
        num_policies = batch_policy_data['Policy_Term'].shape[0]
        time_vector = jnp.arange(0, self.projection_months)  # Shape: (num_months,)
        policy_terms_months = batch_policy_data['Policy_Term'] * 12  # Shape: (num_policies,)
        duration_in_months = batch_policy_data['Duration_in_Months']  # Shape: (num_policies,)

        # Adjust time vectors for policies
        policy_months = duration_in_months[:, None] + time_vector[None, :]  # Shape: (num_policies, num_months)

        # Create masks for in-force policies considering duration in months
        policy_masks = (policy_months <= policy_terms_months[:, None]) * (policy_months>0)  # Shape: (num_policies, num_months)

        # Policy years
        policy_years = ((policy_months - 1) // 12) + 1  # Shape: (num_policies, num_months)

        # Expand policy attributes across time periods
        ages = batch_policy_data['Age_at_Entry'][:, None] + ((policy_months - 1) // 12)  # Shape: (num_policies, num_months)
        genders = batch_policy_data['Gender_Code'][:, None]  # Shape: (num_policies, 1)
        genders = jnp.tile(genders, (1, self.projection_months))
        emrs = batch_policy_data['EMR'][:, None]  # Shape: (num_policies, 1)
        emrs = jnp.tile(emrs, (1, self.projection_months))
        reins_emrs = batch_policy_data['reins_EMR'][:, None]  # Shape: (num_policies, 1)
        reins_emrs = jnp.tile(reins_emrs, (1, self.projection_months))
        sum_assureds = batch_policy_data['Sum_Assured'][:, None]  # Shape: (num_policies, 1)
        sum_assureds = jnp.tile(sum_assureds, (1, self.projection_months))
        premium_amounts = batch_policy_data['Premium_Amount'][:, None]  # Shape: (num_policies, 1)
        premium_amounts = jnp.tile(premium_amounts, (1, self.projection_months))
        premium_frequencies = batch_policy_data['Premium_Frequency'][:, None]  # Shape: (num_policies, 1)
        premium_frequencies = jnp.tile(premium_frequencies, (1, self.projection_months))
        distribution_channels = batch_policy_data['Distribution_Channel'][:, None]  # Shape: (num_policies, 1)
        distribution_channels = jnp.tile(distribution_channels, (1, self.projection_months))

        # Calendar Month calculation based on valuation date
        valuation_month = self.config.valuation_date.month
        calendar_months = (valuation_month - 1 + time_vector) % 12 + 1  # Shape: (num_months,)
        financial_year_ind = jnp.arange(valuation_month, self.projection_months+valuation_month) 
        valuation_year = self.config.valuation_date.year
        calendar_years = valuation_year + (time_vector // 12)  # Assuming time_vector is in months

        def financial_year(ind,year):
            fy = []
            for i in ind:
                if i % 12==0:
                    financial_year = (int(i/12)-1) + year
                else:
                    financial_year = int(i/12) + year
                fy.append(financial_year)
            return fy
        
        fy = financial_year(financial_year_ind,self.config.valuation_date.year)

        # Projection Step: 1 to num_months
        if self.config.run_type =='BusinessPlanning':
            projection_steps = policy_months  # Shape: (num_months,)
            no_of_pol = batch_policy_data['no_of_pol'][:, None]  # Shape: (num_policies, 1)
            no_of_pol = jnp.tile(no_of_pol, (1, self.projection_months))
        else:
            projection_steps = time_vector

        policy_attrs = {
            'num_policies': num_policies,
            'time_vector': time_vector,  # Shape: (num_months,)
            'policy_masks': policy_masks,  # Shape: (num_policies, num_months)
            'policy_terms_months': policy_terms_months,  # Shape: (num_policies,)
            'policy_months': policy_months,  # Shape: (num_policies, num_months)
            'policy_years': policy_years,  # Shape: (num_policies, num_months)
            'ages': ages,  # Shape: (num_policies, num_months)
            'genders': genders,  # Shape: (num_policies, num_months)
            'emrs': emrs,  # Shape: (num_policies, num_months)
            'reins_emrs' : reins_emrs,
            'sum_assureds': sum_assureds,  # Shape: (num_policies, num_months)
            'premium_amounts': premium_amounts,  # Shape: (num_policies, num_months)
            'premium_frequencies': premium_frequencies,  # Shape: (num_policies, num_months)
            'distribution_channels': distribution_channels,  # Shape: (num_policies, num_months)
            'calendar_months': calendar_months,  # Shape: (num_months,)
            'fy': fy,  # Shape: (num_months,)
            'projection_steps': projection_steps,  # Shape: (num_months,)
            'calendar_years': calendar_years,
        }

        if self.config.run_type =='BusinessPlanning':
            bplan_fields = {
            'no_of_pol':no_of_pol,
            }
            policy_attrs.update(bplan_fields)

        return policy_attrs

    def compute_rates(self, policy_attrs: Dict[str, Any]) -> Dict[str, Any]:
        """
        Computes rates using assumption classes.
        """
        ages = policy_attrs['ages']  # Shape: (num_policies, num_months)
        genders = policy_attrs['genders']  # Shape: (num_policies, num_months)
        emrs = policy_attrs['emrs']  # Shape: (num_policies, num_months)
        reins_emrs = policy_attrs['reins_emrs']
        premium_frequencies = policy_attrs['premium_frequencies']  # Shape: (num_policies, num_months)
        policy_years = policy_attrs['policy_years']  # Shape: (num_policies, num_months)
        distribution_channels = policy_attrs['distribution_channels']  # Shape: (num_policies, num_months)
        policy_months = policy_attrs['policy_months']  # Shape: (num_policies, num_months)

        # Read MAD factors and other config variables from product config
        MAD_Mortality = float(self.product_config.variables.get('MAD_Mortality', 0.0))
        MAD_Lapse = float(self.product_config.variables.get('MAD_Lapse', 0.0))
        MAD_Expense = float(self.product_config.variables.get('MAD_Expense', 0.0))
        Inflation_Factor = float(self.product_config.variables.get('Inflation', 0.0))
        Reinsurance_Retention_Limit = float(self.product_config.variables.get('Reinsurance Retention Limit abs', 0.0))

        # Mortality rates
        mortality_rates_base = self.assumptions['mortality'].get_annual_rate_vectorized(ages, genders)  # Shape: (num_policies, num_months)
        mortality_rates_BE = mortality_rates_base * emrs  * (policy_months>0)# BE layer
        mortality_rates_reserving = mortality_rates_BE * (1 + MAD_Mortality)  # Reserving layer

        # Reinsurance Mortality Rates
        reinsurance_mortality_rates_base = self.assumptions['reinsurance_mortality'].get_annual_rate_vectorized(ages, genders)
        reinsurance_mortality_rates = reinsurance_mortality_rates_base * reins_emrs * (policy_months>0)
        reinsurance_mortality_rates_monthly = 1 - (1 - reinsurance_mortality_rates) ** (1 / 12)  # Shape: (num_policies, num_months)

        # Convert to monthly mortality rates
        monthly_mortality_rates_BE = 1 - (1 - mortality_rates_BE) ** (1 / 12)
        monthly_mortality_rates_reserving = 1 - (1 - mortality_rates_reserving) ** (1 / 12)

        # Premium Modal factors
        modal_factor = self.assumptions['modal_factor'].get_annual_rate_vectorized(premium_frequencies)  # Shape: (num_policies, num_months)
        
        # Lapse rates
        lapse_rates_base = self.assumptions['persistency'].get_annual_lapse_rate_vectorized(
            policy_years=policy_years,
            distribution_channels=distribution_channels
        )  # Shape: (num_policies, num_months)

        # Lapse rate formula
        lapse_due_mask = jnp.where(
            (policy_months + 1) % (12 / premium_frequencies) == jnp.where(premium_frequencies == 12, 0, 1),
            1.0,
            0.0
        )
        lapse_due_mask = lapse_due_mask * (policy_months > 0).astype(FLOAT_DTYPE)
        lapse_rates_BE = lapse_rates_base * lapse_due_mask
        lapse_rates_reserving = lapse_rates_BE * (1 + MAD_Lapse)

        # Convert to monthly lapse rates
        monthly_lapse_rates_BE = 1 - (1 - lapse_rates_BE) ** (1 / premium_frequencies)
        monthly_lapse_rates_reserving = 1 - (1 - lapse_rates_reserving) ** (1 / premium_frequencies)

        # Commission rates
        commission_rates = self.assumptions['commissions'].get_commission_rate_vectorized(
            policy_years=policy_years,
            distribution_channels=distribution_channels
        )  # Shape: (num_policies, num_months)

        # Expense rates
        # Initial expenses components
        initial_expense = self.assumptions['expense'].get_initial_expense_rates(policy_attrs['sum_assureds'])
        init_fixed_expense_rate = initial_expense.get('Fixed', 0.0)  # scalar
        init_percent_prem_expense_rate = initial_expense.get('% of Prem', 0.0)  # scalar
        init_percent_sa_expense_rate = initial_expense.get('% of SA', 0.0)  # scalar

        # Renewal expenses components
        renewal_expenses = self.assumptions['expense'].get_renewal_expense_rates()
        fixed_expense_rate = renewal_expenses.get('Fixed expenses', 0.0) # scalar
        percent_prem_expense_rate = renewal_expenses.get('% of Prem', 0.0) # scalar

        # Claim expense rate
        claim_expense_rate = renewal_expenses.get('Claim expenses', 0.0) / 100.0  # scalar

        # Fetch monthly interest rates
        monthly_ROI_rates_raw = self.assumptions['interest_rate'].get_monthly_rates('ROI')  # For BE layer
        monthly_ROI_rates = np.zeros_like(monthly_ROI_rates_raw)
        monthly_ROI_rates[1:] = monthly_ROI_rates_raw[:-1]

        monthly_VROI_rates_raw = self.assumptions['interest_rate'].get_monthly_rates('VROI')  # For Reserving layer
        monthly_VROI_rates = np.zeros_like(monthly_VROI_rates_raw)
        monthly_VROI_rates[1:] = monthly_VROI_rates_raw[:-1]

        monthly_CCIL_rates_raw = self.assumptions['interest_rate'].get_monthly_rates('CCIL')  # For MCEV calculations
        monthly_CCIL_rates = np.zeros_like(monthly_CCIL_rates_raw)
        monthly_CCIL_rates[1:] = monthly_CCIL_rates_raw[:-1]

        rates = {
            'monthly_mortality_rates_BE': monthly_mortality_rates_BE,  # Shape: (num_policies, num_months)
            'monthly_mortality_rates_reserving': monthly_mortality_rates_reserving,  # Shape: (num_policies, num_months)
            'monthly_lapse_rates_BE': monthly_lapse_rates_BE,  # Shape: (num_policies, num_months)
            'monthly_lapse_rates_reserving': monthly_lapse_rates_reserving,  # Shape: (num_policies, num_months)
            'commission_rates': commission_rates,  # Shape: (num_policies, num_months)
            'reinsurance_mortality_rates': reinsurance_mortality_rates_monthly,  # Shape: (num_policies, num_months)
            'fixed_expense_rate': fixed_expense_rate,  # scalar
            'percent_prem_expense_rate': percent_prem_expense_rate,  # scalar
            'claim_expense_rate': claim_expense_rate,  # scalar
            'MAD_Expense': MAD_Expense,  # scalar
            'Inflation_Factor': Inflation_Factor,  # scalar
            'Reinsurance_Retention_Limit': Reinsurance_Retention_Limit,  # scalar
            'monthly_ROI_rates': monthly_ROI_rates,  # Shape: (num_months,)
            'monthly_VROI_rates': monthly_VROI_rates,  # Shape: (num_months,)
            'monthly_CCIL_rates': monthly_CCIL_rates,  # Shape: (num_months,)
            'init_fixed_expense_rate': init_fixed_expense_rate,  # scalar
            'init_percent_prem_expense_rate': init_percent_prem_expense_rate,  # scalar
            'init_percent_sa_expense_rate': init_percent_sa_expense_rate,  # scalar
            'modal_factor': modal_factor
        }

        return rates

    def calculate_decrements(self,
        policy_attrs: Dict[str, Any],
        rates: Dict[str, Any],
        layer: str
    ) -> Dict[str, jnp.ndarray]:
        """
        Calculates decrements for the specified layer ('BE' or 'Reserving').

        Args:
            policy_attrs (Dict[str, Any]): Policy attributes.
            rates (Dict[str, Any]): Computed rates.
            layer (str): The layer for which to calculate decrements ('BE' or 'Reserving').

        Returns:
            Dict[str, jnp.ndarray]: Decrement results.
        """
        num_policies = policy_attrs['num_policies']
        # Ensure shapes are compatible
        policy_months = policy_attrs['policy_months']  # Shape: (num_policies, num_months)
        policy_terms_months = policy_attrs['policy_terms_months']  # Shape: (num_policies,)
        time_vector = policy_attrs['time_vector']  # Shape: (num_months,)

        if layer == 'BE':
            mortality_rates = rates['monthly_mortality_rates_BE']  # Shape: (num_policies, num_months)
            lapse_rates = rates['monthly_lapse_rates_BE']  # Shape: (num_policies, num_months)
        else:  # Reserving
            mortality_rates = rates['monthly_mortality_rates_reserving']  # Shape: (num_policies, num_months)
            lapse_rates = rates['monthly_lapse_rates_reserving']  # Shape: (num_policies, num_months)

        # Apply mask to set rates at time 0 to zero
        time_mask = (time_vector[None, :] > 0).astype(FLOAT_DTYPE)
        mortality_rates *= time_mask
        lapse_rates *= time_mask

        # Maturities: Occur when the policy term ends
        # policy_terms_months: Duration from start to end in months
        # Current policy month
        maturities = jnp.where(
            policy_months == (policy_terms_months[:, None]),
            1.0,  # All remaining lives mature
            0.0
        )  # Shape: (num_policies, num_months)

        # Prepare inputs for scan
        inputs = (
            mortality_rates.T,
            lapse_rates.T,
            maturities.T
        )

        # Initial carry (lives at end of month -1, which is 1)
        init_carry = jnp.ones(num_policies, dtype=FLOAT_DTYPE)

        # Define step function
        def decrement_step(carry, inputs):
            lives_prev = carry
            mortality_rate, lapse_rate, maturity = inputs

            lives_so_begin = lives_prev
            deaths = lives_so_begin * mortality_rate
            total_decrement_rate = mortality_rate + lapse_rate
            lapses = (lives_so_begin - deaths) * lapse_rate 
            lapses = jnp.where(total_decrement_rate > 0, lapses, 0.0)
            maturities_actual = (lives_so_begin - deaths - lapses) * maturity  # All remaining lives mature
            lives_so_end = lives_so_begin - deaths - lapses - maturities_actual
            lives_so_end = jnp.maximum(lives_so_end, 0.0)

            outputs = (lives_so_begin, deaths, lapses, maturities_actual, lives_so_end)
            return lives_so_end, outputs

        # Run scan
        _, outputs = lax.scan(decrement_step, init_carry, inputs)

        # Extract outputs
        lives_so_begin = outputs[0].T
        deaths = outputs[1].T
        lapses = outputs[2].T
        maturities_actual = outputs[3].T
        lives_so_end = outputs[4].T

        decrements = {
            'lives_so_begin': lives_so_begin,
            'deaths': deaths,
            'lapses': lapses,
            'maturities': maturities_actual,
            'lives_so_end': lives_so_end
        }

        return decrements

    def calculate_cash_flows(
        self,
        policy_attrs: Dict[str, Any],
        rates: Dict[str, Any],
        decrements: Dict[str, jnp.ndarray],
        reinsurance_results,
        layer: str,
    ) -> Dict[str, jnp.ndarray]:
        """
        Calculates cash flows for the specified layer ('BE' or 'Reserving').

        Args:
            policy_attrs (Dict[str, Any]): Policy attributes.
            rates (Dict[str, Any]): Computed rates.
            decrements (Dict[str, jnp.ndarray]): Decrement results.
            layer (str): The layer ('BE' or 'Reserving').

        Returns:
            Dict[str, jnp.ndarray]: Cashflow results.
        """
        time_vector = policy_attrs['time_vector']  # Shape: (num_months,)
        premium_amounts = policy_attrs['premium_amounts']  # Shape: (num_policies, num_months)
        premium_frequencies = policy_attrs['premium_frequencies']  # Shape: (num_policies, num_months)
        sum_assureds = policy_attrs['sum_assureds']  # Shape: (num_policies, num_months)
        commission_rates = rates['commission_rates']  # Shape: (num_policies, num_months)
        fixed_expense_rate = rates['fixed_expense_rate']  # scalar
        percent_prem_expense_rate = rates['percent_prem_expense_rate']  # scalar
        claim_expense_rate = rates['claim_expense_rate']  # scalar
        Inflation_Factor = rates['Inflation_Factor']  # scalar
        MAD_Expense = rates['MAD_Expense'] if layer == 'Reserving' else 0.0  # scalar
        Reinsurance_Retention_Limit = rates['Reinsurance_Retention_Limit']  # scalar
        init_fixed_expense_rate = rates['init_fixed_expense_rate']  # scalar
        init_percent_prem_expense_rate = rates['init_percent_prem_expense_rate']  # scalar
        init_percent_sa_expense_rate = rates['init_percent_sa_expense_rate']  # scalar
        monthly_interest_rates = rates['monthly_VROI_rates'] if layer == 'Reserving' else rates['monthly_ROI_rates']
        modal_factor = rates['modal_factor']

        # Decrements
        lives_so_begin = decrements['lives_so_begin']  # Shape: (num_policies, num_months)
        deaths = decrements['deaths']  # Shape: (num_policies, num_months)
        lapses = decrements['lapses']  # Shape: (num_policies, num_months)
        maturities = decrements['maturities']  # Shape: (num_policies, num_months)
        lives_so_end = decrements['lives_so_end']  # Shape: (num_policies, num_months)

        # Premiums: Only in the first month of each policy year
        premium_due_mask = jnp.where((premium_frequencies==12), 1,(((policy_attrs['policy_months'] % (12/premium_frequencies))) == 1).astype(FLOAT_DTYPE))        
        premium_due_mask = premium_due_mask * (policy_attrs['projection_steps'] > 0).astype(FLOAT_DTYPE)  # Exclude time 0
        premiums = (premium_amounts * modal_factor) * premium_due_mask * lives_so_begin  # Shape: (num_policies, num_months)

        # Commissions
        commissions = premiums * commission_rates  # Shape: (num_policies, num_months)
        
        # Initial Expense (only in first month)
        # Compute initial expense per policy (shape: (num_policies,))
        initial_expense_per_policy = (
            init_fixed_expense_rate +
            init_percent_prem_expense_rate * premium_amounts[:, 1] +
            init_percent_sa_expense_rate * sum_assureds[:, 0]
        )
        # * (policy_attrs['policy_months'][:,1]==1)
        # Expand to shape (num_policies, 1)
        initial_expense_per_policy = initial_expense_per_policy[:, None]
        # Compute initial expense (shape: (num_policies, num_months))
        initial_expense = initial_expense_per_policy * (policy_attrs['policy_months'] == 1).astype(FLOAT_DTYPE) * lives_so_begin * (policy_attrs['projection_steps']>0)
        
        # Renewal Expenses
        renewal_expenses = (
            ((fixed_expense_rate + percent_prem_expense_rate * premium_amounts)/12) *
            (1 + Inflation_Factor) ** ((policy_attrs['projection_steps'] - 1)/12) *
            (1 + MAD_Expense)
        ) * lives_so_begin * (policy_attrs['policy_years'] > 1)  # Shape: (num_policies, num_months)

        # Claim Expenses
        claim_expenses = sum_assureds * claim_expense_rate * deaths  # Shape: (num_policies, num_months)

        # Death Benefits
        death_benefits = sum_assureds * deaths  # Shape: (num_policies, num_months)

        # Surrender Benefits (0 for term policies)
        surrender_benefits = jnp.zeros_like(premiums)  # Shape: (num_policies, num_months)
        
        if layer == 'BE':
            interest_on_cashflows = (premiums - commissions - initial_expense - renewal_expenses - reinsurance_results['reins_premiums']) * monthly_interest_rates
        else:
            interest_on_cashflows = (premiums - commissions - initial_expense - renewal_expenses) * monthly_interest_rates
            
        interest_on_cashflows = interest_on_cashflows * (policy_attrs['projection_steps'] > 0)
        # Net Cash Flows
        net_cash_flows = - (premiums - commissions - initial_expense - renewal_expenses - claim_expenses - death_benefits - surrender_benefits + interest_on_cashflows) * (policy_attrs['projection_steps']>0) # Shape: (num_policies, num_months)

        # Apply time mask to cashflows (set cashflows at time 0 to zero)
        time_mask = (policy_attrs['time_vector'][None, :] > 0).astype(FLOAT_DTYPE)

        premiums *= time_mask
        commissions *= time_mask
        renewal_expenses *= time_mask
        claim_expenses *= time_mask
        death_benefits *= time_mask
        surrender_benefits *= time_mask
        net_cash_flows *= time_mask

        # Discounting using appropriate rate
        if layer == 'BE':
            discount_rates = rates['monthly_ROI_rates']  # For BE layer
        else:
            discount_rates = rates['monthly_VROI_rates']  # For Reserving layer

        # Reverse arrays for backward calculation
        net_cash_flows_rev = net_cash_flows[:, ::-1]  # Shape: (num_policies, num_months)
        discount_rates_rev = discount_rates[::-1]  # Shape: (num_months,)

        # Function to discount cash flows for a single policy
        def discount_policy_cashflows(net_cash_flow_rev):
            def discount_step(carry, inputs):
                discount_rate, net_cf = inputs
                pv_next = carry
                pv = (pv_next + net_cf) / (1 + discount_rate)
                return pv, pv

            init_carry = 0.0
        
            _, discounted_net_cf_rev = lax.scan(
                discount_step,
                init_carry,
                (discount_rates_rev, net_cash_flow_rev)
            )

            return discounted_net_cf_rev

        # Apply the function to each policy
        discounted_net_cf_rev = jax.vmap(discount_policy_cashflows)(net_cash_flows_rev)

        # Reverse back to original order
        discounted_net_cf = discounted_net_cf_rev[:, ::-1]

        discounted_net_cf = discounted_net_cf.at[:, :2].set(0.0)
    
        # Gross and Net Reserves Per Policy
        # Reserves per policy are the discounted net cashflows divided by lives at end
        if self.config.run_type in ['Valuation','CRNHR']:
            discounted_net_cf = jnp.concatenate([discounted_net_cf[:, 1:], jnp.zeros((discounted_net_cf.shape[0], 1))], axis=1)
            gross_reserve_pp = discounted_net_cf / jnp.maximum(decrements['lives_so_end'] + decrements['maturities'], 1e-6) # Shape: (num_policies, num_months)
        else:
            discounted_net_cf = jnp.concatenate([discounted_net_cf[:, 1:], jnp.zeros((discounted_net_cf.shape[0], 1))], axis=1) * (policy_attrs['projection_steps']>0)
            gross_reserve_pp = discounted_net_cf / jnp.maximum(decrements['lives_so_end'] + decrements['maturities'], 1e-6) * (policy_attrs['projection_steps']>0) # Shape: (num_policies, num_months)
        gross_reserve_pp = jnp.maximum(gross_reserve_pp, 0.0)  # Prevent negative reserves

        cashflows = {
            'premiums': premiums,
            'commissions': commissions,
            'initial_expense': initial_expense,
            'renewal_expenses': renewal_expenses,
            'claim_expenses': claim_expenses,
            'death_benefits': death_benefits,
            'interest_on_cashflows': interest_on_cashflows,
            'surrender_benefits': surrender_benefits,
            'net_cashflows': net_cash_flows,
            'discounted_net_cf': discounted_net_cf,
            'gross_reserve_pp': gross_reserve_pp,
        }

        return cashflows

    def calculate_discounted_cf_reserves(self, policy_attrs, rates, decrements, gross_cf):
        """
        First backward pass - Calculate discounted cash flows and Gross Reserve PP.
        """

        net_cashflows = gross_cf['net_cashflows']
        lives_so_end = decrements['lives_so_end']
        maturities = decrements['maturities']

        monthly_interest_rates = rates['monthly_VROI_rates']
        discount_factors = jnp.cumprod(1 / (1 + monthly_interest_rates[::-1]))[::-1]

        discounted_net_cf = net_cashflows * discount_factors[None, :]
        discounted_cf_cumsum = jnp.cumsum(discounted_net_cf[:, ::-1], axis=1)[:, ::-1]

        gross_reserve_pp = jnp.maximum(
            discounted_cf_cumsum / (lives_so_end + maturities + 1e-8), 0.0
        )

        gross_reserves = {
            'discounted_cf_reserving': discounted_cf_cumsum,
            'gross_reserve_pp': gross_reserve_pp,
        }

        return gross_reserves

    def calculate_reinsurance_cashflows(self, policy_attrs, rates, decrements, gross_cf):
        """
        Second forward pass - Calculate reinsurance cashflows and net CF with reinsurance.
        """

        # Extract variables
        sum_assureds = policy_attrs['sum_assureds']
        Reinsurance_Retention_Limit = rates['Reinsurance_Retention_Limit']

        lives_so_begin = decrements['lives_so_begin']
        deaths = decrements['deaths']
        net_cashflows = gross_cf['net_cashflows']
        gross_reserve_pp = gross_cf['gross_reserve_pp']

        # Reinsurance Sum Assured
        gross_reserve_pp_prev = jnp.pad(gross_reserve_pp[:, :-1], ((0, 0), (1, 0)), constant_values=0.0)
        reins_sum_assured = jnp.maximum(
            sum_assureds - Reinsurance_Retention_Limit - gross_reserve_pp_prev,
            0.0
        ) * (policy_attrs['projection_steps']>0)

        # Reinsurance Mortality Rates
        reinsurance_mortality_rates = rates['reinsurance_mortality_rates']

        # Reinsurance Premiums and Recoveries
        reins_premiums = reinsurance_mortality_rates * reins_sum_assured * lives_so_begin * (policy_attrs['projection_steps']>0)
        reins_recoveries = reins_sum_assured * deaths

        net_cf_with_reinsurance = (net_cashflows + reins_premiums - reins_recoveries) * (policy_attrs['projection_steps']>0)

        reinsurance_results = {
            'reins_sum_assured': reins_sum_assured,
            'reins_premiums': reins_premiums,
            'reins_recoveries': reins_recoveries,
            'net_cf_with_reinsurance': net_cf_with_reinsurance,
        }

        return reinsurance_results

    def calculate_net_reserves(self, policy_attrs, rates, decrements, reinsurance_results):
        """
        Second backward pass - Calculate net reserves.
        """
        num_policies = policy_attrs['num_policies']
        num_months = policy_attrs['policy_months'].shape[1]

        net_cf_with_reinsurance = reinsurance_results['net_cf_with_reinsurance']
        lives_so_end = decrements['lives_so_end']
        maturities = decrements['maturities']

        monthly_interest_rates = rates['monthly_VROI_rates']

        # Reverse arrays for backward calculation
        net_cash_flows_rev = net_cf_with_reinsurance[:, ::-1]  # Shape: (num_policies, num_months)
        monthly_interest_rates_rev = monthly_interest_rates[::-1]  # Shape: (num_months,)

        # Function to discount cash flows for a single policy
        def discount_policy_cashflows(net_cash_flow_rev):
            def discount_step(carry, inputs):
                discount_rate, net_cf = inputs
                pv_next = carry
                pv = (pv_next + net_cf) / (1 + discount_rate)
                return pv, pv

            init_carry = 0.0

            _, discounted_net_cf_rev = lax.scan(
                discount_step,
                init_carry,
                (monthly_interest_rates_rev, net_cash_flow_rev)
            )

            return discounted_net_cf_rev

        # Apply the function to each policy
        discounted_net_cf_rev = jax.vmap(discount_policy_cashflows)(net_cash_flows_rev)

        # Reverse back to original order
        discounted_net_cf = discounted_net_cf_rev[:, ::-1]
    
        # Gross and Net Reserves Per Policy
        # Reserves per policy are the discounted net cashflows divided by lives at end
        if self.config.run_type in ['Valuation','CRNHR']:
            discounted_net_cf = jnp.concatenate([discounted_net_cf[:, 1:], jnp.zeros((discounted_net_cf.shape[0], 1))], axis=1)
        else:
            discounted_net_cf = jnp.concatenate([discounted_net_cf[:, 1:], jnp.zeros((discounted_net_cf.shape[0], 1))], axis=1) * (policy_attrs['projection_steps']>0)
        net_reserve_pp = discounted_net_cf / jnp.maximum(decrements['lives_so_end'] + decrements['maturities'], 1e-6)  # Shape: (num_policies, num_months)
        net_reserve_pp = jnp.maximum(net_reserve_pp, 0.0)  # Prevent negative 
        
        # discount_factors = jnp.cumprod(1 / (1 + monthly_interest_rates[::-1]))[::-1]

        # discounted_net_cf_with_reins = net_cf_with_reinsurance * discount_factors[None, :]
        # discounted_cf_with_reins_cumsum = jnp.cumsum(discounted_net_cf_with_reins[:, ::-1], axis=1)[:, ::-1]

        # net_reserve_pp = jnp.maximum(
        #     discounted_cf_with_reins_cumsum / (lives_so_end + maturities + 1e-8), 0.0
        # )

        net_reserves = {
            'discounted_cf_with_reins': discounted_net_cf,
            'net_reserve_pp': net_reserve_pp,
        }

        return net_reserves

    def calculate_be_layer(self, policy_attrs, rates, decrements, reinsurance_results, gross_reserve_pp, net_reserve_pp):
        """
        Third forward pass - BE Layer cashflows, reserves, solvency capital, and profit.
        """

        # Use the BE layer cashflows and decrements
        be_cashflows = self.calculate_cash_flows(
            policy_attrs,
            rates,
            decrements,
            reinsurance_results,
            layer='BE',
        )
        net_cf_without_reinsurance = -be_cashflows['net_cashflows']
        reinsurance_mortality_rates = rates['reinsurance_mortality_rates']
        reins_sum_assured = reinsurance_results['reins_sum_assured']

        # Reinsurance Premiums and Recoveries
        be_cashflows['reins_premiums'] = reinsurance_mortality_rates * reins_sum_assured * decrements['lives_so_begin'] * (policy_attrs['projection_steps']>0)
        be_cashflows['reins_recoveries'] = reins_sum_assured * decrements['deaths']

        be_cashflows['net_cashflows'] = (net_cf_without_reinsurance - be_cashflows['reins_premiums'] + be_cashflows['reins_recoveries']) * (policy_attrs['projection_steps']>0)

        # Reserves
        lives_so_end = decrements['lives_so_end']

        be_reserves = net_reserve_pp * (lives_so_end + decrements['maturities'])
        be_reserves = jnp.maximum(be_reserves, 0.0) * (policy_attrs['projection_steps']>0)

        # Increase in Reserves
        reserve_shifted = jnp.concatenate(
            [self.ZERO_ARRAY[:, [0]], be_reserves[:, :-1]], axis=1)
        increase_in_reserves = be_reserves - reserve_shifted
        increase_in_reserves = increase_in_reserves.at[:, 0].set(be_reserves[:, 0])

        # Interest on Reserve
        monthly_ROI_rates = rates['monthly_ROI_rates']
        interest_on_reserve = reserve_shifted * monthly_ROI_rates[None, :] * (policy_attrs['projection_steps']>0)
        interest_on_reserve = interest_on_reserve.at[:, 0].set(0.0)

        # Solvency Capital Calculations
        sum_assureds = policy_attrs['sum_assureds']
        Reinsurance_Retention_Limit = rates['Reinsurance_Retention_Limit']
        reins_sum_assured = reinsurance_results['reins_sum_assured']
        required_solvency_capital,gross_sar,net_sar, part1_sm, part2_sm = self.calculate_solvency_capital(
            policy_attrs, rates, decrements, be_reserves, gross_reserve_pp, net_reserve_pp, reins_sum_assured) 
        
        required_solvency_capital = required_solvency_capital.at[:, 0].set(0.0) 

        # Increase in Solvency Capital
        solvency_capital_shifted = jnp.concatenate(
            [self.ZERO_ARRAY[:, [0]], required_solvency_capital[:, :-1]], axis=1)
        increase_in_solvency_capital = required_solvency_capital - solvency_capital_shifted
        increase_in_solvency_capital = increase_in_solvency_capital.at[:, 0].set(required_solvency_capital[:, 0]) * (policy_attrs['projection_steps']>0)

        # Interest on Solvency Capital
        interest_on_solvency_capital = solvency_capital_shifted * monthly_ROI_rates[None, :]
        interest_on_solvency_capital = interest_on_solvency_capital.at[:, 0].set(0.0) * (policy_attrs['projection_steps']>0)

        # Profit Calculations
        profit_before_tax = be_cashflows['net_cashflows'] - increase_in_reserves + interest_on_reserve
        csr_rate = self.product_config.variables.get('CSR', 0.0)
        tax_rate = self.product_config.variables.get('Tax Rate', 0.0)
        csr = profit_before_tax * csr_rate * (policy_attrs['projection_steps']>0)
        tax = (profit_before_tax - csr) * tax_rate * (policy_attrs['projection_steps']>0)
        net_profit_before_sm = profit_before_tax - csr - tax

        # Net Profit After Solvency Margin
        cost_of_capital = increase_in_solvency_capital - interest_on_solvency_capital + \
                          (interest_on_solvency_capital * tax_rate) + (interest_on_solvency_capital * csr_rate) * (policy_attrs['projection_steps']>0)
        net_profit_after_sm = net_profit_before_sm - cost_of_capital

        be_results = {
            'be_premiums': be_cashflows['premiums'],
            'be_commissions': be_cashflows['commissions'],
            'be_initial_expense': be_cashflows['initial_expense'],
            'be_renewal_expenses': be_cashflows['renewal_expenses'],
            'be_claim_expenses': be_cashflows['claim_expenses'],
            'be_death_benefits': be_cashflows['death_benefits'],
            'be_surrender_benefits': be_cashflows['surrender_benefits'],
            'be_reinsurance_premiums': be_cashflows['reins_premiums'],
            'be_reinsurance_recoveries': be_cashflows['reins_recoveries'],
            'be_interest_on_cashflows': be_cashflows['interest_on_cashflows'],
            'be_net_cf': be_cashflows['net_cashflows'],
            'be_reserves': be_reserves,
            'increase_in_reserves': increase_in_reserves,
            'interest_on_reserves': interest_on_reserve,
            'part1_sm' : part1_sm,
            'part2_sm' : part2_sm,
            'gross_sar' : gross_sar,
            'net_sar' : net_sar,
            'required_solvency_capital': required_solvency_capital,
            'increase_in_solvency_capital': increase_in_solvency_capital,
            'interest_on_solvency_capital': interest_on_solvency_capital,
            'profit_before_tax': profit_before_tax,
            'csr': csr,
            'tax': tax,
            'net_profit_before_sm': net_profit_before_sm,
            'cost_of_capital': cost_of_capital,
            'net_profit_after_sm': net_profit_after_sm,
        }

        return be_results

    def calculate_solvency_capital(self, policy_attrs, rates, decrements, be_reserves, gross_reserve_pp, net_reserve_pp, reins_sum_assured):
        """
        Calculates solvency capital.

        Returns:
            required_solvency_capital: Solvency capital required at each time step.
        """
        sum_assureds = policy_attrs['sum_assureds']
        lives_so_end = decrements['lives_so_end']

        # Gross Sum at Risk
        gross_sar = (sum_assureds * lives_so_end -  be_reserves)

        # Net Sum at Risk
        net_sar = ((sum_assureds - reins_sum_assured) * lives_so_end - be_reserves)

        gross_sar = np.maximum(gross_sar, 0.0)
        net_sar = np.maximum(net_sar, 0.0)

        # Solvency Margin parameters
        Solvency_Margin_1_factor = float(self.product_config.variables.get('Part 1 SM', 0.0))
        Solvency_Margin_2_factor = float(self.product_config.variables.get('Part 2 SM', 0.0))
        Part1_net_to_gross_factor = float(self.product_config.variables.get('Part 1 net to gross factor', 1.0))
        Part2_net_to_gross_factor = float(self.product_config.variables.get('Part 2 net to gross factor', 1.0))
        Solvency_Ratio = float(self.product_config.variables.get('Solvency ratio', 1.0))

        # Part 1 SM
        net_to_gross_reserve_ratio = jnp.minimum(
            1.0,
            jnp.where(
                gross_reserve_pp != 0,
                net_reserve_pp / (gross_reserve_pp + 1e-6),
                1.0
            )
        )
        net_to_gross_reserve_ratio = jnp.minimum(jnp.maximum(net_to_gross_reserve_ratio, Part1_net_to_gross_factor), 1.0)
        part1_sm = be_reserves * Solvency_Margin_1_factor * net_to_gross_reserve_ratio * Solvency_Ratio

        # Part 2 SM

        non_zero_mask = gross_sar != 0
        net_to_gross_sar_ratio = jnp.minimum(1.0, jnp.where(non_zero_mask, net_sar / (gross_sar + 1e-6), 1))
        net_to_gross_sar_ratio = jnp.maximum(net_to_gross_sar_ratio, Part2_net_to_gross_factor)
        part2_sm_mask = (policy_attrs['policy_months'] < policy_attrs['policy_terms_months'][:, None])
        part2_sm = gross_sar * Solvency_Margin_2_factor * net_to_gross_sar_ratio * Solvency_Ratio * part2_sm_mask
        
        required_solvency_capital = (part1_sm + part2_sm) 
        required_solvency_capital = jnp.maximum(required_solvency_capital, 0.0)

        return required_solvency_capital, gross_sar, net_sar, part1_sm, part2_sm

    def calculate_pv_variables(self, policy_attrs, rates, be_results, reinsurance_results, decrements, batch_policy_numbers):
        """
        Third backward pass - Calculate MCEV, BEL, PVFP, and FCC.
        """
        num_policies = policy_attrs['num_policies']
        num_months = policy_attrs['policy_months'].shape[1]
        premiums = be_results['be_premiums']
        commissions = be_results['be_commissions']
        initial_expense = be_results['be_initial_expense']
        renewal_expenses = be_results['be_renewal_expenses']
        be_reserves = be_results['be_reserves']
        be_net_cf = be_results['be_net_cf']
        be_interest_on_cashflows = be_results['be_interest_on_cashflows']
        be_inc_in_reserves = be_results['increase_in_reserves']
        required_solvency_capital = be_results['required_solvency_capital']
        net_profit_before_sm = be_results['net_profit_before_sm']
        required_solvency_capital = be_results['required_solvency_capital']
        increase_in_solvency_capital = be_results['increase_in_solvency_capital']
        interest_on_solvency_capital = be_results['interest_on_solvency_capital']
        policy_months = policy_attrs['policy_months']

        monthly_CCIL_rates = rates['monthly_CCIL_rates']
        tax_rate = float(self.product_config.variables.get('Tax Rate', 0.0))
        csr_rate = float(self.product_config.variables.get('CSR', 0.0))

        interest_on_cashflows = (premiums - commissions - initial_expense - renewal_expenses - reinsurance_results['reins_premiums']) * monthly_CCIL_rates
        interest_on_cashflows = interest_on_cashflows * (policy_attrs['projection_steps'] > 0)

        reserve_shifted = jnp.concatenate(
            [self.ZERO_ARRAY[:, [0]], be_reserves[:, :-1]], axis=1)

        # Interest on Reserve
        interest_on_reserve = reserve_shifted * monthly_CCIL_rates[None, :] * (policy_attrs['projection_steps']>0)
        interest_on_reserve = interest_on_reserve.at[:, 0].set(0.0)

        net_cf = be_net_cf - be_interest_on_cashflows + interest_on_cashflows
        profit_before_tax = net_cf - be_inc_in_reserves + interest_on_reserve
        csr = profit_before_tax * csr_rate
        tax = (profit_before_tax-csr)*tax_rate
        net_profit = profit_before_tax - csr - tax

        # discount_factors = jnp.cumprod(1 / (1 + monthly_CCIL_rates[::-1]))[::-1]
        monthly_interest_rates_rev = monthly_CCIL_rates[::-1]  # Shape: (num_months,)

        def discount_policy_cashflows(cash_flow_rev):
            def discount_step(carry, inputs):
                discount_rate, net_cf = inputs
                pv_next = carry
                pv = (pv_next + net_cf) / (1 + discount_rate)
                return pv, pv

            init_carry = 0.0

            _, discounted_rev = lax.scan(
                discount_step,
                init_carry,
                (monthly_interest_rates_rev, cash_flow_rev)
            )

            return discounted_rev

        # PVFP
        net_profit_rev = net_profit[:, ::-1]  # Shape: (num_policies, num_months)
        disc_net_profit_rev = jax.vmap(discount_policy_cashflows)(net_profit_rev)
        disc_net_profit = disc_net_profit_rev[:, ::-1]
        pvfp = jnp.concatenate([disc_net_profit[:, 1:], jnp.zeros((disc_net_profit.shape[0], 1))], axis=1) * (policy_months>=0)

        # discounted_net_profit = net_profit_before_sm * discount_factors[None, :]
        # pvfp = jnp.cumsum(discounted_net_profit[:, ::-1], axis=1)[:, ::-1]

        # PV Premium
        def discount_premium_cashflows(cash_flow_rev):
            def discount_step(carry, inputs):
                discount_rate, net_cf = inputs
                pv_next = carry
                pv = net_cf + pv_next / (1 + discount_rate)
                return pv, pv

            init_carry = 0.0

            _, discounted_rev = lax.scan(
                discount_step,
                init_carry,
                (monthly_interest_rates_rev, cash_flow_rev)
            )

            return discounted_rev
        be_premiums = be_results['be_premiums']
        be_premiums_rev = be_premiums[:, ::-1]  # Shape: (num_policies, num_months)
        disc_be_premiums_rev = jax.vmap(discount_premium_cashflows)(be_premiums_rev)
        disc_be_premiums = disc_be_premiums_rev[:, ::-1]
        pv_premium = jnp.concatenate([disc_be_premiums[:, 1:], jnp.zeros((disc_be_premiums.shape[0], 1))], axis=1)* (policy_months>=0)
        
        # discounted_premiums = be_premiums * discount_factors[None, :]
        # pv_premium = jnp.cumsum(discounted_premiums[:, ::-1], axis=1)[:, ::-1]

        # BEL
        # be_net_cf = be_results['be_net_cf']
        net_cf_rev = net_cf[:, ::-1]  # Shape: (num_policies, num_months)
        disc_net_cf_rev= jax.vmap(discount_policy_cashflows)(net_cf_rev)
        disc_net_cf = disc_net_cf_rev[:, ::-1]
        bel = jnp.concatenate([disc_net_cf[:, 1:], jnp.zeros((disc_net_cf.shape[0], 1))], axis=1) * (policy_months>=0)
        bel_pp = -bel/(decrements['lives_so_end'] + decrements['maturities'])

        # IFRS BEL
        premium_amounts = policy_attrs['premium_amounts']
        sum_assureds = policy_attrs['sum_assureds']
        commission_rates = rates['commission_rates']
        ifrs_premiums = be_premiums
        deaths = decrements['deaths']
        ifrs_death_benefits = sum_assureds * deaths
        ifrs_surrender_benefits = jnp.zeros_like(ifrs_premiums)
        lives_so_end = decrements['lives_so_end']
        lives_so_begin = decrements['lives_so_begin']
        maturities = decrements['maturities']
        projection_steps = policy_attrs['projection_steps']

        # Instantiate the IFRS17 class and load the data
        ifrs17_init = IFRS17(self.config.table_index, self.config, self.product_name)
        ifrs17_init.load_data()

        starting_policy_month = policy_attrs['policy_months']
        
        valuation_month = self.config.valuation_date.month

        if valuation_month > 3:
            month_shift_locked_in = abs(valuation_month - 4)
        else:
            month_shift_locked_in = abs(valuation_month - 4 + 12)

        month_shift_current = abs(month_shift_locked_in - 13)

        # Access the IFRS ROI rates
        ifrs_current_rate_raw = ifrs17_init.get_monthly_rates('if17_Current_ROI')
        ifrs_current_rate = ifrs_current_rate_raw
        ifrs_current_rate = np.concatenate([ np.zeros(month_shift_current), ifrs_current_rate[:-(month_shift_current)] ])  
        ifrs_current_rate_array = np.tile(ifrs_current_rate, (num_policies, 1)) 
        
        ifrs_locked_in_rate_raw = ifrs17_init.get_monthly_rates('if17_Locked_in_Rate') 
        ifrs_locked_in_rate = ifrs_locked_in_rate_raw[month_shift_locked_in:]
        ifrs_locked_in_rate = np.concatenate([np.zeros(1), ifrs_locked_in_rate[:-1]])
        ifrs_locked_in_rate = np.concatenate([ ifrs_locked_in_rate, np.zeros(month_shift_locked_in)])
        ifrs_locked_in_rate_array = np.tile(ifrs_locked_in_rate, (num_policies, 1)) 
        

        ifrs_ccil_rate_raw = ifrs17_init.get_monthly_rates('if17_CCIL Fwd Rates')
        num_policies, projection_months = starting_policy_month.shape
        ifrs_ccil_rate_list = []

        indicator = (policy_months - 1) // 12 + 1

        for i in range(num_policies):
            # Take the first month for each policy (e.g. starting_policy_month[i, 0])
            start_month = int(starting_policy_month[i, 0])  # assuming all cols are same start for that policy

            # Start from start_month, shift by 1 (add 0 in front), remove last
            rate_slice = ifrs_ccil_rate_raw[start_month:]
            shifted = np.concatenate([np.zeros(1), rate_slice[:-1]])

            # Pad to match projection length
            if len(shifted) < projection_months:
                shifted = np.concatenate([shifted, np.zeros(projection_months - len(shifted))])
            elif len(shifted) > projection_months:
                shifted = shifted[:projection_months]

            # Add to list
            ifrs_ccil_rate_list.append(shifted)
        

        # Convert the list to a numpy array
        ifrs_ccil_rate = ifrs_ccil_rate_list[0]
        ifrs_ccil_rate_array = np.array(ifrs_ccil_rate_list)

        for policy_idx in range(num_policies):
            # DYNAMICALLY select the correct rate array for the CURRENT policy
            ifrs_ccil_rate = ifrs_ccil_rate_array[policy_idx]
            # Reverse the rates for the current policy
            ccil_discount_rates_rev = ifrs_ccil_rate[::-1]


        # Multiply the initial expense with the IFRS initial expense multiplier

        ifrs_initial_expenses = (be_results['be_initial_expense'] * ifrs17_init.ifrs17_multiplier_initial_expenses) + be_results['be_commissions']

        # Calculate the IFRS17 renewal expenses
        IFRS_Renewal_Fixed_expenses = ifrs17_init.get_renewal_expense_rates('Fixed expenses')
        IFRS17_Prem_expenses = ifrs17_init.get_renewal_expense_rates('% of Prem')
        IFRS17_Claim_expenses = ifrs17_init.get_renewal_expense_rates('Claim expenses')
        
        ifrs_renewal_fixed_expenses = IFRS_Renewal_Fixed_expenses
        # Shift ifrs_renewal_fixed_expenses down by 1 row
        ifrs_renewal_fixed_expenses = np.insert(ifrs_renewal_fixed_expenses[:-1], 0, 0.0)

        # Calculate the start month offset for each policy individually
        start_month_offsets = starting_policy_month[:, 0]  # Assuming starting_policy_month is a 2D array with shape (num_policies, num_months)
        premium_frequency = policy_attrs['premium_frequencies']

        # Adjust IFRS17_Prem_expenses for each policy based on its start month offset
        IFRS17_Prem_expenses = IFRS17_Prem_expenses.reshape(1, -1)
        adjusted_IFRS17_Prem_expenses = []
        for policy_idx, start_month_offset in enumerate(start_month_offsets):
            # Check if the premium frequency is 12 (annual)
            if premium_frequency[policy_idx, 0] >1:  # Assuming premium_frequency is a 2D array
                
                IFRS17_Prem_expenses_policy = IFRS17_Prem_expenses[:, start_month_offset - 1:]

                # Add padding to match the projection length
                padding_length = projection_months - IFRS17_Prem_expenses_policy.shape[1]
                if padding_length > 0:
                    padding = jnp.zeros((1, padding_length))
                    IFRS17_Prem_expenses_policy = jnp.concatenate([IFRS17_Prem_expenses_policy, padding], axis=1)
    
                if IFRS17_Prem_expenses_policy.ndim == 1:
                    IFRS17_Prem_expenses_policy = IFRS17_Prem_expenses_policy.reshape(1, -1) 
                
                last_value = 0

                # Iterate over the months in 12-month blocks
                for i in range(2, IFRS17_Prem_expenses_policy.shape[1], 12):  # Step by 12 months
                    # Find the first non-zero value in the current 12-month block
                    block_start = i
                    block_end = min(i + 12, IFRS17_Prem_expenses_policy.shape[1])  # Ensure we don't go out of bounds
                    block_values = IFRS17_Prem_expenses_policy[0, block_start:block_end]

                    # Check if there is any non-zero value in the block
                    non_zero_indices = jnp.where(block_values != 0)[0]
                    if len(non_zero_indices) > 0:
                        # Use the first non-zero value in the block
                        first_non_zero_value = block_values[non_zero_indices[0]]
                    else:
                        # If no non-zero value is found, use the last value from the previous block
                        first_non_zero_value = last_value

                    # Update the block with the repeated value
                    IFRS17_Prem_expenses_policy = IFRS17_Prem_expenses_policy.at[0, block_start:block_end].set(first_non_zero_value)

                    # Update the last_value for the next block
                    last_value = first_non_zero_value

            else:
                # Slice dynamically for the current policy
                IFRS17_Prem_expenses_policy = IFRS17_Prem_expenses[:, start_month_offset - 1:]
    
                # Add padding to match the projection length
                padding_length = projection_months - IFRS17_Prem_expenses_policy.shape[1]
                if padding_length > 0:
                    padding = jnp.zeros((1, padding_length))
                    IFRS17_Prem_expenses_policy = jnp.concatenate([IFRS17_Prem_expenses_policy, padding], axis=1)
    
            adjusted_IFRS17_Prem_expenses.append(IFRS17_Prem_expenses_policy)

        # Convert the list back to a single array
        adjusted_IFRS17_Prem_expenses = jnp.concatenate(adjusted_IFRS17_Prem_expenses, axis=0)


        ifrs_premiums_reshape = ifrs_premiums.reshape(-1, len(ifrs_renewal_fixed_expenses))  # Reshape with dynamic number of policies
        
        ifrs_renewal_prem_expenses = adjusted_IFRS17_Prem_expenses * ifrs_premiums_reshape
        
        combined_renewal_expenses = be_results['be_commissions'] + ifrs_renewal_fixed_expenses + ifrs_renewal_prem_expenses
        
         # Calculate claim expense
        ifrs_claim_expense = IFRS17_Claim_expenses * deaths

        #BEL Calculation (Gross of reinsurance and adjusted for I17 Expenses)
        # Calculate the BEL CF
        ifrs_bel_cf =  ifrs_death_benefits + ifrs_surrender_benefits + ifrs_initial_expenses + combined_renewal_expenses + ifrs_claim_expense - ifrs_premiums

        # Calculate BEL at Onerous Tagging Rate
        bel_at_onerous_tagging_rate = ifrs_bel_cf - ((ifrs_premiums - ifrs_initial_expenses - combined_renewal_expenses) * ifrs_ccil_rate)

         # Reverse arrays for backward calculation
        bel_at_onerous_tagging_rate_rev = bel_at_onerous_tagging_rate[:, ::-1]  # Shape: (num_policies, num_months)
        
        # Create an array to store reversed discount rates for all policies
        discount_rates_rev_array = np.zeros_like(ifrs_ccil_rate_array)

        # Populate the array with reversed rates for each policy
        for policy_idx in range(num_policies):
            ifrs_ccil_rate = ifrs_ccil_rate_array[policy_idx]
            discount_rates_rev_array[policy_idx] = ifrs_ccil_rate[::-1]

        # Function to discount cash flows for a single policy
        def discount_policy_cashflows(net_cash_flow_rev,discount_rates_rev):
            def discount_step(carry, inputs):
                discount_rate, net_cf = inputs
                pv_next = carry
                pv = (pv_next + net_cf) / (1 + discount_rate)
                return pv, pv

            init_carry = 0.0

            _, discounted_net_cf_rev = lax.scan(
                discount_step,
                init_carry,
                (discount_rates_rev, net_cash_flow_rev)
            )

            return discounted_net_cf_rev

        # Apply the function to each policy
        discounted_bel_at_onerous_tagging_rate_rev = jax.vmap(discount_policy_cashflows)(bel_at_onerous_tagging_rate_rev,discount_rates_rev_array)

        # Reverse back to original order
        discounted_bel_at_onerous_tagging_rate = discounted_bel_at_onerous_tagging_rate_rev[:, ::-1]

        # Shift the array by one row up
        discounted_bel_at_onerous_tagging_rate_shifted_up = discounted_bel_at_onerous_tagging_rate[:, 1:]

        discounted_bel_at_onerous_tagging_rate_shifted_up = np.hstack([discounted_bel_at_onerous_tagging_rate_shifted_up, np.zeros((discounted_bel_at_onerous_tagging_rate.shape[0], 1))])

        # Calculate BEL PP at Onerous tagging rate
        bel_pp_at_onerous_tagging_rate = discounted_bel_at_onerous_tagging_rate_shifted_up / (lives_so_end + maturities)
        
        # discounted_be_net_cf = be_net_cf * discount_factors[None, :]
        # bel = jnp.cumsum(discounted_be_net_cf[:, ::-1], axis=1)[:, ::-1]

        # Frictional Cost of Capital (FCC)
        required_solvency_capital_shifted = jnp.concatenate(
            [self.ZERO_ARRAY[:, [0]], required_solvency_capital[:, :-1]], axis=1)
        
        interest_on_sm = required_solvency_capital_shifted * monthly_CCIL_rates
        tax_on_int_on_sm = interest_on_sm * tax_rate
        csr_on_int_on_sm = interest_on_sm * csr_rate
        coc = increase_in_solvency_capital - interest_on_sm + tax_on_int_on_sm + csr_on_int_on_sm


        # interest_on_solvency_capital_mcev = required_solvency_capital * monthly_CCIL_rates[None, :]
        # tax_on_interest_sc_mcev = interest_on_solvency_capital_mcev * tax_rate
        # csr_on_interest_sc_mcev = interest_on_solvency_capital_mcev * csr_rate
        # cost_of_capital_mcev = increase_in_solvency_capital - interest_on_solvency_capital_mcev + \
        #                        tax_on_interest_sc_mcev + csr_on_interest_sc_mcev

        coc_rev = coc[:, ::-1]  # Shape: (num_policies, num_months)
        disc_coc_rev= jax.vmap(discount_policy_cashflows)(coc_rev,discount_rates_rev_array)
        disc_coc = disc_coc_rev[:, ::-1]
        fcc = jnp.concatenate([disc_coc[:, 1:], jnp.zeros((disc_coc.shape[0], 1))], axis=1)* (policy_months>=0)

        # discounted_coc_mcev = cost_of_capital_mcev * discount_factors[None, :]
        # fcc = jnp.cumsum(discounted_coc_mcev[:, ::-1], axis=1)[:, ::-1]

        # Calculate the PV of Expenses using Locked-In Rate
        combined_expenses_rev = combined_renewal_expenses[:, ::-1]  # Reverse for backward calculation
        discount_rates_locked_in_rev = ifrs_locked_in_rate[::-1]  # Reverse the locked-in rates

        # Function to discount expenses for a single policy
        def discount_expenses(expenses_rev):
            def discount_step(carry, inputs):
                discount_rate, expense = inputs
                pv_next = carry
                pv = (pv_next  / (1 + discount_rate)) + expense
                return pv, pv

            init_carry = 0.0

            _, discounted_expenses_rev = lax.scan(
                discount_step,
                init_carry,
                (discount_rates_locked_in_rev, expenses_rev)
            )

            return discounted_expenses_rev

        # Apply the function to each policy
        discounted_expenses_rev = jax.vmap(discount_expenses)(combined_expenses_rev)

        # Reverse back to original order
        discounted_expenses = discounted_expenses_rev[:, ::-1]

        discounted_expenses_shifted_up = discounted_expenses[:, 1:]

        discounted_expenses_shifted_up = np.hstack([discounted_expenses_shifted_up, np.zeros((discounted_expenses.shape[0], 1))])

        # Calculate adjusted px
        adj_px = lives_so_begin

        # Calculate the length of the arrays after flattening
        num_entries = policy_attrs['policy_months'].size  # Assuming policy_months is a 2D array

        # Repeat the batch_policy_numbers to match the number of entries
        policy_number_array = np.repeat(batch_policy_numbers, num_entries // len(batch_policy_numbers))
        policy_month_array = np.array(policy_attrs['policy_months']).flatten()[:num_entries]
        calendar_month_array = np.tile(policy_attrs['calendar_months'], len(batch_policy_numbers))[:num_entries]
        projection_steps = np.tile(policy_attrs['projection_steps'], len(batch_policy_numbers))[:num_entries]

        # Retrieve additional variables
        additional_variables = ifrs17_init.get_additional_variables()

        # Access v
        ifrs_v = additional_variables['IFRS17_V']
        ifrs_stress_v = additional_variables['IFRS17_Stress_V']

        # Calculate DF
        base_df = np.zeros(num_months)
        # Assuming policy_months is a range or list of month indices
        for i in list(range(1, num_months + 1)):
            if i < 3:
                base_df[i - 1] = 1
            else:
                base_df[i - 1] = ifrs_v ** (i - 1)

    
        stress_df = np.zeros(num_months)
        for i in list(range(1, num_months + 1)):
            if i < 3:
                stress_df[i - 1] = 1
            else:
                stress_df[i - 1] = ifrs_stress_v ** (i - 1)
        num_months   = self.projection_months
        
        # Build discount-factor arrays: shape (num_months,) for base & stress
        t_index     = jnp.arange(num_months)  # [0..num_months-1]
        df_base     = base_df
        df_stress   = stress_df

        # Function to compute the annuity-factor “vector” for one policy
        # e.g. a reversed cumulative sum of (adjusted_px * discount_factors).
        def annuity_factor_for_one_policy(px_for_policy: jnp.ndarray, df: jnp.ndarray) -> jnp.ndarray:
            rev_mult = px_for_policy[::-1] * df[::-1]      # shape (num_months,)
            rev_cumsum    = jnp.cumsum(rev_mult, axis=0) # partial sums in reverse
            partial_sums  = rev_cumsum[::-1]                  # shape (num_months,)

            return partial_sums / (df*px_for_policy )

        # Vectorize across all policies using jax.vmap
        annuity_factors_base_array = jax.vmap(lambda px: annuity_factor_for_one_policy(px, df_base))(adj_px)
        # ann_factors_base = jax.vmap(annuity_factor_for_one_policy(adjusted_px, df_base))

         # Access stress expense
        stress_expense = additional_variables['IFRS17_Stress_Expense']
        
        annuity_factors_stress_array = jax.vmap(lambda px: annuity_factor_for_one_policy(px, df_stress))(adj_px)
        annuity_factors_stress_array = annuity_factors_stress_array*stress_expense

        # Access extra inflation
        stress_inflation = additional_variables['IFRS17_Stress_Inflation']

        # Calculate extra inflation
        ifrs_stress_inflation = np.zeros(num_months)
        for i in list(range(1, num_months + 1)):
            if i < 3:
                ifrs_stress_inflation[i - 1] = 1
            else:
                ifrs_stress_inflation[i - 1] = (1 + stress_inflation) ** (i - 2)


        # Calculate stress expense
        #stress_expense = np.tile(stress_expense, num_entries)
        stress_expense = np.full(policy_months.shape, stress_expense)
        
        ifrs_stress_expense = ifrs_renewal_fixed_expenses + ifrs_renewal_prem_expenses*stress_expense*ifrs_stress_inflation

        # Calculate the PV of Stress Expenses using Locked-In Rate
        ifrs_stress_expense_rev = ifrs_stress_expense[:, ::-1]  # Reverse for backward calculation
        discount_rates_locked_in_rev = ifrs_locked_in_rate[::-1]  # Reverse the locked-in rates

        # Function to discount expenses for a single policy
        def discount_expenses(stress_expenses_rev):
            def discount_step(carry, inputs):
                discount_rate, expense = inputs
                pv_next = carry
                pv = pv_next / (1 + discount_rate) + expense
                return pv, pv

            init_carry = 0.0

            _, discounted_stress_expenses_rev = lax.scan(
                discount_step,
                init_carry,
                (discount_rates_locked_in_rev, stress_expenses_rev)
            )

            return discounted_stress_expenses_rev

        # Apply the function to each policy
        discounted_stress_expenses_rev = jax.vmap(discount_expenses)(ifrs_stress_expense_rev)

        # Reverse back to original order
        discounted_stress_expenses = discounted_stress_expenses_rev[:, ::-1]

        discounted_stress_expenses_shifted_up = discounted_stress_expenses[:, 1:]

        discounted_stress_expenses_shifted_up = np.hstack([discounted_stress_expenses_shifted_up, np.zeros((discounted_stress_expenses.shape[0], 1))])

        # Calculate Expense Capital
        ifrs_expense_captial = discounted_stress_expenses_shifted_up - discounted_expenses_shifted_up
        
        pv_results = {
            'interest_on_cashflows':interest_on_cashflows,
            'interest_on_reserve':interest_on_reserve,
            'net_cf':net_cf,    
            'profit_before_tax':profit_before_tax,
            'csr':csr,
            'tax':tax,
            'net_profit':net_profit,
            'pvfp': pvfp,
            'pv_premium': pv_premium,
            'interest_on_sm':interest_on_sm,
            'tax_interest_on_sm': tax_on_int_on_sm,
            'csr_interest_on_sm': csr_on_int_on_sm,
            'coc':coc,
            'fcc': fcc,
            'bel': bel,
            'bel_pp':bel_pp,
            'ifrs_bel': discounted_bel_at_onerous_tagging_rate_shifted_up,
            'ifrs_bel_pp': bel_pp_at_onerous_tagging_rate,
            'ifrs_expense_capital': ifrs_expense_captial,
        }
        return pv_results