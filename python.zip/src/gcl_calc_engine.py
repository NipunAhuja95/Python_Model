# gcl_calc_engine.py

import jax
import jax.numpy as jnp
from jax import lax
import numpy as np
from typing import Dict, Any
from src.base_calc_engine import CalculationEngine
from src.assumptions import IFRS17
from src.jax_config import FLOAT_DTYPE, INT_DTYPE

class GroupCreditLifeCalculationEngine(CalculationEngine):
    """
    Performs calculations for the Group Credit Life product.
    """

    ZERO_ARRAY = None  # Will be initialized in the prepare_policy_data method

    def run_batch(self, batch_policy_data: Dict[str, jnp.ndarray], batch_policy_numbers: Any):
        """
        Performs calculations for a single batch of group credit life policies.
        """
        # Prepare policy data
        policy_attrs = self.prepare_policy_data(batch_policy_data)

        # Initialize zero array
        self.ZERO_ARRAY = jnp.zeros((policy_attrs['num_policies'], self.projection_months), dtype=FLOAT_DTYPE)

        # Compute rates
        rates = self.compute_rates(policy_attrs)

        # 1st forward pass: Reserving Decrements and Reserving Cashflows (Gross)
        decrements_reserving = self.calculate_decrements(policy_attrs, rates, layer='Reserving')
        reinsurance_results= None
        gross_cf_reserving = self.calculate_cash_flows(policy_attrs, rates, decrements_reserving, reinsurance_results, layer='Reserving')

        # 1st backward pass: Discounted CF for Reserving + Gross Reserve PP
        gross_reserves = self.calculate_discounted_cf_reserves(policy_attrs, rates, decrements_reserving, gross_cf_reserving)

        # 2nd forward pass: Reinsurance Cashflows (Reserving layer)
        reinsurance_results = self.calculate_reinsurance_cash_flows(policy_attrs, rates, decrements_reserving, gross_reserves, layer='Reserving')

        # 2nd backward pass: Net Reserves (Reserving)
        net_reserves = self.calculate_net_reserves(policy_attrs, rates, decrements_reserving, reinsurance_results, gross_cf_reserving, gross_reserves, layer='Reserving')

        # 3rd forward pass: BE Decrements and BE Cashflows (including reinsurance)
        decrements_BE = self.calculate_decrements(policy_attrs, rates, layer='BE')
        reinsurance_results_BE = self.calculate_reinsurance_cash_flows(policy_attrs, rates, decrements_BE, gross_reserves, layer='BE')

        be_results = self.calculate_be_layer(policy_attrs, rates, decrements_BE, reinsurance_results_BE, gross_reserves['gross_reserve_pp'], net_reserves['net_reserve_pp'])

        # Third backward pass - Calculate MCEV, BEL, PVFP, and FCC
        pv_results = self.calculate_pv_variables(policy_attrs, rates, be_results, reinsurance_results_BE, decrements_BE, batch_policy_numbers=batch_policy_numbers)

        results_dict = {
            'policy_attrs': policy_attrs,
            'rates': rates,
            'gross_cf_reserving': gross_cf_reserving,
            'gross_reserves': gross_reserves,
            'reinsurance_results': reinsurance_results,
            'net_reserves': net_reserves,
            'decrements_reserving': decrements_reserving,
            'decrements_BE': decrements_BE,
            'reinsurance_results_BE': reinsurance_results_BE,
            'be_results': be_results,
            'pv_results': pv_results
        }

        return results_dict        
    
    def create_output_df(self, batch_policy_numbers, results_dict: Dict[str, Any]):
        """Create output dataframes"""

        policy_attrs = results_dict['policy_attrs']
        rates = results_dict['rates']
        gross_cf_reserving = results_dict['gross_cf_reserving']
        gross_reserves = results_dict['gross_reserves']
        reinsurance_results = results_dict['reinsurance_results']
        net_reserves = results_dict['net_reserves']
        decrements_reserving = results_dict['decrements_reserving']
        decrements_BE = results_dict['decrements_BE']
        reinsurance_results_BE = results_dict['reinsurance_results_BE']
        be_results = results_dict['be_results']
        pv_results = results_dict['pv_results']

        # Prepare data for output
        projection_steps = policy_attrs['projection_steps']
        combined_data = {
            'Policy_Number': np.repeat(batch_policy_numbers, projection_steps.size),
            'Policy_Month': np.array(policy_attrs['policy_months']).reshape(-1),
            'Calendar_Month': np.tile(policy_attrs['calendar_months'], len(batch_policy_numbers)),
            'Projection_Step': np.tile(np.arange(projection_steps.size), len(batch_policy_numbers)),
            'Modal_Factor': np.array(rates['modal_factor']).reshape(-1),
        }

        # Add reserving decrements with suffix
        for key, value in decrements_reserving.items():
            combined_data[f"decrements_{key}_reserving"] = np.array(value).flatten()

        # Add BE decrements with suffix
        for key, value in decrements_BE.items():
            combined_data[f"decrements_{key}_be"] = np.array(value).flatten()

        # Add BE cashflows with suffix
        for key, value in gross_cf_reserving.items():
            combined_data[f"cashflows_{key}_reserving"] = np.array(value).flatten()

        # Add Reserving decrements with suffix
        for key, value in gross_reserves.items():
            combined_data[f"cashflows_{key}_reserving"] = np.array(value).flatten()

        # Add Reserving cashflows with suffix
        for key, value in reinsurance_results.items():
            combined_data[f"cashflows_{key}_reserving"] = np.array(value).flatten()

        # Add reserves
        for key, value in net_reserves.items():
            combined_data[f"cashflows_{key}_reserving"]  = np.array(value).flatten()

        # Add reins BE CFs with suffix
        for key, value in reinsurance_results_BE.items():
            combined_data[f"cashflows_{key}_BE"]  = np.array(value).flatten()

        # Add solvency capital calculations
        for key, value in be_results.items():
            combined_data[f"cashflows_{key}_BE"]  = np.array(value).flatten()

        # Add profit calculations
        for key, value in pv_results.items():
            combined_data[f"MCEV_{key}_BE"]  = np.array(value).flatten()

        # Store combined results
        return combined_data
    
    def create_bplan_output_df(self, batch_policy_numbers, results_dict: Dict[str, Any], sales_key):
        """Create output dataframes"""

        policy_attrs = results_dict['policy_attrs']
        be_results = results_dict['be_results']
        pv_results = results_dict['pv_results']

        # Prepare data for output
        projection_steps = policy_attrs['projection_steps']
        combined_data = {
            'Policy_Number': np.repeat(batch_policy_numbers, projection_steps.size/len(batch_policy_numbers)),
            'Sales_Key': np.repeat(sales_key, projection_steps.size/len(batch_policy_numbers)),
            'Policy_Month': np.array(policy_attrs['policy_months']).reshape(-1),
            'Calendar_Month': np.tile(policy_attrs['calendar_months'], len(batch_policy_numbers)),
            'Financial_Year': np.tile(policy_attrs['fy'], len(batch_policy_numbers)),
            'Projection_Step': np.array(projection_steps).reshape(-1),
            'Number_of_policies': np.array(policy_attrs['no_of_pol']).reshape(-1)
        }

        # Add BE cashflow calculations
        be_results_keys_remove = ['be_reinsurance_recoveries','be_net_cf', 'be_reserves',
                                  'part1_sm', 'part2_sm','gross_sar', 'net_sar','increase_in_solvency_capital', 'interest_on_solvency_capital',
                                  'profit_before_tax', 'csr', 'tax', 'net_profit_before_sm','cost_of_capital', 'net_profit_after_sm']
        be_results_filtered = {key: value for key, value in be_results.items() if key not in be_results_keys_remove}
        for key, value in be_results_filtered.items():
            combined_data[f"{key}"]  = np.array(value).flatten()

        # Add PV calculations
        pv_results_keys_remove = ['interest_on_cashflows', 'interest_on_reserve', 'net_cf', 'profit_before_tax', 'csr', 'tax', 'net_profit', 'pvfp', 
                                  'pv_premium', 'interest_on_sm', 'tax_interest_on_sm', 'csr_interest_on_sm', 'coc', 'fcc', 'bel', 'bel_pp']
        pv_results_filtered = {key: value for key, value in pv_results.items() if key not in pv_results_keys_remove}
        for key, value in pv_results_filtered.items():
            combined_data[f"MCEV_{key}_BE"]  = np.array(value).flatten()

        # Store combined results
        return combined_data

    def prepare_policy_data(self, batch_policy_data: Dict[str, jnp.ndarray]) -> Dict[str, Any]:
        """
        Prepares and expands policy data for GCL calculations.
        """
        num_policies = batch_policy_data['Policy_Term'].shape[0]
        time_vector = jnp.arange(self.projection_months)
        policy_terms_months = (batch_policy_data['Policy_Term'] * 12).astype(INT_DTYPE)
        duration_in_months = batch_policy_data['Duration_in_Months']  # from policy data

        # Policy months
        policy_months = duration_in_months[:, None] + time_vector[None, :]

        # Policy Masks
        policy_masks = (policy_months <= policy_terms_months[:, None]) * (policy_months>0)

        # Policy Years
        policy_years = ((policy_months - 1) // 12) + 1

        # Ages
        ages = batch_policy_data['Age_at_Policy_Start'][:, None] + ((policy_months - 1)//12)

        # Genders
        genders = batch_policy_data['Gender_Code'][:, None]
        genders = jnp.tile(genders, (1, self.projection_months))

        # Smoker
        smoker_status = batch_policy_data['Smoking_Status_Code'][:, None]
        smoker_status = jnp.tile(smoker_status, (1, self.projection_months))


        # Mortality flat flag
        mortality_flat_flag = batch_policy_data['Mortality_Flag'][:, None]  # New field from policy data
        mortality_flat_flag = jnp.tile(mortality_flat_flag, (1, self.projection_months))

        # Loan Amount, EMI, Interest Rate, Moratorium Months, Interest Accrue Switch, Reducing SA flag
        loan_amount = batch_policy_data['Loan_Amount']  # scalar per policy
        emi = batch_policy_data['EMI_amount']
        interest_rate = batch_policy_data['Interest_Rate']
        moratorium = batch_policy_data['Moratorium_Period_ind']
        interest_accrue = batch_policy_data['Interest_Accrue']  # 0 or 1 from policy data
        reducing_sa_flag = batch_policy_data['Reducing_SA'] # 0 or 1
        loan_os = batch_policy_data['loan_os']

        # For sum assured calculation:
        # If Reducing_SA=1, sum assured changes monthly based on loan amortization:
        # Sum Assured(t) = max(0, previous_month_sum_assured*(1+interest_rate/12*interest_accrue)-EMI*(moratorium=0 else 0) )
        # If moratorium>0, no EMI is deducted until moratorium ends. If moratorium=0, EMI paid every month from start
        # We assume we have to compute a loan schedule:
        # Initialize sum_assureds array:
        sum_assureds = jnp.zeros((num_policies, self.projection_months), dtype=FLOAT_DTYPE)
        # first month sum assured = loan_amount
        #sum_assureds = sum_assureds.at[:,0].set(loan_os)
        sum_assureds = sum_assureds.at[:,0].set(loan_amount)

        def update_sa(carry, x):
            # x = month index
            sa_prev = carry
            # If current month <= moratorium, no EMI is deducted and interest accrues if interest_accrue=1
            # sum_assured_t = sa_prev*(1+interest_rate/12*interest_accrue) - EMI*(0 if within moratorium else 1)
            # If Reducing_SA=0, sum assured stays constant = loan_amount
            # If Reducing_SA=1, apply formula
            interest_factor = (1 + interest_rate[:,None]/12 * interest_accrue[:,None])
            # If month index < moratorium, no EMI deduction
            pay_emi = (x >= moratorium[:,None]).astype(FLOAT_DTYPE)
            new_sa = jnp.where(reducing_sa_flag[:,None]==1,
                               sa_prev*interest_factor - emi[:,None]*pay_emi,
                               loan_amount[:,None]) 
            new_sa = jnp.clip(new_sa, a_min=0.0, a_max=None)
            return new_sa, new_sa

        # scan to fill sum_assureds for t>0
        _, sa_out = lax.scan(update_sa, sum_assureds[:,[0]], jnp.arange(1, self.projection_months))
        # sa_out shape: (projection_months-1, num_policies,1)
        sa_out = sa_out.swapaxes(0,1)[:,:,0] # rearrange to (num_policies, projection_months-1)
        sum_assureds = sum_assureds.at[:,1:].set(sa_out)
        sum_assureds = jnp.pad(sum_assureds[:, :-1], ((0, 0), (1, 0)), constant_values=0.0)

        # Premium: single premium at start:
        premium = batch_policy_data['Premium']  # single premium from policy data
        premium_amounts = jnp.tile(premium[:,None], (1,self.projection_months))

        # Premium Frequency = from product spec is single pay for GCL or monthly (Mode field)
        # The code states: If PPT=1 year, and mode=1=annual or 12=monthly
        freq = batch_policy_data['Mode']  # from policy data
        # If mode=1 => single pay at inception
        # If mode=12 => monthly
        # If mode=1 or else, initial code is ambiguous. Let's just store freq:
        premium_frequencies = jnp.tile(freq[:,None], (1,self.projection_months))

        # Distribution channel (assume =1 always if not given)
        # Provided in data, use as is:
        distribution_channels = batch_policy_data['Distribution_Channel'][:, None]
        distribution_channels = jnp.tile(distribution_channels, (1,self.projection_months))

        # Calendar month based on valuation month
        valuation_month = self.config.valuation_date.month
        calendar_months = ((valuation_month -1) + time_vector) % 12 +1
        financial_year_ind = jnp.arange(valuation_month, self.projection_months+valuation_month) 

        def financial_year(ind,year):
            fy = []
            for i in ind:
                if i % 12==0:
                    financial_year = (int(i/12)-1) + year
                else:
                    financial_year = int(i/12) + year
                fy.append(financial_year)
            return fy
        
        fy = financial_year(financial_year_ind, self.config.valuation_date.year)

        # Projection Steps:
        if self.config.run_type =='BusinessPlanning':
            projection_steps = policy_months  # Shape: (num_months,)
            no_of_pol = batch_policy_data['no_of_pol'][:, None]  # Shape: (num_policies, 1)
            no_of_pol = jnp.tile(no_of_pol, (1, self.projection_months))
        else:
            projection_steps = time_vector

        product_config_val = lambda var: float(self.product_config.variables.get(var,0.0))
        max_upr_term = product_config_val('Max term for which UPR to be held (months)')

        policy_attrs = {
            'num_policies': num_policies,
            'time_vector': time_vector,
            'policy_masks': policy_masks,
            'policy_terms_months': policy_terms_months,
            'policy_months': policy_months,
            'policy_years': policy_years,
            'ages': ages,
            'genders': genders,
            'smoker_status': smoker_status,
            'mortality_flat_flag': mortality_flat_flag,
            'sum_assureds': sum_assureds,
            'premium_amounts': premium_amounts,
            'premium_frequencies': premium_frequencies,
            'distribution_channels': distribution_channels,
            'calendar_months': calendar_months,
            'fy': fy,  # Shape: (num_months,)
            'projection_steps': projection_steps,
            'loan_amount': loan_amount,
            'emi': emi,
            'interest_rate': interest_rate,
            'moratorium': moratorium,
            'interest_accrue': interest_accrue,
            'reducing_sa_flag': reducing_sa_flag,
            'max_upr_term': max_upr_term
        }

        if self.config.run_type =='BusinessPlanning':
            bplan_fields = {
            'no_of_pol':no_of_pol,
            }
            policy_attrs.update(bplan_fields)

        return policy_attrs

    def compute_rates(self, policy_attrs: Dict[str, Any]) -> Dict[str, Any]:
        """
        Compute all monthly rates and expense loadings as per instructions.
        """

        ages = policy_attrs['ages']
        genders = policy_attrs['genders']
        smoker_status = policy_attrs['smoker_status']
        mortality_flat_flag = policy_attrs['mortality_flat_flag']
        policy_years = policy_attrs['policy_years']
        distribution_channels = policy_attrs['distribution_channels']
        policy_months = policy_attrs['policy_months']  # Shape: (num_policies, num_months)

        # Get MAD factors and others
        MAD_Mortality = float(self.product_config.variables.get('MAD_Mortality',0.0))
        MAD_Lapse = float(self.product_config.variables.get('MAD_Lapse',0.0))
        MAD_Expense = float(self.product_config.variables.get('MAD_Expense',0.0))
        Inflation_Factor = float(self.product_config.variables.get('Inflation',0.0))

        # Mortality rates:
        # If mortality_flat_flag=0 => use flat monthly mortality rate:
        # For Reserving layer: monthly mortality = 1 - (1-0.0022)^(1/12)
        # For BE layer: monthly mortality = 1-(1-0.002)^(1/12)
        # If mortality_flat_flag=1 => use GCL mortality support * IALM approach from assumptions
        be_mort_rate_annual = jnp.where(mortality_flat_flag==0, 0.002, self.assumptions['mortality'].get_annual_rate_gcl(ages,genders,smoker_status,basis='BE'))
        reserving_mort_rate_annual = jnp.where(mortality_flat_flag==0,0.0022,self.assumptions['mortality'].get_annual_rate_gcl(ages,genders,smoker_status,basis='Reserving'))

        monthly_mortality_rates_BE = 1-(1-be_mort_rate_annual)**(1/12) * (policy_months>0)
        monthly_mortality_rates_reserving = 1-(1-reserving_mort_rate_annual)**(1/12)

        # Lapse rates:
        lapse_rates_base_annual = self.assumptions['persistency'].get_annual_lapse_rate_vectorized(policy_years, distribution_channels)
        # For BE: lapse_rate = lapse_rates_base_annual * ... (From instructions: monthly = just convert annual to monthly)
        # We have no special factor for BE except maybe *0.5 from instructions given above
        lapse_rates_BE_annual = lapse_rates_base_annual
        lapse_rates_reserving_annual = (1+MAD_Lapse)*lapse_rates_BE_annual
        monthly_lapse_rates_BE = 1-(1-lapse_rates_BE_annual)**(1/12)
        monthly_lapse_rates_reserving = 1-(1-lapse_rates_reserving_annual)**(1/12)

        # Commission rates:
        commission_rates = self.assumptions['commissions'].get_commission_rate_vectorized(policy_years, distribution_channels)
        pay_prem = jnp.where((policy_attrs['policy_months']==1),1,0)
        commission_rates = commission_rates * pay_prem
        # Expenses:
        # Initial expenses from GCL expense table
        # Need sum assured at inception for interpolation:
        sa_inception = policy_attrs['sum_assureds'][:,0]
        init_exp = self.assumptions['expense'].get_initial_expense_rates(sa_inception[:,None])
        init_fixed_expense_rate = init_exp['Fixed']
        init_percent_prem_expense_rate = init_exp['% of Prem']
        init_percent_sa_expense_rate = init_exp['% of SA']

        # Renewal expenses:
        renewal_expenses = self.assumptions['expense'].get_renewal_expense_rates()
        fixed_expense_rate_annual = renewal_expenses.get('Fixed expenses',0.0)
        claim_expense_rate = renewal_expenses.get('Claim expenses',0.0)/100.0
        percent_prem_expense_rate_annual = renewal_expenses.get('% of Prem',0.0)
        # monthly
        fixed_expense_rate = fixed_expense_rate_annual/12
        percent_prem_expense_rate = percent_prem_expense_rate_annual/12

        # Interest Rates:
        monthly_ROI_rates = self.assumptions['interest_rate'].get_monthly_rates('ROI')
        monthly_VROI_rates_raw = self.assumptions['interest_rate'].get_monthly_rates('VROI')
        monthly_VROI_rates = np.zeros_like(monthly_VROI_rates_raw)
        monthly_VROI_rates[1:] = monthly_VROI_rates_raw[:-1]
        monthly_CCIL_rates_raw = self.assumptions['interest_rate'].get_monthly_rates('CCIL')  # For MCEV calculations
        monthly_CCIL_rates = np.zeros_like(monthly_CCIL_rates_raw)
        monthly_CCIL_rates[1:] = monthly_CCIL_rates_raw[:-1]

        # Reinsurance mortality (monthly):
        # For GCL reinsurance:
        reinsurance_mort_rates_annual = self.assumptions['reinsurance_mortality'].get_annual_rate_vectorized(ages,genders) 
        monthly_reins_mort = 1-(1-reinsurance_mort_rates_annual)**(1/12) * (policy_months>0)

        # Reinsurance retention limit abs, proportion from product self.config:
        reins_ret_limit_abs = float(self.product_config.variables.get('Reinsurance Retention Limit abs',1500000))
        reins_ret_limit_prop = float(self.product_config.variables.get('Reinsurance Retention Limit proportion',1))

        # SAR factors
        part1_net_gross_factor = float(self.product_config.variables.get('Part 1 net to gross factor',1.0))
        part2_net_gross_factor = float(self.product_config.variables.get('Part 2 net to gross factor',1.0))
        solvency_ratio = float(self.product_config.variables.get('Solvency ratio',1.0))
        part1_sm = float(self.product_config.variables.get('Part 1 SM',0.0))
        part2_sm = float(self.product_config.variables.get('Part 2 SM',0.0))
        tax_rate = float(self.product_config.variables.get('Tax Rate',0.0))
        csr_rate = float(self.product_config.variables.get('CSR',0.0))
        cost_of_capital_charge = float(self.product_config.variables.get('Cost of Capital Charge',0.04))
        modal_factor = jnp.zeros((policy_attrs['num_policies'], self.projection_months), dtype=FLOAT_DTYPE)
        modal_factor = 1 + modal_factor


        rates = {
            'monthly_mortality_rates_BE': monthly_mortality_rates_BE,
            'monthly_mortality_rates_reserving': monthly_mortality_rates_reserving,
            'monthly_lapse_rates_BE': monthly_lapse_rates_BE,
            'monthly_lapse_rates_reserving': monthly_lapse_rates_reserving,
            'commission_rates': commission_rates,
            'fixed_expense_rate': fixed_expense_rate,
            'percent_prem_expense_rate': percent_prem_expense_rate,
            'claim_expense_rate': claim_expense_rate,
            'MAD_Expense': MAD_Expense,
            'Inflation_Factor': Inflation_Factor,
            'monthly_ROI_rates': monthly_ROI_rates,
            'monthly_VROI_rates': monthly_VROI_rates,
            'monthly_CCIL_rates': monthly_CCIL_rates,
            'init_fixed_expense_rate': init_fixed_expense_rate,
            'init_percent_prem_expense_rate': init_percent_prem_expense_rate,
            'init_percent_sa_expense_rate': init_percent_sa_expense_rate,
            'monthly_reins_mort': monthly_reins_mort,
            'reinsurance_mortality_rates': monthly_reins_mort,
            'reins_ret_limit_abs': reins_ret_limit_abs,
            'reins_ret_limit_prop': reins_ret_limit_prop,
            'part1_net_gross_factor': part1_net_gross_factor,
            'part2_net_gross_factor': part2_net_gross_factor,
            'solvency_ratio': solvency_ratio,
            'part1_sm': part1_sm,
            'part2_sm': part2_sm,
            'tax_rate': tax_rate,
            'csr_rate': csr_rate,
            'cost_of_capital_charge': cost_of_capital_charge,
            'modal_factor':modal_factor
        }

        return rates

    def calculate_decrements(self, policy_attrs: Dict[str, Any], rates: Dict[str,Any], layer:str)->Dict[str,jnp.ndarray]:
        """
        Calculate decrements: Already done in previous code snippet, just re-use
        """
        num_policies = policy_attrs['num_policies']
        policy_months = policy_attrs['policy_months']
        policy_terms_months = policy_attrs['policy_terms_months']

        if layer=='BE':
            mort = rates['monthly_mortality_rates_BE']
            lapse = rates['monthly_lapse_rates_BE']
        else:
            mort = rates['monthly_mortality_rates_reserving']
            lapse = rates['monthly_lapse_rates_reserving']

        if self.config.run_type=='BusinessPlanning':
            time_mask = (policy_attrs['projection_steps']>0).astype(FLOAT_DTYPE)
        else:
            time_mask = (policy_attrs['time_vector'][None,:]>0).astype(FLOAT_DTYPE)
        mort = mort*time_mask
        lapse = lapse*time_mask

        maturities = jnp.where(policy_months == (policy_terms_months[:,None]),1.0,0.0)

        inputs = (mort.T,lapse.T,maturities.T)
        init_carry = jnp.ones(num_policies,dtype=FLOAT_DTYPE)
        def step(carry,inp):
            lives_prev=carry
            mr,lr,mat=inp
            deaths = lives_prev*mr
            total_rate = mr+lr
            lapses=(lives_prev-deaths)*lr
            lapses = jnp.where(total_rate>0,lapses,0.0)
            maturity_acts=(lives_prev-deaths-lapses)*mat
            lives_end=lives_prev - deaths - lapses -maturity_acts
            lives_end=jnp.maximum(lives_end,0.0)
            return lives_end,(lives_prev,deaths,lapses,maturity_acts,lives_end)

        _,outs=lax.scan(step,init_carry,inputs)
        lives_so_begin=outs[0].T
        deaths=outs[1].T
        lapses=outs[2].T
        maturities_actual=outs[3].T
        lives_so_end=outs[4].T

        return {
            'lives_so_begin': lives_so_begin,
            'deaths': deaths,
            'lapses': lapses,
            'maturities': maturities_actual,
            'lives_so_end': lives_so_end
        }

    def calculate_cash_flows(self, policy_attrs: Dict[str,Any], rates:Dict[str,Any], decrements:Dict[str,jnp.ndarray], reinsurance_results, layer:str)->Dict[str,jnp.ndarray]:
        """
        Calculate PP Cashflows for given layer (Reserving or BE)
        Follow instructions.
        """

        # Extract
        lives_so_begin = decrements['lives_so_begin']
        deaths = decrements['deaths']
        lapses = decrements['lapses']
        maturities = decrements['maturities']
        # If layer=Reserving or BE:
        # Premium paid only in first year at premium frequency:
        # If mode=1 => single premium at start month=1
        # If mode=12 => monthly premium for first 12 months?
        # so if projection step <=12 and mode=12 => monthly premium, else no premium
        premium_amounts = policy_attrs['premium_amounts'] 
        premium_freq = policy_attrs['premium_frequencies']
        # If freq=1 => entire premium in month 1
        # If freq=12 => premium each month for first 12 months
        if self.config.run_type == 'BusinessPlanning':
            month_idx = policy_attrs['projection_steps']
        else:
            month_idx = policy_attrs['projection_steps'][None,:]
        pay_prem = jnp.where((premium_freq==1)&(policy_attrs['policy_months']==1),1,0)
                            #  jnp.where((premium_freq==12)&(month_idx<12),1,0))

        premiums = premium_amounts * pay_prem * lives_so_begin

        commissions = premiums * rates['commission_rates'] # Actually commissions paid when premium paid
        
        # Initial Expense: only in first month:
        init_exp_policy = (rates['init_fixed_expense_rate'] 
            + rates['init_percent_prem_expense_rate'] * premium_amounts[:,1] 
            + rates['init_percent_sa_expense_rate'] * policy_attrs['sum_assureds'][:, 1])
        initial_expense = init_exp_policy[:,None] * lives_so_begin * (policy_attrs['policy_months'] == 1)

        # Renewal Expense:
        # Renewal expense = (fixed_expense_rate + percent_prem_expense_rate*0) * (1+Inflation)^(policy_years-1)*(1+MAD_Expense)*IFSM
        # If layer='Reserving', add MAD_Expense, if layer='BE', no MAD_Expense added?
        mad_exp = rates['MAD_Expense'] if layer=='Reserving' else 0.0
        infl_factor = (1 + rates['Inflation_Factor']) ** ((policy_attrs['projection_steps'] - 1)/12) 
        renewal_expenses = ((rates['fixed_expense_rate'] 
                             + (rates['percent_prem_expense_rate']*0)) * infl_factor 
                             * (1+mad_exp)) * lives_so_begin * (policy_attrs['policy_months'] > 1)

        # Claim expense:
        claim_expenses = (policy_attrs['sum_assureds'] * rates['claim_expense_rate'])*deaths

        # Death Benefit:
        # If current month>policy_term => DB=0 else DB=sum_assured(t)*deaths
        # sum_assured(t) from policy_attrs
        # If current month > policy_terms_month => no coverage:
        in_coverage = (policy_attrs['policy_months'] <= policy_attrs['policy_terms_months'][:,None]).astype(FLOAT_DTYPE)
        death_benefit = (policy_attrs['sum_assureds']*in_coverage)*deaths

        # Surrender Benefits:
        # Surrender Value =0.5*premiums_collected*(unexpired_term/total_term)*min(current_SA/initial_SA,1)
        # premiums_collected till current month for single pay or monthly pay = sum of previous premium?
        # For simplicity, if freq=1 => entire premium at t=0 => premium_collected = premium_amount
        # If freq=12 => premium_collected = premium_amount*(month_idx+1)/12 (for first year)
        prem_collected = jnp.where(premium_freq==1,
                                   premium_amounts[:,0][:,None]*((month_idx>=0).astype(FLOAT_DTYPE)),0) # entire premium at start
                                #    premium_amounts[:,0][:,None]*((jnp.minimum(month_idx+1,12))/12)) # if monthly freq
        # Surrender factor=0.5 for all years from instructions
        # unexpired_term=(policy_term_months - policy_months+1)
        unexpired_term = jnp.maximum(0.0, (policy_attrs['policy_terms_months'][:,None]-policy_attrs['policy_months']))
        sum_assureds_shape = policy_attrs['sum_assureds'].shape
        loan_amount_shape = policy_attrs['loan_amount'].shape
        loan_amount_reshaped = jnp.broadcast_to(policy_attrs['loan_amount'].reshape(loan_amount_shape[0], 1), sum_assureds_shape)
        sv=0.5*prem_collected * (unexpired_term / policy_attrs['policy_terms_months'][:,None]) * jnp.minimum(policy_attrs['sum_assureds'] / loan_amount_reshaped[:,0][:,None],1.0)
        surrender_benefits = sv * lapses

        # Interest on Cashflows:
        # interest on (premium +ve CF?), Actually from instructions:
        # net CF = -(premiums - commissions - initial_expense - renewal_expenses - claim_expenses - death_benefit - surrender_benefits + interest)
        # interest_on_cashflows = (premiums + commissions + initial_expense + renewal_expenses)*monthly_interest_rate
        # Commissions, initial_expense, renewal_expenses are negative => sum might be negative?
        base_cf_for_interest = (premiums - commissions - initial_expense - renewal_expenses)
        if layer=='Reserving':
            monthly_rate = rates['monthly_VROI_rates']
        else:
            monthly_rate = rates['monthly_ROI_rates']
        interest_on_cashflows = base_cf_for_interest*monthly_rate[None,:]

        net_cash_flows = -(premiums - commissions - initial_expense - renewal_expenses - claim_expenses - death_benefit - surrender_benefits + interest_on_cashflows)

        return {
            'premiums': premiums,
            'commissions': commissions,
            'initial_expense': initial_expense,
            'renewal_expenses': renewal_expenses,
            'claim_expenses': claim_expenses,
            'death_benefits': death_benefit,
            'surrender_benefits': surrender_benefits,
            'interest_on_cashflows': interest_on_cashflows,
            'net_cashflows': net_cash_flows,
            'sv': sv
        }

    def calculate_discounted_cf_reserves(self,policy_attrs,rates,decrements,gross_cf):
        """
        First backward pass: discount net_cashflows with monthly_VROI for reserving
        """
        net_cf = gross_cf['net_cashflows']
        lives_end = decrements['lives_so_end']
        maturities = decrements['maturities']
        monthly_vroi = rates['monthly_VROI_rates']
        policy_months = policy_attrs['policy_months']
        policy_terms = policy_attrs['policy_terms_months'][:, jnp.newaxis]
        single_premium=policy_attrs['premium_amounts']
        commissions= (((policy_attrs['projection_steps']>0) * policy_attrs['premium_amounts'] * rates['commission_rates'])[:,0])[:, jnp.newaxis]
        #init_expense = (rates['init_percent_sa_expense_rate']*policy_attrs['sum_assureds'][:,0])[:, jnp.newaxis]

        sum_assureds_shape = policy_attrs['sum_assureds'].shape
        loan_amount_shape = policy_attrs['loan_amount'].shape
        loan_amount_reshaped = jnp.broadcast_to(policy_attrs['loan_amount'].reshape(loan_amount_shape[0], 1), sum_assureds_shape)

        init_exp_upr = (rates['init_percent_sa_expense_rate']*loan_amount_reshaped[:,0])[:, jnp.newaxis]
        base_upr = single_premium - commissions - init_exp_upr
        sv = gross_cf['sv']
        
        net_cash_flows_rev = net_cf[:, ::-1]  # Shape: (num_policies, num_months)
        discount_rates_rev = monthly_vroi[::-1]  # Shape: (num_months,)

        def discount_policy_cashflows(net_cash_flow_rev):
            def discount_step(carry, inputs):
                discount_rate, net_cf = inputs
                pv_next = carry
                pv = (pv_next + net_cf) / (1 + discount_rate)
                return pv, pv

            init_carry = 0.0
        
            _, discounted_net_cf_rev = lax.scan(
                discount_step,
                init_carry,
                (discount_rates_rev, net_cash_flow_rev)
            )

            return discounted_net_cf_rev
        
        # Apply the function to each policy
        discounted_net_cf_rev = jax.vmap(discount_policy_cashflows)(net_cash_flows_rev)

        # Reverse back to original order
        discounted_net_cf = discounted_net_cf_rev[:, ::-1]

        discounted_net_cf = discounted_net_cf.at[:, :2].set(0.0)

        # Gross and Net Reserves Per Policy
        # Reserves per policy are the discounted net cashflows divided by lives at end
        if self.config.run_type in ['Valuation','CRNHR']:
            discounted_net_cf = jnp.concatenate([discounted_net_cf[:, 1:], jnp.zeros((discounted_net_cf.shape[0], 1))], axis=1)
        else:
            discounted_net_cf = jnp.concatenate([discounted_net_cf[:, 1:], jnp.zeros((discounted_net_cf.shape[0], 1))], axis=1) * (policy_attrs['projection_steps']>0)

        gross_reserve_pp = jnp.maximum(discounted_net_cf/(lives_end + maturities + 1e-8),0.0)
        
        upr = jnp.zeros_like(gross_reserve_pp)  # Placeholder for UPR calculation
        months_due_ratio = (policy_terms - policy_months + 0.5)/policy_terms
        
        max_term_UPR = int(self.product_config.variables.get('Max term for which UPR to be held (months)', 0.0))
        upr = jnp.maximum(0, base_upr * months_due_ratio) * (policy_attrs['projection_steps'] > 0) * (policy_terms <= max_term_UPR)

        gross_reserve_pp = jnp.maximum(upr, gross_reserve_pp)
        gross_reserve_pp = jnp.maximum(sv, gross_reserve_pp) *  jnp.where(policy_attrs['projection_steps']>0, 1, 0)
        gross_reserves = {
            'discounted_cf_reserving': discounted_net_cf,
            'gross_reserve_pp': gross_reserve_pp,
        }

        return gross_reserves

    def calculate_reinsurance_cash_flows(self, policy_attrs, rates, decrements_or_netres, gross_reserves, layer:str)->Dict[str,jnp.ndarray]:
        """
        2nd forward pass: Reinsurance cashflows
        For layer=Reserving or layer=BE, logic same:
        Reins sum assured(t)=max(sum_assured(t)-reins_ret_limit_abs - gross_reserve_pp(t-1),0)*reins_ret_limit_prop
        For t=0 no prev gross_reserve_pp(t-1)? assume t-1= -1 => gross_reserve_pp(-1)=0
        """
        lives_begin = decrements_or_netres['lives_so_begin'] if 'lives_so_begin' in decrements_or_netres else decrements_or_netres['lives_so_begin'] # from decrements if layer='Reserving', from BE decrements if layer='BE'
        deaths = decrements_or_netres['deaths'] if 'deaths' in decrements_or_netres else decrements_or_netres['deaths']
        sum_assureds = policy_attrs['sum_assureds']

        # For t=0, gross_reserve_pp(t-1)=0
        #gr_pp_shifted = jnp.concatenate([self.ZERO_ARRAY[:,[0]], gross_reserves['gross_reserve_pp'][:,:-1]],axis=1)
        gross_reserve_pp_prev = jnp.pad(gross_reserves['gross_reserve_pp'][:, :-1], ((0, 0), (1, 0)), constant_values=0.0)
        reins_sum_assured = jnp.maximum(sum_assureds - rates['reins_ret_limit_abs'] - gross_reserve_pp_prev,0.0)*rates['reins_ret_limit_prop']

        # Reins premium = reins_sum_assured * monthly_reins_mort * IFSM

        reins_premiums = reins_sum_assured * rates['monthly_reins_mort'] * lives_begin
        # Reins recoveries = reins_sum_assured * deaths
        reins_recoveries = reins_sum_assured * deaths

        # Net CF with reinsurance is done after we calculate main net cf if needed:
        # This function only returns reins_premiums and reins_recoveries
 

        return {
            'reins_sum_assured': reins_sum_assured,
            'reins_premiums': reins_premiums,
            'reins_recoveries': reins_recoveries
        }

    def calculate_net_reserves(self, policy_attrs, rates, decrements, reins_cf, gross_cf, gross_reserves, layer:str):
        """
        2nd backward pass: Net Reserves with reinsurance
        """
        lives_end = decrements['lives_so_end']
        maturities = decrements['maturities']
        monthly_vroi = rates['monthly_VROI_rates']
        sv = gross_cf['sv']

        # Now we can use gross_cf safely:
        net_cf_with_reinsurance = gross_cf['net_cashflows'] + reins_cf['reins_premiums'] - reins_cf['reins_recoveries']

        #df = jnp.cumprod(1/(1+monthly_vroi[::-1]))[::-1]
        #disc_net_cf_reins = net_cf_with_reinsurance*df[None,:]
        #disc_cf_with_reins_cumsum = jnp.cumsum(disc_net_cf_reins[:, ::-1], axis=1)[:, ::-1]

    #First backward pass: discount net_cashflows with monthly_VROI for reserving
        
        #net_cf = gross_cf['net_cashflows']
        lives_end = decrements['lives_so_end']
        maturities = decrements['maturities']
        monthly_vroi = rates['monthly_VROI_rates']
        policy_months = policy_attrs['policy_months']
        policy_terms = policy_attrs['policy_terms_months'][:, jnp.newaxis]
        single_premium=policy_attrs['premium_amounts']
        commissions= (((policy_attrs['projection_steps']>0) * policy_attrs['premium_amounts'] * rates['commission_rates'])[:,0])[:, jnp.newaxis]
        #init_expense = (rates['init_percent_sa_expense_rate']*policy_attrs['sum_assureds'][:,0])[:, jnp.newaxis]

        sum_assureds_shape = policy_attrs['sum_assureds'].shape
        loan_amount_shape = policy_attrs['loan_amount'].shape
        loan_amount_reshaped = jnp.broadcast_to(policy_attrs['loan_amount'].reshape(loan_amount_shape[0], 1), sum_assureds_shape)

        init_exp_upr = (rates['init_percent_sa_expense_rate']*loan_amount_reshaped[:,0])[:, jnp.newaxis]

        base_upr = single_premium - commissions - init_exp_upr
        
        net_cash_flows_rev = net_cf_with_reinsurance[:, ::-1]  # Shape: (num_policies, num_months)
        discount_rates_rev = monthly_vroi[::-1]  # Shape: (num_months,)

        def discount_policy_cashflows(net_cash_flow_rev):
            def discount_step(carry, inputs):
                discount_rate, net_cf = inputs
                pv_next = carry
                pv = (pv_next + net_cf) / (1 + discount_rate)
                return pv, pv

            init_carry = 0.0
        
            _, discounted_net_cf_rev = lax.scan(
                discount_step,
                init_carry,
                (discount_rates_rev, net_cash_flow_rev)
            )

            return discounted_net_cf_rev
        
        # Apply the function to each policy
        discounted_net_cf_rev = jax.vmap(discount_policy_cashflows)(net_cash_flows_rev)

        # Reverse back to original order
        discounted_net_cf = discounted_net_cf_rev[:, ::-1]

        # Gross and Net Reserves Per Policy
        # Reserves per policy are the discounted net cashflows divided by lives at end
        if self.config.run_type in ['Valuation','CRNHR']:
            discounted_net_cf = jnp.concatenate([discounted_net_cf[:, 1:], jnp.zeros((discounted_net_cf.shape[0], 1))], axis=1)
        else:
            discounted_net_cf = jnp.concatenate([discounted_net_cf[:, 1:], jnp.zeros((discounted_net_cf.shape[0], 1))], axis=1) * (policy_attrs['projection_steps']>0)

        net_reserve_pp = jnp.maximum(discounted_net_cf/(lives_end + maturities + 1e-8),0.0)

        upr = jnp.zeros_like(net_reserve_pp)  # Placeholder for UPR calculation
        months_due_ratio = (policy_terms - policy_months + 0.5)/policy_terms

        max_term_UPR = int(self.product_config.variables.get('Max term for which UPR to be held (months)', 0.0))
        upr = jnp.maximum(0, base_upr * months_due_ratio) * (policy_attrs['projection_steps'] > 0) * (policy_terms<=max_term_UPR)

        net_reserve_pp = jnp.maximum(upr, net_reserve_pp)
        net_reserve_pp = jnp.maximum(sv, net_reserve_pp)

        return {
            'net_cf_with_reinsurance': net_cf_with_reinsurance,
            'discounted_cf_with_reins': discounted_net_cf,
            'net_reserve_pp': net_reserve_pp
        }

    def calculate_be_layer(self, policy_attrs, rates, decrements, reinsurance_results, gross_reserve_pp, net_reserve_pp):
        """
        Third forward pass - BE Layer cashflows, reserves, solvency capital, and profit.
        """
        # Use the BE layer cashflows and decrements
        be_cashflows = self.calculate_cash_flows(
            policy_attrs,
            rates,
            decrements,
            reinsurance_results,
            layer='BE',
        )
        net_cf_without_reinsurance = -be_cashflows['net_cashflows']
        reinsurance_mortality_rates = rates['monthly_reins_mort']
        reins_sum_assured = reinsurance_results['reins_sum_assured']

        # Reinsurance Premiums and Recoveries
        be_cashflows['reins_premiums'] = reinsurance_mortality_rates * reins_sum_assured * decrements['lives_so_begin'] * (policy_attrs['projection_steps']>0)
        be_cashflows['reins_recoveries'] = reins_sum_assured * decrements['deaths']

        #base_cf_for_interest = (be_cashflows['premiums'] - be_cashflows['commissions'] - be_cashflows['initial_expense'] - be_cashflows['renewal_expenses'] -be_cashflows['reins_premiums'])
        monthly_rate = rates['monthly_ROI_rates']
        be_cashflows['interest_on_cashflows'] = be_cashflows['interest_on_cashflows'] - be_cashflows['reins_premiums'] * monthly_rate[None,:]

        be_cashflows['net_cashflows'] = (net_cf_without_reinsurance - be_cashflows['reins_premiums'] + be_cashflows['reins_recoveries'] - be_cashflows['reins_premiums'] * monthly_rate[None,:]) * (policy_attrs['projection_steps']>0)

        # Reserves
        lives_so_end = decrements['lives_so_end']

        be_reserves = net_reserve_pp * (lives_so_end + decrements['maturities'])
        be_reserves = jnp.maximum(be_reserves, 0.0)* (policy_attrs['projection_steps']>0)

        # Increase in Reserves
        reserve_shifted = jnp.concatenate(
            [self.ZERO_ARRAY[:, [0]], be_reserves[:, :-1]], axis=1)
        increase_in_reserves = be_reserves - reserve_shifted
        increase_in_reserves = increase_in_reserves.at[:, 0].set(be_reserves[:, 0])

        # Interest on Reserve
        monthly_ROI_rates = rates['monthly_ROI_rates']
        interest_on_reserve = reserve_shifted * monthly_ROI_rates[None, :] * (policy_attrs['projection_steps']>0) * (policy_attrs['policy_masks']>0)
        interest_on_reserve = interest_on_reserve.at[:, 0].set(0.0)

        # Solvency Capital Calculations
        sum_assureds = policy_attrs['sum_assureds']
        reins_sum_assured = reinsurance_results['reins_sum_assured']
        required_solvency_capital,gross_sar,net_sar, part1_sm, part2_sm = self.calculate_solvency_capital(
            policy_attrs, rates, decrements, be_reserves, gross_reserve_pp, net_reserve_pp, reins_sum_assured) 
        
        required_solvency_capital = required_solvency_capital.at[:, 0].set(0.0) 

        # Increase in Solvency Capital
        solvency_capital_shifted = jnp.concatenate(
            [self.ZERO_ARRAY[:, [0]], required_solvency_capital[:, :-1]], axis=1)
        increase_in_solvency_capital = required_solvency_capital - solvency_capital_shifted
        increase_in_solvency_capital = increase_in_solvency_capital.at[:, 0].set(required_solvency_capital[:, 0]) * (policy_attrs['projection_steps']>0)

        # Interest on Solvency Capital
        interest_on_solvency_capital = solvency_capital_shifted * monthly_ROI_rates[None, :]
        interest_on_solvency_capital = interest_on_solvency_capital.at[:, 0].set(0.0) * (policy_attrs['projection_steps']>0) * (policy_attrs['policy_masks']>0)

        # Profit Calculations
        profit_before_tax = (be_cashflows['net_cashflows'] - increase_in_reserves + interest_on_reserve)
        csr_rate = self.product_config.variables.get('CSR', 0.0)
        tax_rate = self.product_config.variables.get('Tax Rate', 0.0)
        csr = profit_before_tax * csr_rate * (policy_attrs['projection_steps']>0)
        tax = (profit_before_tax - csr) * tax_rate * (policy_attrs['projection_steps']>0)
        net_profit_before_sm = (profit_before_tax - csr - tax)

        # Net Profit After Solvency Margin
        cost_of_capital = increase_in_solvency_capital - interest_on_solvency_capital + \
                          (interest_on_solvency_capital * tax_rate) + (interest_on_solvency_capital * csr_rate) * (policy_attrs['projection_steps']>0)
        net_profit_after_sm = net_profit_before_sm - cost_of_capital

        be_results = {
            'be_premiums': be_cashflows['premiums'],
            'be_commissions': be_cashflows['commissions'],
            'be_initial_expense': be_cashflows['initial_expense'],
            'be_renewal_expenses': be_cashflows['renewal_expenses'],
            'be_claim_expenses': be_cashflows['claim_expenses'],
            'be_death_benefits': be_cashflows['death_benefits'],
            'be_surrender_benefits': be_cashflows['surrender_benefits'],
            'be_reinsurance_premiums': be_cashflows['reins_premiums'],
            'be_reinsurance_recoveries': be_cashflows['reins_recoveries'],
            'be_interest_on_cashflows': be_cashflows['interest_on_cashflows'],
            'be_net_cf': be_cashflows['net_cashflows'],
            'be_reserves': be_reserves,
            'increase_in_reserves': increase_in_reserves,
            'interest_on_reserves': interest_on_reserve,
            'part1_sm' : part1_sm,
            'part2_sm' : part2_sm,
            'gross_sar' : gross_sar,
            'net_sar' : net_sar,
            'required_solvency_capital': required_solvency_capital,
            'increase_in_solvency_capital': increase_in_solvency_capital,
            'interest_on_solvency_capital': interest_on_solvency_capital,
            'profit_before_tax': profit_before_tax,
            'csr': csr,
            'tax': tax,
            'net_profit_before_sm': net_profit_before_sm,
            'cost_of_capital': cost_of_capital,
            'net_profit_after_sm': net_profit_after_sm,
        }

        return be_results

    def calculate_solvency_capital(self, policy_attrs, rates, decrements, be_reserves, gross_reserve_pp, net_reserve_pp, reins_sum_assured):
        """
        Calculates solvency capital.

        Returns:
            required_solvency_capital: Solvency capital required at each time step.
        """
        sum_assureds = policy_attrs['sum_assureds']
        lives_so_end = decrements['lives_so_end']
        maturities = decrements['maturities']
        policy_terms_months = policy_attrs['policy_terms_months'][:, jnp.newaxis]

        max_term_UPR = int(self.product_config.variables.get('Max term for which UPR to be held (months)', 0.0))

        # Gross Sum at Risk
        gross_sar = (sum_assureds * (lives_so_end + maturities * (policy_terms_months <= max_term_UPR)  ) -  be_reserves)

        # Net Sum at Risk
        net_sar = ((sum_assureds - reins_sum_assured) * (lives_so_end + maturities * (policy_terms_months <= max_term_UPR)  ) - be_reserves)

        gross_sar = np.maximum(gross_sar, 0.0)
        net_sar = np.maximum(net_sar, 0.0)

        # Solvency Margin parameters
        Solvency_Margin_1_factor = float(self.product_config.variables.get('Part 1 SM', 0.0))
        Solvency_Margin_2_factor = float(self.product_config.variables.get('Part 2 SM', 0.0))
        Part1_net_to_gross_factor = float(self.product_config.variables.get('Part 1 net to gross factor', 1.0))
        Part2_net_to_gross_factor = float(self.product_config.variables.get('Part 2 net to gross factor', 1.0))
        Solvency_Ratio = float(self.product_config.variables.get('Solvency ratio', 1.0))

        # Part 1 SM
        net_to_gross_reserve_ratio = jnp.minimum(
            1.0,
            jnp.where(
                gross_reserve_pp != 0,
                net_reserve_pp / (gross_reserve_pp + 1e-6),
                1.0
            )
        )
        net_to_gross_reserve_ratio = jnp.minimum(jnp.maximum(net_to_gross_reserve_ratio, Part1_net_to_gross_factor), 1.0)
        part1_sm = be_reserves * Solvency_Margin_1_factor * net_to_gross_reserve_ratio * Solvency_Ratio

        # Part 2 SM
        net_to_gross_sar_ratio = jnp.minimum(
            1.0,
            jnp.where(
                gross_sar != 0,
                net_sar / (gross_sar + 1e-6),
                1.0
            )
        )
        net_to_gross_sar_ratio = jnp.maximum(net_to_gross_sar_ratio, Part2_net_to_gross_factor)
        part2_sm_mask = (policy_attrs['policy_months'] <= policy_attrs['policy_terms_months'][:, None])
        part2_sm = gross_sar * Solvency_Margin_2_factor * net_to_gross_sar_ratio * Solvency_Ratio * part2_sm_mask
        
        required_solvency_capital = (part1_sm + part2_sm) 
        required_solvency_capital = jnp.maximum(required_solvency_capital, 0.0)

        return required_solvency_capital, gross_sar, net_sar, part1_sm, part2_sm
    
    def calculate_pv_variables(self, policy_attrs, rates, be_results, reinsurance_results, decrements,batch_policy_numbers):
        """
        Third backward pass - Calculate MCEV, BEL, PVFP, and FCC.
        """
        num_policies = policy_attrs['num_policies']
        num_months = policy_attrs['policy_months'].shape[1]
        premiums = be_results['be_premiums']
        commissions = be_results['be_commissions']
        initial_expense = be_results['be_initial_expense']
        renewal_expenses = be_results['be_renewal_expenses']
        be_reserves = be_results['be_reserves']
        be_net_cf = be_results['be_net_cf']
        be_interest_on_cashflows = be_results['be_interest_on_cashflows']
        be_inc_in_reserves = be_results['increase_in_reserves']
        required_solvency_capital = be_results['required_solvency_capital']
        net_profit_before_sm = be_results['net_profit_before_sm']
        required_solvency_capital = be_results['required_solvency_capital']
        increase_in_solvency_capital = be_results['increase_in_solvency_capital']
        interest_on_solvency_capital = be_results['interest_on_solvency_capital']
        policy_months = policy_attrs['policy_months']

        monthly_CCIL_rates = rates['monthly_CCIL_rates']
        tax_rate = float(self.product_config.variables.get('Tax Rate', 0.0))
        csr_rate = float(self.product_config.variables.get('CSR', 0.0))
        
        interest_on_cashflows = (premiums - commissions - initial_expense - renewal_expenses - reinsurance_results['reins_premiums']) * monthly_CCIL_rates
        interest_on_cashflows = interest_on_cashflows * (policy_attrs['projection_steps'] > 0)

        reserve_shifted = jnp.concatenate(
            [self.ZERO_ARRAY[:, [0]], be_reserves[:, :-1]], axis=1)

        # Interest on Reserve
        interest_on_reserve = reserve_shifted * monthly_CCIL_rates[None, :] * (policy_attrs['projection_steps']>0)
        interest_on_reserve = interest_on_reserve.at[:, 0].set(0.0)

        net_cf = be_net_cf - be_interest_on_cashflows + interest_on_cashflows
        profit_before_tax = net_cf - be_inc_in_reserves + interest_on_reserve
        csr = profit_before_tax * csr_rate
        tax = (profit_before_tax-csr)*tax_rate
        net_profit = profit_before_tax - csr - tax

        # discount_factors = jnp.cumprod(1 / (1 + monthly_CCIL_rates[::-1]))[::-1]
        monthly_interest_rates_rev = monthly_CCIL_rates[::-1]  # Shape: (num_months,)

        def discount_policy_cashflows(cash_flow_rev):
            def discount_step(carry, inputs):
                discount_rate, net_cf = inputs
                pv_next = carry
                pv = (pv_next + net_cf) / (1 + discount_rate)
                return pv, pv

            init_carry = 0.0

            _, discounted_rev = lax.scan(
                discount_step,
                init_carry,
                (monthly_interest_rates_rev, cash_flow_rev)
            )

            return discounted_rev

        # PVFP
        net_profit_rev = net_profit[:, ::-1]  # Shape: (num_policies, num_months)
        disc_net_profit_rev = jax.vmap(discount_policy_cashflows)(net_profit_rev)
        disc_net_profit = disc_net_profit_rev[:, ::-1]
        pvfp = jnp.concatenate([disc_net_profit[:, 1:], jnp.zeros((disc_net_profit.shape[0], 1))], axis=1)

        # discounted_net_profit = net_profit_before_sm * discount_factors[None, :]
        # pvfp = jnp.cumsum(discounted_net_profit[:, ::-1], axis=1)[:, ::-1]

        # PV Premium
        def discount_premium_cashflows(cash_flow_rev):
            def discount_step(carry, inputs):
                discount_rate, net_cf = inputs
                pv_next = carry
                pv = net_cf + pv_next / (1 + discount_rate)
                return pv, pv

            init_carry = 0.0

            _, discounted_rev = lax.scan(
                discount_step,
                init_carry,
                (monthly_interest_rates_rev, cash_flow_rev)
            )

            return discounted_rev

        # PV Premium
        be_premiums = be_results['be_premiums']
        be_premiums_rev = be_premiums[:, ::-1]  # Shape: (num_policies, num_months)
        disc_be_premiums_rev = jax.vmap(discount_premium_cashflows)(be_premiums_rev)
        disc_be_premiums = disc_be_premiums_rev[:, ::-1]
        pv_premium = jnp.concatenate([disc_be_premiums[:, 1:], jnp.zeros((disc_be_premiums.shape[0], 1))], axis=1)
        
        # discounted_premiums = be_premiums * discount_factors[None, :]
        # pv_premium = jnp.cumsum(discounted_premiums[:, ::-1], axis=1)[:, ::-1]

        # BEL
        # be_net_cf = be_results['be_net_cf']
        net_cf_rev = net_cf[:, ::-1]  # Shape: (num_policies, num_months)
        disc_net_cf_rev= jax.vmap(discount_policy_cashflows)(net_cf_rev)
        disc_net_cf = disc_net_cf_rev[:, ::-1]
        bel = jnp.concatenate([disc_net_cf[:, 1:], jnp.zeros((disc_net_cf.shape[0], 1))], axis=1)
        bel_pp = -bel/(decrements['lives_so_end'] + decrements['maturities'])
        
        # discounted_be_net_cf = be_net_cf * discount_factors[None, :]
        # bel = jnp.cumsum(discounted_be_net_cf[:, ::-1], axis=1)[:, ::-1]

        # Frictional Cost of Capital (FCC)
        required_solvency_capital_shifted = jnp.concatenate(
            [self.ZERO_ARRAY[:, [0]], required_solvency_capital[:, :-1]], axis=1)
        
        interest_on_sm = required_solvency_capital_shifted * monthly_CCIL_rates
        tax_on_int_on_sm = interest_on_sm * tax_rate
        csr_on_int_on_sm = interest_on_sm * csr_rate
        coc = increase_in_solvency_capital - interest_on_sm + tax_on_int_on_sm + csr_on_int_on_sm


        # interest_on_solvency_capital_mcev = required_solvency_capital * monthly_CCIL_rates[None, :]
        # tax_on_interest_sc_mcev = interest_on_solvency_capital_mcev * tax_rate
        # csr_on_interest_sc_mcev = interest_on_solvency_capital_mcev * csr_rate
        # cost_of_capital_mcev = increase_in_solvency_capital - interest_on_solvency_capital_mcev + \
        #                        tax_on_interest_sc_mcev + csr_on_interest_sc_mcev

        coc_rev = coc[:, ::-1]  # Shape: (num_policies, num_months)
        disc_coc_rev= jax.vmap(discount_policy_cashflows)(coc_rev)
        disc_coc = disc_coc_rev[:, ::-1]
        fcc = jnp.concatenate([disc_coc[:, 1:], jnp.zeros((disc_coc.shape[0], 1))], axis=1)

        # discounted_coc_mcev = cost_of_capital_mcev * discount_factors[None, :]
        # fcc = jnp.cumsum(discounted_coc_mcev[:, ::-1], axis=1)[:, ::-1]

        # IFRS BEL
        premium_amounts = policy_attrs['premium_amounts']
        sum_assureds = policy_attrs['sum_assureds']
        commission_rates = rates['commission_rates']
        ifrs_premiums = be_premiums
        deaths = decrements['deaths']
        ifrs_death_benefits = sum_assureds * deaths
        ifrs_surrender_benefits = be_results['be_surrender_benefits']
        lives_so_end = decrements['lives_so_end']
        lives_so_begin = decrements['lives_so_begin']
        maturities = decrements['maturities']
        projection_steps = policy_attrs['projection_steps']

        # Instantiate the IFRS17 class and load the data
        ifrs17_init = IFRS17(self.config.table_index, self.config, self.product_name)
        ifrs17_init.load_data()
        
        starting_policy_month = policy_attrs['policy_months']
        
        valuation_month = self.config.valuation_date.month

        if valuation_month > 3:
            month_shift_locked_in = abs(valuation_month - 4)
        else:
            month_shift_locked_in = abs(valuation_month - 4 + 12)

        month_shift_current = abs(month_shift_locked_in - 13)

        # Access the IFRS ROI rates
        ifrs_current_rate_raw = ifrs17_init.get_monthly_rates('if17_Current_ROI')
        ifrs_current_rate = ifrs_current_rate_raw
        ifrs_current_rate = np.concatenate([ np.zeros(month_shift_current), ifrs_current_rate[:-(month_shift_current)] ])  
        ifrs_current_rate_array = np.tile(ifrs_current_rate, (num_policies, 1)) 
        
        ifrs_locked_in_rate_raw = ifrs17_init.get_monthly_rates('if17_Locked_in_Rate')
        
        ifrs_locked_in_rate = ifrs_locked_in_rate_raw[month_shift_locked_in:]
        ifrs_locked_in_rate = np.concatenate([np.zeros(1), ifrs_locked_in_rate[:-1]])
        ifrs_locked_in_rate = np.concatenate([ ifrs_locked_in_rate, np.zeros(month_shift_locked_in)])
        ifrs_locked_in_rate_array = np.tile(ifrs_locked_in_rate, (num_policies, 1)) 
        

        ifrs_ccil_rate_raw = ifrs17_init.get_monthly_rates('if17_CCIL Fwd Rates')
        
        num_policies, projection_months = starting_policy_month.shape
        ifrs_ccil_rate_list = []

        indicator = (policy_months - 1) // 12 + 1

        for i in range(num_policies):
            # Take the first month for each policy (e.g. starting_policy_month[i, 0])
            start_month = int(starting_policy_month[i, 0])  # assuming all cols are same start for that policy

            # Start from start_month, shift by 1 (add 0 in front), remove last
            rate_slice = ifrs_ccil_rate_raw[start_month:]
            shifted = np.concatenate([np.zeros(1), rate_slice[:-1]])

            # Pad to match projection length
            if len(shifted) < projection_months:
                shifted = np.concatenate([shifted, np.zeros(projection_months - len(shifted))])
            elif len(shifted) > projection_months:
                shifted = shifted[:projection_months]

            # Add to list
            ifrs_ccil_rate_list.append(shifted)
        

        # Convert the list to a numpy array
        ifrs_ccil_rate = ifrs_ccil_rate_list[0]
        ifrs_ccil_rate_array = np.array(ifrs_ccil_rate_list)

        for policy_idx in range(num_policies):
            # DYNAMICALLY select the correct rate array for the CURRENT policy
            ifrs_ccil_rate = ifrs_ccil_rate_array[policy_idx]
            # Reverse the rates for the current policy
            ccil_discount_rates_rev = ifrs_ccil_rate[::-1]


        # Multiply the initial expense with the IFRS initial expense multiplier

        ifrs_initial_expenses = (be_results['be_initial_expense'] * ifrs17_init.ifrs17_multiplier_initial_expenses) + be_results['be_commissions']

        # Calculate the IFRS17 renewal expenses
        IFRS_Renewal_Fixed_expenses = ifrs17_init.get_renewal_expense_rates('Fixed expenses')
        IFRS17_Prem_expenses = ifrs17_init.get_renewal_expense_rates('% of Prem')
        IFRS17_Claim_expenses = ifrs17_init.get_renewal_expense_rates('Claim expenses')
        
        ifrs_renewal_fixed_expenses = IFRS_Renewal_Fixed_expenses
        # Shift ifrs_renewal_fixed_expenses down by 1 row
        ifrs_renewal_fixed_expenses = np.insert(ifrs_renewal_fixed_expenses[:-1], 0, 0.0)

        if ifrs_renewal_fixed_expenses.ndim == 1:
                ifrs_renewal_fixed_expenses = np.expand_dims(ifrs_renewal_fixed_expenses, axis=0)

        last_value = 0

        for i in range(2, ifrs_renewal_fixed_expenses.shape[1], 12):  # Step by 12 months
            # Find the first non-zero value in the current 12-month block
            block_start = i
            block_end = min(i + 12, ifrs_renewal_fixed_expenses.shape[1])  # Ensure we don't go out of bounds
            block_values = ifrs_renewal_fixed_expenses[0, block_start:block_end]

            # Check if there is any non-zero value in the block
            non_zero_indices = jnp.where(block_values != 0)[0]
            if len(non_zero_indices) > 0:
                # Use the first non-zero value in the block
                first_non_zero_value = block_values[non_zero_indices[0]]
            else:
                # If no non-zero value is found, use the last value from the previous block
                first_non_zero_value = last_value

            # Update the block with the repeated value
            ifrs_renewal_fixed_expenses[0, block_start:block_end] = first_non_zero_value

            # Update the last_value for the next block
            last_value = first_non_zero_value

        ifrs_renewal_fixed_expenses_scaled = ifrs_renewal_fixed_expenses[:, 2:] * (1 / 12)
            
        ifrs_renewal_fixed_expenses_undec = jnp.concatenate(
            [ifrs_renewal_fixed_expenses[:, :2], ifrs_renewal_fixed_expenses_scaled],
            axis=1
        )
        # Ensure ifrs_renewal_fixed_expenses has the same number of rows as lives_so_begin
        if ifrs_renewal_fixed_expenses.shape[0] == 1:
            ifrs_renewal_fixed_expenses = jnp.tile(ifrs_renewal_fixed_expenses, (lives_so_begin.shape[0], 1))
            
        ifrs_renewal_fixed_expenses = ifrs_renewal_fixed_expenses.at[:, 2:].set(
            ifrs_renewal_fixed_expenses_undec[:, 2:] * lives_so_begin[:, 2:]
        )
        
        # Calculate the start month offset for each policy individually
        start_month_offsets = starting_policy_month[:, 0]  # Assuming starting_policy_month is a 2D array with shape (num_policies, num_months)
        premium_frequency = policy_attrs['premium_frequencies']

        # Adjust IFRS17_Prem_expenses for each policy based on its start month offset
        IFRS17_Prem_expenses = IFRS17_Prem_expenses.reshape(1, -1)
        adjusted_IFRS17_Prem_expenses = []
        for policy_idx, start_month_offset in enumerate(start_month_offsets):
            # Check if the premium frequency is 12 (annual)
            if premium_frequency[policy_idx, 0] >1:  # Assuming premium_frequency is a 2D array
                
                IFRS17_Prem_expenses_policy = IFRS17_Prem_expenses[:, start_month_offset - 1:]

                # Add padding to match the projection length
                padding_length = projection_months - IFRS17_Prem_expenses_policy.shape[1]
                if padding_length > 0:
                    padding = jnp.zeros((1, padding_length))
                    IFRS17_Prem_expenses_policy = jnp.concatenate([IFRS17_Prem_expenses_policy, padding], axis=1)
    
                if IFRS17_Prem_expenses_policy.ndim == 1:
                    IFRS17_Prem_expenses_policy = IFRS17_Prem_expenses_policy.reshape(1, -1) 
                
                last_value = 0

                # Iterate over the months in 12-month blocks
                for i in range(2, IFRS17_Prem_expenses_policy.shape[1], 12):  # Step by 12 months
                    # Find the first non-zero value in the current 12-month block
                    block_start = i
                    block_end = min(i + 12, IFRS17_Prem_expenses_policy.shape[1])  # Ensure we don't go out of bounds
                    block_values = IFRS17_Prem_expenses_policy[0, block_start:block_end]

                    # Check if there is any non-zero value in the block
                    non_zero_indices = jnp.where(block_values != 0)[0]
                    if len(non_zero_indices) > 0:
                        # Use the first non-zero value in the block
                        first_non_zero_value = block_values[non_zero_indices[0]]
                    else:
                        # If no non-zero value is found, use the last value from the previous block
                        first_non_zero_value = last_value

                    # Update the block with the repeated value
                    IFRS17_Prem_expenses_policy = IFRS17_Prem_expenses_policy.at[0, block_start:block_end].set(first_non_zero_value)

                    # Update the last_value for the next block
                    last_value = first_non_zero_value

            else:
                # Slice dynamically for the current policy
                IFRS17_Prem_expenses_policy = IFRS17_Prem_expenses[:, start_month_offset - 1:]
    
                # Add padding to match the projection length
                padding_length = projection_months - IFRS17_Prem_expenses_policy.shape[1]
                if padding_length > 0:
                    padding = jnp.zeros((1, padding_length))
                    IFRS17_Prem_expenses_policy = jnp.concatenate([IFRS17_Prem_expenses_policy, padding], axis=1)
    
            adjusted_IFRS17_Prem_expenses.append(IFRS17_Prem_expenses_policy)

        # Convert the list back to a single array
        adjusted_IFRS17_Prem_expenses = jnp.concatenate(adjusted_IFRS17_Prem_expenses, axis=0)

        if ifrs_renewal_fixed_expenses.ndim == 1:
            ifrs_premiums_reshape = ifrs_premiums.reshape(-1, len(ifrs_renewal_fixed_expenses))  # Reshape with dynamic number of policies
        else:
            ifrs_premiums_reshape = ifrs_premiums.reshape(-1, ifrs_renewal_fixed_expenses.shape[1])

        ifrs_renewal_prem_expenses = adjusted_IFRS17_Prem_expenses * ifrs_premiums_reshape
        
        combined_renewal_expenses = be_results['be_commissions'] + ifrs_renewal_fixed_expenses + ifrs_renewal_prem_expenses
        
         # Calculate claim expense
        ifrs_claim_expense = IFRS17_Claim_expenses * deaths

        #BEL Calculation (Gross of reinsurance and adjusted for I17 Expenses)
        # Calculate the BEL CF
        ifrs_bel_cf =  ifrs_death_benefits + ifrs_surrender_benefits + ifrs_initial_expenses + combined_renewal_expenses + ifrs_claim_expense - ifrs_premiums

        # Calculate BEL at Onerous Tagging Rate
        bel_at_onerous_tagging_rate = ifrs_bel_cf - ((ifrs_premiums - ifrs_initial_expenses - combined_renewal_expenses) * ifrs_ccil_rate)

         # Reverse arrays for backward calculation
        bel_at_onerous_tagging_rate_rev = bel_at_onerous_tagging_rate[:, ::-1]  # Shape: (num_policies, num_months)
        
        # Create an array to store reversed discount rates for all policies
        discount_rates_rev_array = np.zeros_like(ifrs_ccil_rate_array)

        # Populate the array with reversed rates for each policy
        for policy_idx in range(num_policies):
            ifrs_ccil_rate = ifrs_ccil_rate_array[policy_idx]
            discount_rates_rev_array[policy_idx] = ifrs_ccil_rate[::-1]

        # Function to discount cash flows for a single policy
        def discount_policy_cashflows(net_cash_flow_rev,discount_rates_rev):
            def discount_step(carry, inputs):
                discount_rate, net_cf = inputs
                pv_next = carry
                pv = (pv_next + net_cf) / (1 + discount_rate)
                return pv, pv

            init_carry = 0.0

            _, discounted_net_cf_rev = lax.scan(
                discount_step,
                init_carry,
                (discount_rates_rev, net_cash_flow_rev)
            )

            return discounted_net_cf_rev

        # Apply the function to each policy
        discounted_bel_at_onerous_tagging_rate_rev = jax.vmap(discount_policy_cashflows)(bel_at_onerous_tagging_rate_rev,discount_rates_rev_array)

        # Reverse back to original order
        discounted_bel_at_onerous_tagging_rate = discounted_bel_at_onerous_tagging_rate_rev[:, ::-1]

        # Shift the array by one row up
        discounted_bel_at_onerous_tagging_rate_shifted_up = discounted_bel_at_onerous_tagging_rate[:, 1:]

        discounted_bel_at_onerous_tagging_rate_shifted_up = np.hstack([discounted_bel_at_onerous_tagging_rate_shifted_up, np.zeros((discounted_bel_at_onerous_tagging_rate.shape[0], 1))])

        # Calculate BEL PP at Onerous tagging rate
        bel_pp_at_onerous_tagging_rate = discounted_bel_at_onerous_tagging_rate_shifted_up / (lives_so_end + maturities)
        
        # discounted_be_net_cf = be_net_cf * discount_factors[None, :]
        # bel = jnp.cumsum(discounted_be_net_cf[:, ::-1], axis=1)[:, ::-1]

        # Frictional Cost of Capital (FCC)
        required_solvency_capital_shifted = jnp.concatenate(
            [self.ZERO_ARRAY[:, [0]], required_solvency_capital[:, :-1]], axis=1)
        
        interest_on_sm = required_solvency_capital_shifted * monthly_CCIL_rates
        tax_on_int_on_sm = interest_on_sm * tax_rate
        csr_on_int_on_sm = interest_on_sm * csr_rate
        coc = increase_in_solvency_capital - interest_on_sm + tax_on_int_on_sm + csr_on_int_on_sm


        # interest_on_solvency_capital_mcev = required_solvency_capital * monthly_CCIL_rates[None, :]
        # tax_on_interest_sc_mcev = interest_on_solvency_capital_mcev * tax_rate
        # csr_on_interest_sc_mcev = interest_on_solvency_capital_mcev * csr_rate
        # cost_of_capital_mcev = increase_in_solvency_capital - interest_on_solvency_capital_mcev + \
        #                        tax_on_interest_sc_mcev + csr_on_interest_sc_mcev

        coc_rev = coc[:, ::-1]  # Shape: (num_policies, num_months)
        disc_coc_rev= jax.vmap(discount_policy_cashflows)(coc_rev,discount_rates_rev_array)
        disc_coc = disc_coc_rev[:, ::-1]
        fcc = jnp.concatenate([disc_coc[:, 1:], jnp.zeros((disc_coc.shape[0], 1))], axis=1)* (policy_months>=0)

        # discounted_coc_mcev = cost_of_capital_mcev * discount_factors[None, :]
        # fcc = jnp.cumsum(discounted_coc_mcev[:, ::-1], axis=1)[:, ::-1]

        # Calculate the PV of Expenses using Locked-In Rate
        combined_expenses_rev = combined_renewal_expenses[:, ::-1]  # Reverse for backward calculation
        discount_rates_locked_in_rev = ifrs_locked_in_rate[::-1]  # Reverse the locked-in rates

        # Function to discount expenses for a single policy
        def discount_expenses(expenses_rev):
            def discount_step(carry, inputs):
                discount_rate, expense = inputs
                pv_next = carry
                pv = (pv_next  / (1 + discount_rate)) + expense
                return pv, pv

            init_carry = 0.0

            _, discounted_expenses_rev = lax.scan(
                discount_step,
                init_carry,
                (discount_rates_locked_in_rev, expenses_rev)
            )

            return discounted_expenses_rev

        # Apply the function to each policy
        discounted_expenses_rev = jax.vmap(discount_expenses)(combined_expenses_rev)

        # Reverse back to original order
        discounted_expenses = discounted_expenses_rev[:, ::-1]

        discounted_expenses_shifted_up = discounted_expenses[:, 1:]

        discounted_expenses_shifted_up = np.hstack([discounted_expenses_shifted_up, np.zeros((discounted_expenses.shape[0], 1))])

        # Calculate adjusted px
        adj_px = lives_so_begin

        # Calculate the length of the arrays after flattening
        num_entries = policy_attrs['policy_months'].size  # Assuming policy_months is a 2D array

        # Repeat the batch_policy_numbers to match the number of entries
        policy_number_array = np.repeat(batch_policy_numbers, num_entries // len(batch_policy_numbers))
        policy_month_array = np.array(policy_attrs['policy_months']).flatten()[:num_entries]
        calendar_month_array = np.tile(policy_attrs['calendar_months'], len(batch_policy_numbers))[:num_entries]
        projection_steps = np.tile(policy_attrs['projection_steps'], len(batch_policy_numbers))[:num_entries]

        # Retrieve additional variables
        additional_variables = ifrs17_init.get_additional_variables()

        # Access v
        ifrs_v = additional_variables['IFRS17_V']
        ifrs_stress_v = additional_variables['IFRS17_Stress_V']

        # Calculate DF
        base_df = np.zeros(num_months)
        # Assuming policy_months is a range or list of month indices
        for i in list(range(1, num_months + 1)):
            if i < 3:
                base_df[i - 1] = 1
            else:
                base_df[i - 1] = ifrs_v ** (i - 1)

    
        stress_df = np.zeros(num_months)
        for i in list(range(1, num_months + 1)):
            if i < 3:
                stress_df[i - 1] = 1
            else:
                stress_df[i - 1] = ifrs_stress_v ** (i - 1)
        num_months   = self.projection_months
        
        # Build discount-factor arrays: shape (num_months,) for base & stress
        t_index     = jnp.arange(num_months)  # [0..num_months-1]
        df_base     = base_df
        df_stress   = stress_df

        # Function to compute the annuity-factor “vector” for one policy
        # e.g. a reversed cumulative sum of (adjusted_px * discount_factors).
        def annuity_factor_for_one_policy(px_for_policy: jnp.ndarray, df: jnp.ndarray) -> jnp.ndarray:
            rev_mult = px_for_policy[::-1] * df[::-1]      # shape (num_months,)
            rev_cumsum    = jnp.cumsum(rev_mult, axis=0) # partial sums in reverse
            partial_sums  = rev_cumsum[::-1]                  # shape (num_months,)

            return partial_sums / (df*px_for_policy )

        # Vectorize across all policies using jax.vmap
        annuity_factors_base_array = jax.vmap(lambda px: annuity_factor_for_one_policy(px, df_base))(adj_px)
        
         # Access stress expense
        stress_expense = additional_variables['IFRS17_Stress_Expense']
        
        annuity_factors_stress_array = jax.vmap(lambda px: annuity_factor_for_one_policy(px, df_stress))(adj_px)
        annuity_factors_stress_array = annuity_factors_stress_array*stress_expense

        # Access extra inflation
        stress_inflation = additional_variables['IFRS17_Stress_Inflation']

        # Calculate extra inflation
        ifrs_stress_inflation = np.zeros(num_months)
        for i in list(range(1, num_months + 1)):
            if i < 3:
                ifrs_stress_inflation[i - 1] = 1
            else:
                ifrs_stress_inflation[i - 1] = (1 + stress_inflation) ** (i - 2)


        # Calculate stress expense
        #stress_expense = np.tile(stress_expense, num_entries)
        stress_expense = np.full(policy_months.shape, stress_expense)
        
        ifrs_stress_expense = ifrs_renewal_fixed_expenses + ifrs_renewal_prem_expenses*stress_expense*ifrs_stress_inflation

        # Calculate the PV of Stress Expenses using Locked-In Rate
        ifrs_stress_expense_rev = ifrs_stress_expense[:, ::-1]  # Reverse for backward calculation
        discount_rates_locked_in_rev = ifrs_locked_in_rate[::-1]  # Reverse the locked-in rates

        # Function to discount expenses for a single policy
        def discount_expenses(stress_expenses_rev):
            def discount_step(carry, inputs):
                discount_rate, expense = inputs
                pv_next = carry
                pv = pv_next / (1 + discount_rate) + expense
                return pv, pv

            init_carry = 0.0

            _, discounted_stress_expenses_rev = lax.scan(
                discount_step,
                init_carry,
                (discount_rates_locked_in_rev, stress_expenses_rev)
            )

            return discounted_stress_expenses_rev

        # Apply the function to each policy
        discounted_stress_expenses_rev = jax.vmap(discount_expenses)(ifrs_stress_expense_rev)

        # Reverse back to original order
        discounted_stress_expenses = discounted_stress_expenses_rev[:, ::-1]

        discounted_stress_expenses_shifted_up = discounted_stress_expenses[:, 1:]

        discounted_stress_expenses_shifted_up = np.hstack([discounted_stress_expenses_shifted_up, np.zeros((discounted_stress_expenses.shape[0], 1))])

        infl_factor = (1 + rates['Inflation_Factor']) ** ((policy_attrs['projection_steps'] - 1)/12) 

        # Calculate Expense Capital
        ifrs_expense_captial = (ifrs_renewal_fixed_expenses_undec + ifrs_renewal_prem_expenses) * infl_factor * (annuity_factors_stress_array - annuity_factors_base_array) * lives_so_end

        pv_results = {
            'interest_on_cashflows':interest_on_cashflows,
            'interest_on_reserve':interest_on_reserve,
            'net_cf':net_cf,    
            'profit_before_tax':profit_before_tax,
            'csr':csr,
            'tax':tax,
            'net_profit':net_profit,
            'pvfp': pvfp,
            'pv_premium': pv_premium,
            'interest_on_sm':interest_on_sm,
            'tax_interest_on_sm': tax_on_int_on_sm,
            'csr_interest_on_sm': csr_on_int_on_sm,
            'coc':coc,
            'fcc': fcc,
            'bel': bel,
            'bel_pp':bel_pp,
            'ifrs_bel': discounted_bel_at_onerous_tagging_rate,
            'ifrs_bel_pp': bel_pp_at_onerous_tagging_rate,
            'ifrs_expense_capital': ifrs_expense_captial,
        }

        return pv_results
