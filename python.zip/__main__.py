from src.executor import executor
import json

def main():
    # SQL database configuration
    sql_config = {
        'source_type': 'sql',
        'db_host': 'localhost',
        'db_user': 'root',
        'db_password': 'Exodus!191',
        'db_name': 'python_model',
        'db_port': 3306
    }

    # JSON configuration with SQL data source
    json_config = {
        "Valuation_Date": "31-03-2024",
        "Projection_Term": 55,
        "Sensitivities_Flag": 0,
        "Reinsurance_Flag": 1,
        "Run_Type": "Valuation",
        "Target_Profit_Margin_Pricing": 0.1,
        "Risk_Discount_Rate_Pricing": 0.12,
        "Policy_start": 1,
        "Policy_end": 9999999,
        "Products_to_run": [
            "BASE_TERM",
            "GCL",
            "RIDER_ADB",
            "RIDER_CI",
            "RIDER_ATPD"
        ],
        "Output_path": "C:\\Users\\TW224JE\\Downloads\\output",
        "Output_seratim_cf_flag": 1,
        "data_source": sql_config  # Add SQL configuration
    }

    # Convert config to JSON string and execute
    json_config = json.dumps(json_config)
    executor(json_config)
    # Uncomment the above lines to run with SQL data source
    # If you want to run with CSV data source, you can use the following:
    #executor()
if __name__ == "__main__":
    main()