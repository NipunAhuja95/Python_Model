import pandas as pd
from sqlalchemy import create_engine, text

# 1. Create the engine pointing at python_model
engine = create_engine(
    "mysql+mysqlconnector://root:Exodus!191@localhost:3306/python_model",
    connect_args={"allow_local_infile": True}
)

# 2. Define your CSVs and target table names
tables_to_load = [
    (r"C:\Users\TW224JE\Downloads\Python_Life_model_21July\Python_Life_model\data\assumptions\Rein_Morbidity_Tbl_24Q3.csv",
     "rein_morbidity_tbl_24q3"),
]

for csv_path, table_name in tables_to_load:
    # a) Read CSV   
    df = pd.read_csv(csv_path)
    
    # b) (Optional) clean column names
    df.columns = df.columns.str.strip()
    
    # c) Drop if exists (avoids reflection errors)
    with engine.begin() as conn:
        conn.execute(text(f"DROP TABLE IF EXISTS `{table_name}`;"))
    
    # d) Write fresh table
    df.to_sql(
        name=table_name,
        con=engine,
        if_exists="fail",  # must not exist now
        index=False
    )
    
    print(f"✔ Loaded {len(df)} rows into python_model.{table_name}")

print("All five tables have been loaded successfully.")
