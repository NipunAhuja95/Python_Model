from flask import Flask, request, jsonify
from flask_cors import CORS
from src.executor import executor
import json

app = Flask(__name__)
CORS(app)

app.debug = True

# ✅ Static SQL database configuration
# TIP: You can later switch this to environment variables for security
sql_config = {
    'source_type': 'sql',
    'db_host': 'localhost',
    'db_user': 'root',
    'db_password': 'root',
    'db_name': 'python_model',
    'db_port': 3306
}

@app.route('/execute', methods=['POST'])
def execute():
    try:
        # 🔹 Get JSON input from API client (e.g., Spring Boot)
        input_data = request.get_json()

        if not input_data:
            return jsonify({"status": "error", "message": "No JSON data received"}), 400

        print("✅ Received data from client:", input_data)

        # 🔹 Inject SQL configuration into the payload
        input_data['data_source'] = sql_config

        # 🔹 Convert dict to JSON string (executor expects this)
        config_json = json.dumps(input_data)

        # 🔹 Call your executor function
        executor(config_json)

        return jsonify({"status": "success", "message": "Execution completed successfully"}), 200

    except Exception as e:
        print("❌ Error during execution:", str(e))
        return jsonify({"status": "error", "message": str(e)}), 500

if __name__ == "__main__":
    # Run the Flask app on all interfaces, port 5000
    app.run(host="0.0.0.0", port=5000)
