-- MySQL dump 10.13  Distrib 8.0.42, for Win64 (x86_64)
--
-- Host: localhost    Database: python_model
-- ------------------------------------------------------
-- Server version	8.0.42

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `dimension_maintenance`
--

DROP TABLE IF EXISTS `dimension_maintenance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dimension_maintenance` (
  `dimension_maintenance_id` bigint NOT NULL AUTO_INCREMENT,
  `dimension_table_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dimension_type` int DEFAULT NULL,
  `created_by` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `last_modified` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`dimension_maintenance_id`),
  UNIQUE KEY `uq_dimension_table_name` (`dimension_table_name`),
  KEY `idx_dimension_maintenance_created_by` (`created_by`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dimension_maintenance`
--

LOCK TABLES `dimension_maintenance` WRITE;
/*!40000 ALTER TABLE `dimension_maintenance` DISABLE KEYS */;
INSERT INTO `dimension_maintenance` VALUES (25,'bplan_premiums',0,'test@example.com','2025-10-05 18:50:35','2025-10-05 18:50:35'),(26,'table_index',0,'admin@example.com','2025-10-05 18:54:34','2025-10-05 18:54:34'),(27,'commrt_tbl_gcl_24q3',0,'admin@example.com','2025-10-08 17:57:12','2025-10-08 17:57:12'),(28,'commrt_tbl_term_24q3',0,'admin@example.com','2025-10-08 17:57:12','2025-10-08 17:57:12'),(29,'sensitivities_crnhr_ci_atpd_2024q3',0,'admin@example.com','2025-10-08 17:57:12','2025-10-08 17:57:12'),(30,'sensitivities_crnhr_adb_2024q3',0,'admin@example.com','2025-10-08 17:57:12','2025-10-08 17:57:12'),(31,'sensitivities_2024q3',0,'admin@example.com','2025-10-08 17:57:12','2025-10-08 17:57:12'),(32,'renewal_exp_tbl_term_ifrs17',0,'admin@example.com','2025-10-08 17:57:12','2025-10-08 17:57:12'),(33,'renewal_exp_tbl_rider_ifrs17',0,'admin@example.com','2025-10-08 17:57:12','2025-10-08 17:57:12'),(36,'renewal_exp_tbl_gcl_ifrs17',0,'admin@example.com','2025-10-08 18:01:00','2025-10-08 18:01:00'),(37,'reins_mort_support_term_tbl_24q3',0,'admin@example.com','2025-10-08 18:01:46','2025-10-08 18:01:46'),(38,'reins_mort_support_gcl_tbl_24q3',0,'admin@example.com','2025-10-08 18:01:46','2025-10-08 18:01:46'),(39,'rein_mort_tbl_gcl_24q3',0,'admin@example.com','2025-10-08 18:01:46','2025-10-08 18:01:46'),(40,'rein_mort_tbl_24q3',0,'admin@example.com','2025-10-08 18:01:46','2025-10-08 18:01:46'),(41,'rein_morbidity_tbl_24q3',0,'admin@example.com','2025-10-08 18:01:46','2025-10-08 18:01:46'),(42,'persistency_tbl_term_24q3',0,'admin@example.com','2025-10-08 18:09:39','2025-10-08 18:09:39'),(43,'persistency_tbl_gcl_24q3',0,'admin@example.com','2025-10-08 18:09:39','2025-10-08 18:09:39'),(44,'product_config_tbl_24q3',0,'admin@example.com','2025-10-08 18:09:39','2025-10-08 18:09:39'),(45,'premium_modal_factor',0,'admin@example.com','2025-10-08 18:09:39','2025-10-08 18:09:39'),(46,'policy_data_term',0,'admin@example.com','2025-10-08 18:09:39','2025-10-08 18:09:39'),(47,'policy_data_gcl',0,'admin@example.com','2025-10-08 18:09:39','2025-10-08 18:09:39'),(48,'policy_data_ci_rider',0,'admin@example.com','2025-10-08 18:09:39','2025-10-08 18:09:39'),(49,'policy_data_atpd_rider',0,'admin@example.com','2025-10-08 18:09:39','2025-10-08 18:09:39'),(50,'policy_data_adb_rider',0,'admin@example.com','2025-10-08 18:09:39','2025-10-08 18:09:39');
/*!40000 ALTER TABLE `dimension_maintenance` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-10-10 13:24:30
