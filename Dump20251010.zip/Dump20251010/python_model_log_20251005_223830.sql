-- MySQL dump 10.13  Distrib 8.0.42, for Win64 (x86_64)
--
-- Host: localhost    Database: python_model
-- ------------------------------------------------------
-- Server version	8.0.42

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `log_20251005_223830`
--

DROP TABLE IF EXISTS `log_20251005_223830`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `log_20251005_223830` (
  `run_ts` text,
  `log_type` text,
  `log_time` text,
  `level` text,
  `message` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_20251005_223830`
--

LOCK TABLES `log_20251005_223830` WRITE;
/*!40000 ALTER TABLE `log_20251005_223830` DISABLE KEYS */;
INSERT INTO `log_20251005_223830` VALUES ('20251005_223830','main','2025-10-05 22:38:05,312','INFO','Initializing run type instance.'),('20251005_223830','main','2025-10-05 22:38:05,314','INFO','Valuation initialized.'),('20251005_223830','main','2025-10-05 22:38:05,315','INFO','Valuation started for sensitivity: Base'),('20251005_223830','main','2025-10-05 22:38:05,316','INFO','Processing product: BASE_TERM under sensitivity: Base'),('20251005_223830','main','2025-10-05 22:38:05,318','INFO','Loading Mortality Assumptions.'),('20251005_223830','main','2025-10-05 22:38:06,945','INFO','Loading Persistency Assumptions.'),('20251005_223830','main','2025-10-05 22:38:07,286','INFO','Loading Expense Assumptions.'),('20251005_223830','main','2025-10-05 22:38:07,356','INFO','Loaded Initial Expenses successfully.'),('20251005_223830','main','2025-10-05 22:38:07,362','INFO','Loaded Renewal Expenses successfully.'),('20251005_223830','main','2025-10-05 22:38:07,363','INFO','Loading Commissions Assumptions.'),('20251005_223830','main','2025-10-05 22:38:07,590','INFO','Loading Interest Rate Assumptions.'),('20251005_223830','main','2025-10-05 22:38:07,889','INFO','Loading Reinsurance Mortality Assumptions.'),('20251005_223830','main','2025-10-05 22:38:08,659','INFO','Loading Modal factors'),('20251005_223830','main','2025-10-05 22:38:08,667','INFO','Completed loading assumptions for \'BASE_TERM\'.'),('20251005_223830','main','2025-10-05 22:38:08,817','INFO','Running TermCalculationEngine for product: BASE_TERM.'),('20251005_223830','main','2025-10-05 22:38:08,819','INFO','Starting TermCalculationEngine with 1 batches.'),('20251005_223830','main','2025-10-05 22:38:08,821','INFO','Processing batch 1 of 1'),('20251005_223830','main','2025-10-05 22:38:25,381','INFO','Batch 1 processed successfully.'),('20251005_223830','main','2025-10-05 22:38:29,410','INFO','Output written to SQL (MySQL) table \'base_term_base_output_20251005_223808\' on localhost as r***'),('20251005_223830','main','2025-10-05 22:38:29,982','INFO','Output written to SQL (MySQL) table \'base_term_base_aggregate_output_20251005_223808\' on localhost as r***'),('20251005_223830','main','2025-10-05 22:38:30,098','INFO','Output written to SQL (MySQL) table \'base_term_base_seriatim_output_20251005_223808\' on localhost as r***'),('20251005_223830','main','2025-10-05 22:38:30,101','INFO','TermCalculationEngine run completed.'),('20251005_223830','main','2025-10-05 22:38:30,102','INFO','Valuation completed for product: BASE_TERM.'),('20251005_223830','main','2025-10-05 22:38:30,103','INFO','Valuation finished for sensitivity: Base.');
/*!40000 ALTER TABLE `log_20251005_223830` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-10-10 13:24:18
