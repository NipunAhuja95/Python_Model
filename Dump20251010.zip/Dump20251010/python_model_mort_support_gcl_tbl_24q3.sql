-- MySQL dump 10.13  Distrib 8.0.42, for Win64 (x86_64)
--
-- Host: localhost    Database: python_model
-- ------------------------------------------------------
-- Server version	8.0.42

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `mort_support_gcl_tbl_24q3`
--

DROP TABLE IF EXISTS `mort_support_gcl_tbl_24q3`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mort_support_gcl_tbl_24q3` (
  `Age` bigint DEFAULT NULL,
  `BE_M_NS` bigint DEFAULT NULL,
  `BE_M_S` bigint DEFAULT NULL,
  `BE_F_NS` bigint DEFAULT NULL,
  `BE_F_S` bigint DEFAULT NULL,
  `RE_M_NS` double DEFAULT NULL,
  `RE_M_S` double DEFAULT NULL,
  `RE_F_NS` double DEFAULT NULL,
  `RE_F_S` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mort_support_gcl_tbl_24q3`
--

LOCK TABLES `mort_support_gcl_tbl_24q3` WRITE;
/*!40000 ALTER TABLE `mort_support_gcl_tbl_24q3` DISABLE KEYS */;
INSERT INTO `mort_support_gcl_tbl_24q3` VALUES (18,3,6,3,6,3.3,6.6,3.3,6.6),(19,3,6,3,6,3.3,6.6,3.3,6.6),(20,3,6,3,6,3.3,6.6,3.3,6.6),(21,3,6,3,6,3.3,6.6,3.3,6.6),(22,3,6,3,6,3.3,6.6,3.3,6.6),(23,3,6,3,6,3.3,6.6,3.3,6.6),(24,3,6,3,6,3.3,6.6,3.3,6.6),(25,3,6,3,6,3.3,6.6,3.3,6.6),(26,3,6,3,6,3.3,6.6,3.3,6.6),(27,3,6,3,6,3.3,6.6,3.3,6.6),(28,3,6,3,6,3.3,6.6,3.3,6.6),(29,3,6,3,6,3.3,6.6,3.3,6.6),(30,3,6,3,6,3.3,6.6,3.3,6.6),(31,3,6,3,6,3.3,6.6,3.3,6.6),(32,3,6,3,6,3.3,6.6,3.3,6.6),(33,3,6,3,6,3.3,6.6,3.3,6.6),(34,3,6,3,6,3.3,6.6,3.3,6.6),(35,3,6,3,6,3.3,6.6,3.3,6.6),(36,3,6,3,6,3.3,6.6,3.3,6.6),(37,3,6,3,6,3.3,6.6,3.3,6.6),(38,3,6,3,6,3.3,6.6,3.3,6.6),(39,3,6,3,6,3.3,6.6,3.3,6.6),(40,3,6,3,6,3.3,6.6,3.3,6.6),(41,3,6,3,6,3.3,6.6,3.3,6.6),(42,3,6,3,6,3.3,6.6,3.3,6.6),(43,3,6,3,6,3.3,6.6,3.3,6.6),(44,3,6,3,6,3.3,6.6,3.3,6.6),(45,3,6,3,6,3.3,6.6,3.3,6.6),(46,3,6,3,6,3.3,6.6,3.3,6.6),(47,3,6,3,6,3.3,6.6,3.3,6.6),(48,3,6,3,6,3.3,6.6,3.3,6.6),(49,3,6,3,6,3.3,6.6,3.3,6.6),(50,3,6,3,6,3.3,6.6,3.3,6.6),(51,3,6,3,6,3.3,6.6,3.3,6.6),(52,3,6,3,6,3.3,6.6,3.3,6.6),(53,3,6,3,6,3.3,6.6,3.3,6.6),(54,3,6,3,6,3.3,6.6,3.3,6.6),(55,3,6,3,6,3.3,6.6,3.3,6.6),(56,3,6,3,6,3.3,6.6,3.3,6.6),(57,3,6,3,6,3.3,6.6,3.3,6.6),(58,3,6,3,6,3.3,6.6,3.3,6.6),(59,3,6,3,6,3.3,6.6,3.3,6.6),(60,3,6,3,6,3.3,6.6,3.3,6.6),(61,3,6,3,6,3.3,6.6,3.3,6.6),(62,3,6,3,6,3.3,6.6,3.3,6.6),(63,3,6,3,6,3.3,6.6,3.3,6.6),(64,3,6,3,6,3.3,6.6,3.3,6.6),(65,3,6,3,6,3.3,6.6,3.3,6.6),(66,3,6,3,6,3.3,6.6,3.3,6.6),(67,3,6,3,6,3.3,6.6,3.3,6.6),(68,3,6,3,6,3.3,6.6,3.3,6.6),(69,3,6,3,6,3.3,6.6,3.3,6.6),(70,3,6,3,6,3.3,6.6,3.3,6.6),(71,3,6,3,6,3.3,6.6,3.3,6.6),(72,3,6,3,6,3.3,6.6,3.3,6.6),(73,3,6,3,6,3.3,6.6,3.3,6.6),(74,3,6,3,6,3.3,6.6,3.3,6.6),(75,3,6,3,6,3.3,6.6,3.3,6.6),(76,3,6,3,6,3.3,6.6,3.3,6.6),(77,3,6,3,6,3.3,6.6,3.3,6.6),(78,3,6,3,6,3.3,6.6,3.3,6.6),(79,3,6,3,6,3.3,6.6,3.3,6.6),(80,3,6,3,6,3.3,6.6,3.3,6.6),(81,3,6,3,6,3.3,6.6,3.3,6.6),(82,3,6,3,6,3.3,6.6,3.3,6.6),(83,3,6,3,6,3.3,6.6,3.3,6.6),(84,3,6,3,6,3.3,6.6,3.3,6.6),(85,3,6,3,6,3.3,6.6,3.3,6.6),(86,3,6,3,6,3.3,6.6,3.3,6.6),(87,3,6,3,6,3.3,6.6,3.3,6.6),(88,3,6,3,6,3.3,6.6,3.3,6.6),(89,3,6,3,6,3.3,6.6,3.3,6.6),(90,3,6,3,6,3.3,6.6,3.3,6.6),(91,3,6,3,6,3.3,6.6,3.3,6.6),(92,3,6,3,6,3.3,6.6,3.3,6.6),(93,3,6,3,6,3.3,6.6,3.3,6.6),(94,3,6,3,6,3.3,6.6,3.3,6.6),(95,3,6,3,6,3.3,6.6,3.3,6.6),(96,3,6,3,6,3.3,6.6,3.3,6.6),(97,3,6,3,6,3.3,6.6,3.3,6.6),(98,3,6,3,6,3.3,6.6,3.3,6.6),(99,3,6,3,6,3.3,6.6,3.3,6.6);
/*!40000 ALTER TABLE `mort_support_gcl_tbl_24q3` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-10-10 13:24:23
