-- MySQL dump 10.13  Distrib 8.0.42, for Win64 (x86_64)
--
-- Host: localhost    Database: python_model
-- ------------------------------------------------------
-- Server version	8.0.42

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `final_report_metadata`
--

DROP TABLE IF EXISTS `final_report_metadata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `final_report_metadata` (
  `id` int NOT NULL AUTO_INCREMENT,
  `table_name` varchar(255) NOT NULL,
  `run_type` varchar(100) DEFAULT NULL,
  `valuation_date` date DEFAULT NULL,
  `output_run_date` date DEFAULT NULL,
  `output_run_time` time DEFAULT NULL,
  `user_id` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `final_report_metadata`
--

LOCK TABLES `final_report_metadata` WRITE;
/*!40000 ALTER TABLE `final_report_metadata` DISABLE KEYS */;
INSERT INTO `final_report_metadata` VALUES (13,'base_term_base_output_20251006_000719','Valuation','2024-03-31','2025-10-06','00:07:39','admin@example.com','2025-10-05 18:37:39'),(14,'base_term_base_aggregate_output_20251006_000719','Valuation','2024-03-31','2025-10-06','00:07:40','admin@example.com','2025-10-05 18:37:40'),(15,'base_term_base_seriatim_output_20251006_000719','Valuation','2024-03-31','2025-10-06','00:07:40','admin@example.com','2025-10-05 18:37:40'),(16,'gcl_base_output_20251009_014621','Pricing','2024-03-31','2025-10-09','01:46:57','admin@example.com','2025-10-08 20:16:57'),(17,'gcl_base_aggregate_output_20251009_014621','Pricing','2024-03-31','2025-10-09','01:46:57','admin@example.com','2025-10-08 20:16:57'),(18,'gcl_base_output_20251009_015309','Pricing','2024-03-31','2025-10-09','01:53:44','admin@example.com','2025-10-08 20:23:44'),(19,'gcl_base_aggregate_output_20251009_015309','Pricing','2024-03-31','2025-10-09','01:53:44','admin@example.com','2025-10-08 20:23:44'),(20,'gcl_base_seriatim_output_20251009_015309','Pricing','2024-03-31','2025-10-09','01:53:44','admin@example.com','2025-10-08 20:23:44'),(21,'base_term_base_output_20251009_023446','Pricing','2024-03-31','2025-10-09','02:35:21','admin@example.com','2025-10-08 21:05:21'),(22,'base_term_base_aggregate_output_20251009_023446','Pricing','2024-03-31','2025-10-09','02:35:22','admin@example.com','2025-10-08 21:05:22'),(23,'base_term_base_seriatim_output_20251009_023446','Pricing','2024-03-31','2025-10-09','02:35:22','admin@example.com','2025-10-08 21:05:22'),(24,'gcl_base_output_20251009_155824','Pricing','2024-03-31','2025-10-09','15:59:07','admin@example.com','2025-10-09 10:29:07'),(25,'gcl_base_aggregate_output_20251009_155824','Pricing','2024-03-31','2025-10-09','15:59:07','admin@example.com','2025-10-09 10:29:07'),(26,'gcl_base_seriatim_output_20251009_155824','Pricing','2024-03-31','2025-10-09','15:59:08','admin@example.com','2025-10-09 10:29:08');
/*!40000 ALTER TABLE `final_report_metadata` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-10-10 13:24:16
