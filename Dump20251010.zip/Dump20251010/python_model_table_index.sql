-- MySQL dump 10.13  Distrib 8.0.42, for Win64 (x86_64)
--
-- Host: localhost    Database: python_model
-- ------------------------------------------------------
-- Server version	8.0.42

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `table_index`
--

DROP TABLE IF EXISTS `table_index`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `table_index` (
  `TableName` varchar(255) NOT NULL,
  `SQL_TableName` varchar(255) NOT NULL,
  PRIMARY KEY (`TableName`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `table_index`
--

LOCK TABLES `table_index` WRITE;
/*!40000 ALTER TABLE `table_index` DISABLE KEYS */;
INSERT INTO `table_index` VALUES ('Bplan_Premiums','bplan_premiums'),('Commission_Rates_GCL','commrt_tbl_gcl_24q3'),('Commission_Rates_Term','commrt_tbl_term_24q3'),('Correlation_Matrix_CRNHR','correlation_matrix_crnhr'),('Expense_Rate_GCL','exp_tbl_gcl_24q3'),('Expense_Rate_Rider','exp_tbl_rider_24q3'),('Expense_Rate_Term','exp_tbl_term_24q3'),('Index_Table','table_index'),('Initial_Expense_Rate_GCL_IFRS17','initial_exp_tbl_gcl_ifrs17'),('Initial_Expense_Rate_Rider_IFRS17','initial_exp_tbl_rider_ifrs17'),('Initial_Expense_Rate_Term_IFRS17','initial_exp_tbl_term_ifrs17'),('Interest_Rate','intrt_tbl_24q3'),('Interest_Rate_IFRS17','intrt_tbl_ifrs17'),('Morbidity_Table','morbidity_riders_24q3'),('Mortality_Support_GCL','mort_support_gcl_tbl_24q3'),('Mortality_Support_Term','mort_support_term_tbl_24q3'),('Mortality_Table','mort_tbl_24q3'),('Persistency_Rate_GCL','persistency_tbl_gcl_24q3'),('Persistency_Rate_Term','persistency_tbl_term_24q3'),('Policy_Data_ADB','policy_data_adb_rider'),('Policy_Data_ATPD','policy_data_atpd_rider'),('Policy_Data_CI','policy_data_ci_rider'),('Policy_Data_GCL','policy_data_gcl'),('Policy_Data_Term','policy_data_term'),('Premium_Modal_Factor','mod_factor'),('Product_Config','product_config_tbl_24q3'),('Reinsurance_Morbidity_Table','rein_morbidity_tbl_24q3'),('Reinsurance_Mortality_Support_GCL','reins_mort_support_gcl_tbl_24q3'),('Reinsurance_Mortality_Support_Term','reins_mort_support_term_tbl_24q3'),('Reinsurance_Mortality_Table','rein_mort_tbl_24q3'),('Reinsurance_Mortality_Table_GCL','rein_mort_tbl_gcl_24q3'),('Renewal_Expense_Rate_GCL_IFRS17','renewal_exp_tbl_rider_ifrs17'),('Renewal_Expense_Rate_Rider_IFRS17','renewal_exp_tbl_term_ifrs17'),('Renewal_Expense_Rate_Term_IFRS17','renewal_exp_tbl_gcl_ifrs17'),('Sensitivity_Table_CRNHR_ADB','sensitivities_crnhr_adb_2024q3'),('Sensitivity_Table_CRNHR_CI_ATPD','sensitivities_crnhr_ci_atpd_2024q3'),('Sensitivity_Table_CRNHR_Term_GCL','sensitivities_crnhr_term_gcl_2024q3'),('Sensitivity_Table_Valuation','sensitivities_2024q3');
/*!40000 ALTER TABLE `table_index` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-10-10 13:24:29
