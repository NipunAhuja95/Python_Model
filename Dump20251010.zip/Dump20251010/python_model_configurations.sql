-- MySQL dump 10.13  Distrib 8.0.42, for Win64 (x86_64)
--
-- Host: localhost    Database: python_model
-- ------------------------------------------------------
-- Server version	8.0.42

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `configurations`
--

DROP TABLE IF EXISTS `configurations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `configurations` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `valuation_date` varchar(255) DEFAULT NULL,
  `projection_term` varchar(255) DEFAULT NULL,
  `sensitivities_flag` tinyint(1) DEFAULT NULL,
  `reinsurance_flag` tinyint(1) DEFAULT NULL,
  `run_type` varchar(255) DEFAULT NULL,
  `target_profit_margin_pricing` varchar(255) DEFAULT NULL,
  `risk_discount_rate_pricing` varchar(255) DEFAULT NULL,
  `policy_start` varchar(255) DEFAULT NULL,
  `policy_end` varchar(255) DEFAULT NULL,
  `output_path` varchar(255) DEFAULT NULL,
  `output_seriatim_flag` tinyint(1) DEFAULT NULL,
  `submitted_by` varchar(255) DEFAULT NULL,
  `submitted_at` datetime(6) DEFAULT NULL,
  `created_by` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_configurations_created_by` (`created_by`)
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `configurations`
--

LOCK TABLES `configurations` WRITE;
/*!40000 ALTER TABLE `configurations` DISABLE KEYS */;
INSERT INTO `configurations` VALUES (18,'2024-03-31','25',0,0,'Valuation','0.1','0.12','1','1',NULL,1,'test@example.com','2025-10-05 11:19:28.011239','test@example.com'),(19,'2024-03-31','25',0,0,'Valuation','0.1','0.12','1','1',NULL,1,'test@example.com','2025-10-05 11:24:29.062795','test@example.com'),(20,'2024-03-31','10',0,0,'Valuation','0.1','0.12','1','1',NULL,1,'admin@example.com','2025-10-05 11:52:09.074442','admin@example.com'),(21,'2024-03-31','10',0,0,'Valuation','0.1','0.12','1','1',NULL,1,'admin@example.com','2025-10-05 12:30:00.467043','admin@example.com'),(22,'2024-03-31','10',0,0,'Valuation','0.1','0.12','1','1',NULL,1,'admin@example.com','2025-10-05 12:50:17.156836','admin@example.com'),(23,'2024-03-31','10',0,0,'BusinessPlanning','0.1','0.12','1','1',NULL,1,'admin@example.com','2025-10-05 13:01:37.264856','admin@example.com'),(24,'2024-03-31','10',0,0,'Valuation','0.1','0.12','1','1',NULL,1,'admin@example.com','2025-10-05 13:10:50.228879','admin@example.com'),(25,'2024-03-31','10',0,0,'Valuation','0.1','0.12','1','1',NULL,1,'admin@example.com','2025-10-05 13:20:20.133880','admin@example.com'),(26,'2024-03-31','',0,0,'Valuation','0.1','0.12','1','1','C:\\\\Users\\\\PS568BX\\\\Output',1,'admin@example.com','2025-10-05 16:57:20.230659','admin@example.com'),(27,'2024-03-31','10',0,0,'Valuation','0.1','0.12','1','1','C:\\\\Users\\\\PS568BX\\\\Output',1,'admin@example.com','2025-10-05 16:59:31.340625','admin@example.com'),(28,'2024-03-31','10',0,0,'Valuation','0.1','0.12','1','1','C:\\\\Users\\\\PS568BX\\\\Output',1,'admin@example.com','2025-10-05 17:02:02.379657','admin@example.com'),(29,'2024-03-31','10',0,0,'Valuation','0.1','0.12','1','1','C:\\\\Users\\\\PS568BX\\\\Output',1,'admin@example.com','2025-10-05 17:08:01.600593','admin@example.com'),(30,'2024-03-31','10',0,0,'Pricing','0.1','0.12','1','1','C:\\\\Users\\\\PS568BX\\\\Output',1,'admin@example.com','2025-10-05 17:26:43.959496','admin@example.com'),(31,'2024-03-31','10',0,0,'Pricing','0.1','0.12','1','1','C:\\\\Users\\\\PS568BX\\\\Output',1,'admin@example.com','2025-10-05 17:35:23.893553','admin@example.com'),(32,'2024-03-31','10',0,0,'Pricing','0.1','0.12','1','1','C:\\\\Users\\\\PS568BX\\\\Output',1,'admin@example.com','2025-10-05 17:51:02.864234','admin@example.com'),(33,'2024-03-31','10',0,0,'Valuation','0.1','0.12','1','1','C:\\\\Users\\\\PS568BX\\\\Output',1,'admin@example.com','2025-10-05 18:32:46.976212','admin@example.com'),(34,'2024-03-31','10',0,0,'Valuation','0.1','0.12','1','1','C:\\\\Users\\\\PS568BX\\\\Output',1,'admin@example.com','2025-10-05 18:37:16.834147','admin@example.com'),(35,'2024-03-31','2',0,0,'Pricing','0','1','1','1','C:\\\\Users\\\\PS568BX\\\\Output',1,'admin@example.com','2025-10-08 18:34:17.320477','admin@example.com'),(36,'2024-03-31','2',0,0,'Pricing','0.1','0','1','1','C:\\\\Users\\\\PS568BX\\\\Output',1,'admin@example.com','2025-10-08 18:36:26.061892','admin@example.com'),(37,'2024-03-31','2',0,0,'Pricing','0','1','1','1','C:\\\\Users\\\\PS568BX\\\\Output',1,'admin@example.com','2025-10-08 18:51:25.567348','admin@example.com'),(38,'2024-03-31','2',0,0,'Pricing','0','1','1','1','C:\\\\Users\\\\PS568BX\\\\Output',1,'admin@example.com','2025-10-08 20:08:04.586346','admin@example.com'),(39,'2024-03-31','2',0,0,'Pricing','0','1','1','1','C:\\\\Users\\\\PS568BX\\\\Output',1,'admin@example.com','2025-10-08 20:16:16.510556','admin@example.com'),(40,'2024-03-31','2',0,0,'Pricing','0','1','1','1','C:\\\\Users\\\\PS568BX\\\\Output',1,'admin@example.com','2025-10-08 20:23:04.820281','admin@example.com'),(41,'2024-03-31','2',0,0,'Valuation','0','1','1','1','C:\\\\Users\\\\PS568BX\\\\Output',1,'admin@example.com','2025-10-08 20:24:39.944167','admin@example.com'),(42,'2024-03-31','2',0,0,'Valuation','0','1','1','1','C:\\\\Users\\\\PS568BX\\\\Output',1,'admin@example.com','2025-10-08 20:25:08.863953','admin@example.com'),(43,'2024-03-31','2',0,0,'Valuation','0','1','1','1','C:\\\\Users\\\\PS568BX\\\\Output',1,'admin@example.com','2025-10-08 21:03:24.604190','admin@example.com'),(44,'2024-03-31','2',0,0,'Pricing','0','1','1','1','C:\\\\Users\\\\PS568BX\\\\Output',1,'admin@example.com','2025-10-08 21:04:43.964744','admin@example.com'),(45,'2024-03-31','2',0,0,'Pricing','0','1','1','1','C:\\\\Users\\\\PS568BX\\\\Output',1,'admin@example.com','2025-10-09 10:28:18.822455','admin@example.com');
/*!40000 ALTER TABLE `configurations` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-10-10 13:24:20
