-- MySQL dump 10.13  Distrib 8.0.42, for Win64 (x86_64)
--
-- Host: localhost    Database: python_model
-- ------------------------------------------------------
-- Server version	8.0.42

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `log_20251005_232207`
--

DROP TABLE IF EXISTS `log_20251005_232207`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `log_20251005_232207` (
  `run_ts` text,
  `log_type` text,
  `log_time` text,
  `level` text,
  `message` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_20251005_232207`
--

LOCK TABLES `log_20251005_232207` WRITE;
/*!40000 ALTER TABLE `log_20251005_232207` DISABLE KEYS */;
INSERT INTO `log_20251005_232207` VALUES ('20251005_232207','main','2025-10-05 23:21:09,493','INFO','Initializing run type instance.'),('20251005_232207','main','2025-10-05 23:21:09,495','INFO','Pricing initialized.'),('20251005_232207','main','2025-10-05 23:21:09,496','INFO','Pricing run started.'),('20251005_232207','main','2025-10-05 23:21:09,498','INFO','---Pricing BASE_TERM---'),('20251005_232207','main','2025-10-05 23:21:09,499','INFO','Loading Mortality Assumptions.'),('20251005_232207','main','2025-10-05 23:21:11,159','INFO','Loading Persistency Assumptions.'),('20251005_232207','main','2025-10-05 23:21:11,422','INFO','Loading Expense Assumptions.'),('20251005_232207','main','2025-10-05 23:21:11,487','INFO','Loaded Initial Expenses successfully.'),('20251005_232207','main','2025-10-05 23:21:11,491','INFO','Loaded Renewal Expenses successfully.'),('20251005_232207','main','2025-10-05 23:21:11,493','INFO','Loading Commissions Assumptions.'),('20251005_232207','main','2025-10-05 23:21:11,721','INFO','Loading Interest Rate Assumptions.'),('20251005_232207','main','2025-10-05 23:21:11,981','INFO','Loading Reinsurance Mortality Assumptions.'),('20251005_232207','main','2025-10-05 23:21:12,786','INFO','Loading Modal factors'),('20251005_232207','main','2025-10-05 23:21:12,795','INFO','Completed loading assumptions for \'BASE_TERM\'.'),('20251005_232207','main','2025-10-05 23:21:12,959','INFO','Running TermCalculationEngine for product: BASE_TERM.'),('20251005_232207','main','2025-10-05 23:21:12,960','INFO','Starting TermCalculationEngine.'),('20251005_232207','main','2025-10-05 23:22:05,445','INFO','Pricing goalseek completed in 26 iterations'),('20251005_232207','main','2025-10-05 23:22:07,192','INFO','Output written to SQL (MySQL) table \'base_term_base_aggregate_output_20251005_232112\' on localhost as r***'),('20251005_232207','main','2025-10-05 23:22:07,312','INFO','Output written to SQL (MySQL) table \'base_term_base_seriatim_output_20251005_232112\' on localhost as r***'),('20251005_232207','main','2025-10-05 23:22:07,313','INFO','TermCalculationEngine run completed.'),('20251005_232207','main','2025-10-05 23:22:07,315','INFO','Pricing run completed.');
/*!40000 ALTER TABLE `log_20251005_232207` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-10-10 13:24:26
