import React, { useEffect, useState } from "react";
import Modal from "react-modal";
import axios from "axios";
import $ from "jquery";
import "datatables.net-dt/css/dataTables.dataTables.css";
import "datatables.net";
import "./OutputTables.css";

const OutputTables = () => {
  const [selectedTable, setSelectedTable] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [totalRows, setTotalRows] = useState(0);

  // ✅ CSV download handler
  const handleDownloadCSV = async (tableName) => {
    console.log("Downloading CSV for:", tableName);
    try {
      const response = await axios.get(
        `http://localhost:8083/api/output-tables/download`,
        {
          params: { tableName },
          responseType: "blob",
        }
      );

      const blob = new Blob([response.data], { type: "text/csv" });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `${tableName}.csv`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      window.URL.revokeObjectURL(url);

      console.log("✅ CSV downloaded successfully");
    } catch (error) {
      console.error("❌ Error downloading CSV:", error);
      alert("Failed to download CSV for " + tableName);
    }
  };

  // Fetch list of output tables
  useEffect(() => {
    const fetchTables = async () => {
      try {
        const response = await axios.get(
          "http://localhost:8083/api/output-tables"
        );
        const data = response.data;

        if ($.fn.DataTable.isDataTable("#outputTableList")) {
          $("#outputTableList").DataTable().destroy();
        }

        // ✅ Initialize DataTable
        const table = $("#outputTableList").DataTable({
          data: data.map((row) => [
            row.table_name,
            row.run_type || "",
            row.valuation_date || "",
            row.output_run_date || "",
            row.output_run_time || "",
            row.user_id || "",
            `<button type="button" class="btn btn-sm btn-primary download-btn" data-table="${row.table_name}">
              Download File
            </button>`,
          ]),
          columns: [
            { title: "Output Table Name" },
            { title: "Run Type" },
            { title: "Valuation Date" },
            { title: "Output Run Date" },
            { title: "Output Run Time" },
            { title: "User ID" },
            { title: "Actions" },
          ],
          destroy: true,
          autoWidth: false,
          paging: true,
          scrollX: true,
        });

        // ✅ Fix 1: Delegated click handler for download
        $("#outputTableList tbody").off("click", ".download-btn");
        $("#outputTableList tbody").on("click", ".download-btn", function (e) {
          e.stopPropagation();
          const tableName = $(this).data("table");
          handleDownloadCSV(tableName);
        });

        // ✅ Fix 2: Separate row click handler for modal
        $("#outputTableList tbody")
          .off("click", "tr")
          .on("click", "tr", function (event) {
            if ($(event.target).hasClass("download-btn")) return;
            const rowData = table.row(this).data();
            if (rowData && rowData[0]) {
              setSelectedTable(rowData[0]);
              setIsModalOpen(true);
            }
          });
      } catch (err) {
        console.error("Error fetching output tables:", err);
      }
    };

    fetchTables();
  }, []);

  // Initialize DataTable inside modal
  useEffect(() => {
    if (selectedTable && isModalOpen) {
      const initDataTable = async () => {
        try {
          const response = await axios.get(
            "http://localhost:8083/api/output-tables/data",
            { params: { tableName: selectedTable, page: 1, size: 10 } }
          );

          const { columns, totalRows } = response.data;
          setTotalRows(totalRows);

          const formattedColumns = columns.map((col) => ({
            title: col.replace(/_/g, " ").toUpperCase(),
            data: col,
          }));

          if ($.fn.DataTable.isDataTable("#viewOutputTable")) {
            $("#viewOutputTable").DataTable().destroy();
          }

          $("#viewOutputTable").DataTable({
            serverSide: true,
            processing: true,
            ajax: async (data, callback) => {
              const page = Math.floor(data.start / data.length) + 1;
              const size = data.length;

              const res = await axios.get(
                "http://localhost:8083/api/output-tables/data",
                { params: { tableName: selectedTable, page, size } }
              );

              callback({
                draw: data.draw,
                recordsTotal: res.data.totalRows,
                recordsFiltered: res.data.totalRows,
                data: res.data.data,
              });
            },
            columns: formattedColumns,
            scrollX: true,
            paging: true,
            pageLength: 10,
            autoWidth: false,
            responsive: true,
            destroy: true,
          });
        } catch (err) {
          console.error("Error loading table data:", err);
        }
      };

      initDataTable();
    }
  }, [selectedTable, isModalOpen]);

  return (
    <div
      className="px-4 pb-4 w-full bg-gray-50"
      style={{ marginTop: "64px", height: "calc(100vh - 64px)" }}
    >
      <h2 className="text-xl font-bold mb-4">Output Tables</h2>

      {/* Table List */}
      <div id="OutputTableListContainer">
        <table
          id="outputTableList"
          className="display w-full hover cell-border custom-headers"
        ></table>
      </div>

      {/* Modal */}
      <Modal
        isOpen={isModalOpen}
        onRequestClose={() => setIsModalOpen(false)}
        overlayClassName="customModalOverlay"
        className="customModalContent"
        ariaHideApp={false}
      >
        <div className="w-full h-full grid grid-rows-[auto_1fr_auto]">
          <div className="header">
            <span className="font-semibold text-lg">
              {selectedTable} ({totalRows} rows)
            </span>
            <button onClick={() => setIsModalOpen(false)}>
              <box-icon name="x"></box-icon>
            </button>
          </div>

          <div id="TableContainer" className="w-full px-4 overflow-x-auto">
            <table
              id="viewOutputTable"
              className="row-border w-full text-xs nowrap"
            ></table>
          </div>

          <div className="footer">
            <button
              onClick={() => setIsModalOpen(false)}
              className="red-button"
            >
              <box-icon color="red" name="x"></box-icon> CLOSE
            </button>
          </div>
        </div>
      </Modal>
    </div>
  );
};

export default OutputTables;
