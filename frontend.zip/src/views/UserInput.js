import React, { useState, useEffect } from 'react';
import { TextField } from '@mui/material';
import './RunScript.css';
import axios from 'axios';
import { toast, ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

// Reusable Checkbox component
const Checkbox = ({ id, label, value, setter }) => {
  const handleChange = () => {
    setter(value === 1 ? 0 : 1); // Toggle between 1 and 0
  };

  return (
    <div className="flex items-center gap-2 text-[#1f2837]">
      <input
        onChange={handleChange}
        checked={value === 1}
        className="w-4 h-4 accent-[#1f2837]"
        id={id}
        type="checkbox"
      />
      <label htmlFor={id} className="cursor-pointer">
        {label}
      </label>
    </div>
  );
};

const UserInput = () => {
  const [config, setConfig] = useState(null);
  const [valuationDate, setValuationDate] = useState('');
  const [projectionTerm, setProjectionTerm] = useState('');
  const [sensitivitiesFlag, setSensitivitiesFlag] = useState(0);
  const [reinsuranceFlag, setReinsuranceFlag] = useState(0);
  const [runType, setRunType] = useState('Pricing');
  const [targetProfitMarginPricing, setTargetProfitMarginPricing] = useState('');
  const [riskDiscountRatePricing, setRiskDiscountRatePricing] = useState('');
  const [policyStart, setPolicyStart] = useState(0);
  const [policyEnd, setPolicyEnd] = useState(0);
  const [outputPath, setOutputPath] = useState('');
  const [outputCeratimCfFlag, setOutputCeratimCfFlag] = useState(0);

  // Product checkboxes
  const [baseTerm, setBaseTerm] = useState(0);
  const [gcl, setGcl] = useState(0);
  const [riderAdb, setRiderAdb] = useState(0);
  const [riderCi, setRiderCi] = useState(0);
  const [riderAtpd, setRiderAtpd] = useState(0);

  useEffect(() => {
    axios.get('/config.json')
      .then((res) => setConfig(res.data))
      .catch((err) => {
        console.error('Failed to load config:', err);
        toast.error('Failed to load configuration.');
      });
  }, []);

  const runConfiguration = async (e) => {
    e.preventDefault();

    if (!config?.apiUrlPostConfig) {
      toast.error('API URL not configured.');
      return;
    }

    const token = localStorage.getItem('jwtToken');

    const productMap = {
      'Base Term': 'BASE_TERM',
      'GCL': 'GCL',
      'Rider ADB': 'RIDER_ADB',
      'Rider CI': 'RIDER_CI',
      'Rider ATPD': 'RIDER_ATPD',
    };

    const selectedProducts = Object.entries({
      'Base Term': baseTerm,
      'GCL': gcl,
      'Rider ADB': riderAdb,
      'Rider CI': riderCi,
      'Rider ATPD': riderAtpd
    })
      .filter(([_, isSelected]) => isSelected)
      .map(([label]) => productMap[label]);

    try {
      const response = await axios.post(
        config.apiUrlPostConfig,
        {
          token,
          valuationDate,
          projectionTerm,
          sensitivitiesFlag: sensitivitiesFlag === 1,
          reinsuranceFlag: reinsuranceFlag === 1,
          runType,
          targetProfitMarginPricing,
          riskDiscountRatePricing,
          policyStart: policyStart.toString(),
          policyEnd: policyEnd.toString(),
          outputPath,
          outputSeriatimFlag: outputCeratimCfFlag === 1,
          selectedProducts,
        },
        {
          headers: {
            'Content-Type': 'application/json',
          },
        }
      );

      const { pythonResponse } = response.data;

      const pythonStatus = typeof pythonResponse === 'string' ? JSON.parse(pythonResponse) : pythonResponse;

      if (pythonStatus.status === 'success') {
        toast.success('Configuration run successful!');
        setValuationDate('');
        setProjectionTerm('');
        setSensitivitiesFlag(0);
        setReinsuranceFlag(0);
        setRunType('Pricing');
        setTargetProfitMarginPricing('');
        setRiskDiscountRatePricing('');
        setPolicyStart(0);
        setPolicyEnd(0);
        setOutputPath('');
        setOutputCeratimCfFlag(0);
        setBaseTerm(0);
        setGcl(0);
        setRiderAdb(0);
        setRiderCi(0);
        setRiderAtpd(0);
      } else {
        toast.warn('Python backend failed. Please check logs.');
      }
    } catch (error) {
      console.error('Config error:', error);
      toast.error('Please try again in some time');
    }
  };

  return (
    <div className="flex h-screen overflow-hidden bg-white text-[#1f2837]">
      <div className="flex-1 flex flex-col h-full">
        <div className="flex-1 overflow-y-auto p-6 mt-11">
          <div className="flex flex-col gap-6 w-full">
            {/* Products Section */}
            <div>
              <h2 className="text-xl font-semibold mb-4">Products</h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                <Checkbox id="baseTerm" label="Base Term" value={baseTerm} setter={setBaseTerm} />
                <Checkbox id="gcl" label="GCL" value={gcl} setter={setGcl} />
                <Checkbox id="riderAdb" label="Rider ADB" value={riderAdb} setter={setRiderAdb} />
                <Checkbox id="riderCi" label="Rider CI" value={riderCi} setter={setRiderCi} />
                <Checkbox id="riderAtpd" label="Rider ATPD" value={riderAtpd} setter={setRiderAtpd} />
              </div>
              <hr className="border-gray-300" />
            </div>

            {/* Configuration Section */}
            <div>
              <h2 className="text-xl font-semibold mb-4">Configuration Data</h2>
              <div className="space-y-4">
                <TextField
                  fullWidth
                  type="date"
                  label="Valuation Date"
                  variant="outlined"
                  size="small"
                  value={valuationDate}
                  onChange={(e) => setValuationDate(e.target.value)}
                  InputLabelProps={{ shrink: true }}
                  InputProps={{ style: { color: '#1f2837' } }}
                  sx={{ label: { color: '#1f2837' }, '& .MuiOutlinedInput-root': { '& fieldset': { borderColor: '#1f2837' } } }}
                />
                <TextField
                  fullWidth
                  label="Projection Term"
                  variant="outlined"
                  size="small"
                  value={projectionTerm}
                  onChange={(e) => setProjectionTerm(e.target.value)}
                  InputProps={{ style: { color: '#1f2837' } }}
                  sx={{ label: { color: '#1f2837' }, '& .MuiOutlinedInput-root': { '& fieldset': { borderColor: '#1f2837' } } }}
                />
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Checkbox id="sensitivitiesFlag" label="Sensitivities Flag" value={sensitivitiesFlag} setter={setSensitivitiesFlag} />
                  <Checkbox id="reinsuranceFlag" label="Reinsurance Flag" value={reinsuranceFlag} setter={setReinsuranceFlag} />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1">Run Type</label>
                  <select
                    id="runTypeDropdown"
                    className="p-2 border border-[#1f2837] rounded w-full bg-transparent text-[#1f2837] focus:outline-none"
                    value={runType}
                    onChange={(e) => setRunType(e.target.value)}
                  >
                    <option value="Pricing">Pricing</option>
                    <option value="Valuation">Valuation</option>
                    <option value="BusinessPlanning">BusinessPlanning</option>
                    <option value="CRNHR">CRNHR</option>
                    <option value="IFRS">IFRS</option>
                  </select>
                </div>
                <TextField
                  fullWidth
                  label="Target Profit Margin Pricing"
                  variant="outlined"
                  size="small"
                  value={targetProfitMarginPricing}
                  onChange={(e) => setTargetProfitMarginPricing(e.target.value)}
                  InputProps={{ style: { color: '#1f2837' } }}
                  sx={{ label: { color: '#1f2837' }, '& .MuiOutlinedInput-root': { '& fieldset': { borderColor: '#1f2837' } } }}
                />
                <TextField
                  fullWidth
                  label="Risk Discount Rate Pricing"
                  variant="outlined"
                  size="small"
                  value={riskDiscountRatePricing}
                  onChange={(e) => setRiskDiscountRatePricing(e.target.value)}
                  InputProps={{ style: { color: '#1f2837' } }}
                  sx={{ label: { color: '#1f2837' }, '& .MuiOutlinedInput-root': { '& fieldset': { borderColor: '#1f2837' } } }}
                />
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Checkbox id="policyStart" label="Policy Start" value={policyStart} setter={setPolicyStart} />
                  <Checkbox id="policyEnd" label="Policy End" value={policyEnd} setter={setPolicyEnd} />
                </div>
                <TextField
                  fullWidth
                  label="Output Path"
                  variant="outlined"
                  size="small"
                  value={outputPath}
                  onChange={(e) => setOutputPath(e.target.value)}
                  InputProps={{ style: { color: '#1f2837' } }}
                  sx={{ label: { color: '#1f2837' }, '& .MuiOutlinedInput-root': { '& fieldset': { borderColor: '#1f2837' } } }}
                />
                <Checkbox
                  id="outputCeratimCfFlag"
                  label="Output Seratim CF Flag"
                  value={outputCeratimCfFlag}
                  setter={setOutputCeratimCfFlag}
                />
              </div>
            </div>

            {/* Submit Button */}
            <div className="flex justify-center mt-6">
              <button
                onClick={runConfiguration}
                disabled={!config}
                className="text-white bg-[#1f2837] rounded-md px-6 py-2 hover:bg-gray-800 disabled:bg-gray-400 disabled:text-gray-200"
              >
                Run Output
              </button>
            </div>
          </div>
        </div>
      </div>
      <ToastContainer />
    </div>
  );
};

export default UserInput;
