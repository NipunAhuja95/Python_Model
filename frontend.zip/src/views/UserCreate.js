import React, { useEffect, useState } from 'react';
import {
  TextField,
  Button,
  MenuItem,
  IconButton,
  InputAdornment
} from '@mui/material';

import { Visibility, VisibilityOff } from '@mui/icons-material';
import { JSEncrypt } from 'jsencrypt';
import axios from 'axios';

const UserCreate = () => {
  const [config, setConfig] = useState({});
  const [publicKey, setPublicKey] = useState('');
  const [formData, setFormData] = useState({
    username: '',
    email: '',
    password: '',
    retypePassword: '',
    role: '',
  });
  const [showPassword, setShowPassword] = useState(false);
  const [showRetypePassword, setShowRetypePassword] = useState(false);
  const [passwordMismatch, setPasswordMismatch] = useState(false);

  const roles = ['ADMIN', 'USER'];

  useEffect(() => {
    fetch('./config.json')
      .then((response) => response.json())
      .then((data) => {
        setConfig(data);
        if (data.publicKey) {
          const fullKey = `-----BEGIN PUBLIC KEY-----\n${data.publicKey}\n-----END PUBLIC KEY-----`;
          setPublicKey(fullKey);
        } else {
          console.warn('Public key missing in config');
        }
      })
      .catch((error) => console.error('Error loading config:', error));
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;

    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));

    if (name === 'password' || name === 'retypePassword') {
      const other = name === 'password' ? formData.retypePassword : formData.password;
      setPasswordMismatch(value !== other);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!publicKey) {
      alert('Public key not loaded.');
      return;
    }

    if (formData.password !== formData.retypePassword) {
      setPasswordMismatch(true);
      return;
    }

    const encryptor = new JSEncrypt();
    encryptor.setPublicKey(publicKey);

    const encryptedPassword = encryptor.encrypt(formData.password);

    if (!encryptedPassword) {
      alert('Password encryption failed.');
      return;
    }

    const payload = {
      username: formData.username,
      email: formData.email,
      password: encryptedPassword,
      roles: [formData.role],
    };

    try {
      await axios.post(config.apiUrlAddUser, payload, {
        headers: { 'Content-Type': 'application/json' },
      });

      alert('User successfully created!');
      setFormData({
        username: '',
        email: '',
        password: '',
        retypePassword: '',
        role: '',
      });
    } catch (error) {
      console.error('Error creating user:', error);
      alert('Failed to create user. Please check logs or backend.');
    }
  };

  return (
    <div
      style={{
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        minHeight: '100vh',
        backgroundColor: 'white',
      }}
    >
      <div
        style={{
          backgroundColor: 'white',
          color: '#1f2837',
          padding: '30px',
          borderRadius: '12px',
          width: '100%',
          maxWidth: '400px',
          boxShadow: '0px 6px 18px rgba(0,0,0,0.15)',
        }}
      >
        <h2 style={{ marginBottom: '20px', textAlign: 'center', fontSize: '22px' }}>
          Create User
        </h2>

        <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '18px' }}>
          <TextField
            label="User Name"
            name="username"
            value={formData.username}
            onChange={handleChange}
            size="small"
            fullWidth
            autoComplete="off" // 🔑 stop autofill
          />

          <TextField
            label="Email"
            name="email"
            type="email"
            value={formData.email}
            onChange={handleChange}
            size="small"
            fullWidth
            autoComplete="new-email" // 🔑 stop autofill
          />

          <TextField
            label="Password"
            name="password"
            type={showPassword ? 'text' : 'password'}
            value={formData.password}
            onChange={handleChange}
            size="small"
            fullWidth
            autoComplete="new-password" // 🔑 stop autofill
            InputProps={{
              endAdornment: (
                <InputAdornment position="end">
                  <IconButton onClick={() => setShowPassword((prev) => !prev)} edge="end">
                    {showPassword ? (
                      <VisibilityOff style={{ color: '#1f2837' }} />
                    ) : (
                      <Visibility style={{ color: '#1f2837' }} />
                    )}
                  </IconButton>
                </InputAdornment>
              ),
            }}
          />

          <TextField
            label="Retype Password"
            name="retypePassword"
            type={showRetypePassword ? 'text' : 'password'}
            value={formData.retypePassword}
            onChange={handleChange}
            size="small"
            fullWidth
            error={passwordMismatch}
            helperText={passwordMismatch ? 'Passwords do not match' : ''}
            autoComplete="new-password" // 🔑 stop autofill
            InputProps={{
              endAdornment: (
                <InputAdornment position="end">
                  <IconButton onClick={() => setShowRetypePassword((prev) => !prev)} edge="end">
                    {showRetypePassword ? (
                      <VisibilityOff style={{ color: '#1f2837' }} />
                    ) : (
                      <Visibility style={{ color: '#1f2837' }} />
                    )}
                  </IconButton>
                </InputAdornment>
              ),
            }}
          />

          <TextField
            select
            label="Role"
            name="role"
            value={formData.role}
            onChange={handleChange}
            size="small"
            fullWidth
            autoComplete="off" // 🔑 stop autofill
          >
            {roles.map((role) => (
              <MenuItem key={role} value={role}>
                {role}
              </MenuItem>
            ))}
          </TextField>

          <Button
            variant="contained"
            type="submit"
            style={{
              backgroundColor: '#1f2837',
              color: 'white',
              fontWeight: 'bold',
              padding: '10px',
              borderRadius: '8px',
            }}
          >
            Submit
          </Button>
        </form>
      </div>
    </div>
  );
};

export default UserCreate;
