import React, { useEffect, useState, useRef } from 'react';
import * as monaco from 'monaco-editor';
import loader from '@monaco-editor/loader';
import ApexCharts from 'apexcharts';

function PieChart({XAxis, YAxis}) {
    const chartRef = useRef(null);

    useEffect(() => {
        // Define chart options
        // if (XAxis.length > 0 && YAxis.length > 0 && seriesData.length > 0) {
        const chartOptions = {
            series: YAxis,
            labels: XAxis,
            chart: {
                type: 'donut',
                height: 350,
                toolbar: {
                    show: true
                }
            },
            responsive: [{
                breakpoint: 480,
                options: {
                    chart: {
                        width: 200
                    },
                    legend: {
                        position: 'bottom'
                    }
                }
            }]
        };
        console.log(chartOptions)
        // Create a new chart instance
        const chart = new ApexCharts(chartRef.current, chartOptions);
        chart.render();

        // Cleanup chart on component unmount
        return () => {
            chart.destroy();
        };
        // }
    }, [XAxis, YAxis]);

    return <div ref={chartRef}></div>;
}

export default PieChart;
