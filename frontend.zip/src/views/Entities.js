import React, { useEffect, useState } from "react";
import Modal from "react-modal";
import axios from "axios";
import $ from "jquery";
import "datatables.net-dt/css/dataTables.dataTables.css";
import "datatables.net";
import "./Entities.css";
import { FaPlus } from "react-icons/fa";
import { toast } from "react-hot-toast";

Modal.setAppElement("#root");

const Entities = () => {
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [selectedTable, setSelectedTable] = useState(null);
    const [totalRows, setTotalRows] = useState(0);

    // ✅ CSV download handler
    const handleDownloadCSV = async (tableName) => {
        console.log("Downloading CSV for:", tableName);
        try {
            const response = await axios.get(
                `http://localhost:8083/entity/download`,
                {
                    params: { tableName },
                    responseType: "blob",
                }
            );

            const blob = new Blob([response.data], { type: "text/csv" });
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement("a");
            a.href = url;
            a.download = `${tableName}.csv`;
            document.body.appendChild(a);
            a.click();
            a.remove();
            window.URL.revokeObjectURL(url);

            console.log("✅ CSV downloaded successfully");
        } catch (error) {
            console.error("❌ Error downloading CSV:", error);
            alert("Failed to download CSV for " + tableName);
        }
    };

    // ✅ Fetch list of entities
    useEffect(() => {
        const fetchEntities = async () => {
            try {
                const response = await axios.get("http://localhost:8083/entity/getAll");
                const data = response.data;

                if ($.fn.DataTable.isDataTable("#entityListTable")) {
                    $("#entityListTable").DataTable().destroy();
                }

                // ✅ Initialize DataTable
                const table = $("#entityListTable").DataTable({
                    data: data.map((row) => [
                        row.dimensionTableName,
                        row.dimensionType === 1 ? "File Upload" : "SQL Upload",
                        row.createdAt
                            ? new Date(row.createdAt).toLocaleString("en-GB", {
                                day: "2-digit",
                                month: "2-digit",
                                year: "numeric",
                                hour: "2-digit",
                                minute: "2-digit",
                            })
                            : "—",
                        `<button type="button" class="btn btn-sm btn-primary download-btn" data-table="${row.dimensionTableName}">
              Download File
            </button>`,
                    ]),
                    columns: [
                        { title: "Dimension Table Name" },
                        { title: "Dimension Type" },
                        { title: "Date" },
                        { title: "Actions" },
                    ],
                    destroy: true,
                    autoWidth: false,
                    paging: true,
                    scrollX: true,
                });

                // ✅ Download button click
                $("#entityListTable tbody").off("click", ".download-btn");
                $("#entityListTable tbody").on("click", ".download-btn", function (e) {
                    e.stopPropagation();
                    const tableName = $(this).data("table");
                    handleDownloadCSV(tableName);
                });

                // ✅ Row click → open modal to view data
                $("#entityListTable tbody")
                    .off("click", "tr")
                    .on("click", "tr", function (event) {
                        if ($(event.target).hasClass("download-btn")) return;
                        const rowData = table.row(this).data();
                        if (rowData && rowData[0]) {
                            setSelectedTable(rowData[0]);
                            setIsModalOpen(true);
                        }
                    });
            } catch (err) {
                console.error("Error fetching entities:", err);
                toast.error("Failed to fetch entities");
            }
        };

        fetchEntities();
    }, []);

    // ✅ Initialize DataTable inside modal (paginated)
    useEffect(() => {
        if (selectedTable && isModalOpen) {
            const initDataTable = async () => {
                try {
                    const response = await axios.get(
                        "http://localhost:8083/entity/data",
                        { params: { tableName: selectedTable, page: 1, size: 10 } }
                    );

                    const { data, totalRows } = response.data;
                    setTotalRows(totalRows);

                    if (!data || data.length === 0) {
                        $("#viewEntityTable").html("<tr><td>No data available</td></tr>");
                        return;
                    }

                    const columns = Object.keys(data[0]).map((col) => ({
                        title: col.replace(/_/g, " ").toUpperCase(),
                        data: col,
                    }));

                    if ($.fn.DataTable.isDataTable("#viewEntityTable")) {
                        $("#viewEntityTable").DataTable().destroy();
                    }

                    $("#viewEntityTable").DataTable({
                        serverSide: true,
                        processing: true,
                        ajax: async (data, callback) => {
                            const page = Math.floor(data.start / data.length) + 1;
                            const size = data.length;

                            const res = await axios.get(
                                "http://localhost:8083/entity/data",
                                { params: { tableName: selectedTable, page, size } }
                            );

                            callback({
                                draw: data.draw,
                                recordsTotal: res.data.totalRows,
                                recordsFiltered: res.data.totalRows,
                                data: res.data.data,
                            });
                        },
                        columns: columns,
                        scrollX: true,
                        paging: true,
                        pageLength: 10,
                        autoWidth: false,
                        responsive: true,
                        destroy: true,
                    });
                } catch (err) {
                    console.error("Error loading entity data:", err);
                }
            };

            initDataTable();
        }
    }, [selectedTable, isModalOpen]);

    return (
        <div
            className="px-4 pb-4 w-full bg-gray-50"
            style={{ marginTop: "64px", height: "calc(100vh - 64px)" }}
        >
            <h2 className="text-xl font-bold mb-4">Entities</h2>

            {/* Entity Table List */}
            <div id="EntityListContainer">
                <table
                    id="entityListTable"
                    className="display w-full hover cell-border custom-headers"
                ></table>
            </div>

            {/* Add new entity button */}
            <nav className="mt-6">
                <button
                    onClick={() => setIsModalOpen(true)}
                    className="flex items-center space-x-2 text-white bg-[#32bef0] hover:bg-blue-700 px-3 py-2 rounded-full"
                >
                    <FaPlus />
                    <span className="text-sm font-medium">Add Assumptions/Policy Data</span>
                </button>
            </nav>

            {/* Modal */}
            <Modal
                isOpen={isModalOpen}
                onRequestClose={() => setIsModalOpen(false)}
                overlayClassName="customModalOverlay"
                className="customModalContent"
                ariaHideApp={false}
            >
                <div className="w-full h-full grid grid-rows-[auto_1fr_auto]">
                    {/* Header */}
                    <div className="header flex justify-between items-center px-4 py-2 border-b">
                        <span className="font-semibold text-lg">
                            {selectedTable ? `${selectedTable} (${totalRows} rows)` : "Entity Upload / View"}
                        </span>
                        <button onClick={() => setIsModalOpen(false)}>
                            <box-icon name="x"></box-icon>
                        </button>
                    </div>

                    {/* Table content */}
                    <div id="TableContainer" className="w-full px-4 overflow-x-auto">
                        <table
                            id="viewEntityTable"
                            className="row-border w-full text-xs nowrap"
                        ></table>
                    </div>

                    {/* Footer */}
                    <div className="footer flex justify-end p-2 border-t">
                        <button
                            onClick={() => setIsModalOpen(false)}
                            className="red-button flex items-center px-3 py-1 text-red-600 font-semibold border border-red-400 rounded hover:bg-red-50"
                        >
                            <box-icon color="red" name="x"></box-icon> CLOSE
                        </button>
                    </div>
                </div>
            </Modal>
        </div>
    );
};

export default Entities;
