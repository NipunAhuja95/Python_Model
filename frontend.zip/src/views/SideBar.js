import React, { useState, useEffect } from "react";
import { FaChevronDown, FaChevronRight, FaUser } from "react-icons/fa";
import { jwtDecode } from 'jwt-decode'; // You'll need to install this: npm install jwt-decode

const Sidebar = ({ setActivePage, activePage }) => {
  const [openMenu, setOpenMenu] = useState({
    masters: false,
    config: false,
  });

  const [searchTerm, setSearchTerm] = useState("");
  const [username, setUsername] = useState("");

  // Store selected item labels
  const [selected, setSelected] = useState({
    masters: "Masters",
    config: "Config",
  });

  // Extract username from JWT token
  useEffect(() => {
    try {
      const token = localStorage.getItem("jwtToken");
      if (token) {
        const decodedToken = jwtDecode(token);
        // Assuming the username is stored in the token as 'username' or 'sub'
        // Adjust the property name based on your JWT structure
        setUsername(decodedToken.username || decodedToken.sub || decodedToken.email || "User");
      }
    } catch (error) {
      console.error("Error decoding JWT token:", error);
      setUsername("User");
    }
  }, []);

  const toggleMenu = (menu) => {
    setOpenMenu((prev) => ({
      ...prev,
      [menu]: !prev[menu],
    }));
  };

  const handleLogout = () => {
    localStorage.removeItem("jwtToken");
    window.location.href = "/";
  };

  const handleResetPage = () => {
    setActivePage("home");
    setSelected({ masters: "Masters", config: "Config" }); // reset dropdown labels
  };

  const handleSelect = (section, item) => {
    setActivePage(item.key);
    setSelected((prev) => ({
      ...prev,
      [section]: item.label, // replace dropdown button text with selection
    }));
    setOpenMenu((prev) => ({
      ...prev,
      [section]: false, // close the dropdown
    }));
  };

  const menuItems = {
    masters: [
      { label: "User", key: "UserCreate" },
      { label: "Assumptions / Policy Data", key: "Entities" },
      { label: "OutputTables", key: "OutputTables" },
      { label: "Visualize Tables", key: "VisualizeTables" },
      { label: "LLM", key: "LLM" },
    ],
    config: [{ label: "Run Configuration", key: "UserInput" }],
  };

  const filteredMenuItems = Object.entries(menuItems).reduce(
    (acc, [section, items]) => {
      const filtered = items.filter((item) =>
        item.label.toLowerCase().includes(searchTerm.toLowerCase())
      );
      if (filtered.length > 0) acc[section] = filtered;
      return acc;
    },
    {}
  );

  return (
    <nav className="w-full fixed top-0 left-0 z-50 bg-gray-800 text-white shadow-md">
      <div className="flex items-center justify-between px-6 py-3">
        {/* Logo / Title */}
        <div
          className="flex items-center space-x-3 cursor-pointer"
          onClick={handleResetPage}
        >
          <div className="bg-yellow-500 text-black font-bold px-2 py-1 rounded">
            EY
          </div>
          <div>
            <h1 className="font-bold text-lg">Rule Engine</h1>
            <p className="text-xs text-gray-400">Data Processing Platform</p>
          </div>
        </div>

        {/* Search */}
        <div className="flex-1 mx-6 max-w-md">
          <input
            type="text"
            placeholder="Search modules..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full px-3 py-1 rounded bg-gray-700 text-white placeholder-gray-400 focus:outline-none"
          />
        </div>

        {/* Dropdown Menus */}
        <div className="flex items-center space-x-6">
          {/* Masters */}
          {filteredMenuItems.masters && (
            <div className="relative">
              <button
                onClick={() => toggleMenu("masters")}
                className="flex items-center space-x-2 hover:text-yellow-400"
              >
                <span>{selected.masters}</span>
                {openMenu.masters ? <FaChevronDown /> : <FaChevronRight />}
              </button>
              {openMenu.masters && (
                <div className="absolute top-full left-0 mt-2 w-48 bg-gray-700 rounded shadow-lg py-2 z-50">
                  {filteredMenuItems.masters.map((item) => (
                    <button
                      key={item.key}
                      onClick={() => handleSelect("masters", item)}
                      className={`block w-full text-left px-4 py-2 text-sm hover:bg-gray-600 ${activePage === item.key ? "bg-gray-600" : ""
                        }`}
                    >
                      {item.label}
                    </button>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Config */}
          {filteredMenuItems.config && (
            <div className="relative">
              <button
                onClick={() => toggleMenu("config")}
                className="flex items-center space-x-2 hover:text-yellow-400"
              >
                <span>{selected.config}</span>
                {openMenu.config ? <FaChevronDown /> : <FaChevronRight />}
              </button>
              {openMenu.config && (
                <div className="absolute top-full left-0 mt-2 w-48 bg-gray-700 rounded shadow-lg py-2 z-50">
                  {filteredMenuItems.config.map((item) => (
                    <button
                      key={item.key}
                      onClick={() => handleSelect("config", item)}
                      className={`block w-full text-left px-4 py-2 text-sm hover:bg-gray-600 ${activePage === item.key ? "bg-gray-600" : ""
                        }`}
                    >
                      {item.label}
                    </button>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Username Display */}
          <div className="flex items-center space-x-2 px-3 py-1 bg-gray-700 rounded">
            <FaUser className="text-gray-400" />
            <span className="text-sm font-medium">{username}</span>
          </div>

          {/* Logout */}
          <button
            onClick={handleLogout}
            className="hover:text-red-400 flex items-center px-3 py-1 rounded hover:bg-gray-700 transition-colors"
          >
            Logout
          </button>
        </div>
      </div>
    </nav>
  );
};

export default Sidebar;