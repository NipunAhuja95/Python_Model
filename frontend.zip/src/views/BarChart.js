import React, { useEffect, useState, useRef } from 'react';
import * as monaco from 'monaco-editor';
import loader from '@monaco-editor/loader';
import ApexCharts from 'apexcharts';

function BarChart({XAxis, YAxis, seriesData}) {
  const chartRef = useRef(null);

  useEffect(() => {
    console.log("inside bar chart")
    console.log(XAxis)
    // Define chart options
    if (XAxis.length > 0 && YAxis.length > 0 && seriesData.length > 0) {
      const chartOptions = {
        chart: {
          type: 'bar',
          height: 350,
        },
        series: [
          {
            name: seriesData[1],
            data: XAxis,
          },
        ],
        xaxis: {
          categories: YAxis,
          title: {
            text: seriesData[0]
          }
        },
        yaxis: {
          title: {
            text: seriesData[1]
          }
        }
      };

      // Create a new chart instance
      const chart = new ApexCharts(chartRef.current, chartOptions);
      chart.render();

      // Cleanup chart on component unmount
      return () => {
        chart.destroy();
      };
    }
  }, [XAxis, YAxis, seriesData]);

  return <div ref={chartRef}></div>;
}

export default BarChart;
