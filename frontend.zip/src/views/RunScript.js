import React, { useState } from "react";
import Sidebar from "./SideBar";
import Master from "./Master";
import UserInput from "./UserInput";
import Entities from "./Entities";
import OutputTables from "./OutputTables";
import VisualizeTables from "./VisualizeTables";
import UserCreate from "./UserCreate";
import LLM from './LLM';
import "./RunScript.css";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const HomePage = () => {
  return (
    <div className="flex flex-col items-center justify-center h-full px-6 space-y-8">
      {/* Welcome Message */}
      <div className="ey-card fade-in w-full max-w-4xl">
        <div className="ey-card-body text-center">
          <h1 className="text-2xl font-bold text-gray-800 mb-2">
            👋 Welcome to EY Rule Engine
          </h1>
          <p className="text-gray-600">
            Get started by following these simple steps.
          </p>
        </div>
      </div>

      {/* Getting Started */}
      <div className="ey-card bounce-in w-full max-w-4xl">
        <div className="ey-card-header text-center">
          <h3 className="text-lg font-semibold">Getting Started</h3>
          <p className="text-sm text-gray-600">
            New to the platform? Follow these steps
          </p>
        </div>
        <div className="ey-card-body">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 text-center">
            <div className="getting-started-step">
              <div className="step-number">1</div>
              <h4 className="step-title">Create Users</h4>
              <p className="step-description">Manage system access</p>
            </div>

            <div className="getting-started-step">
              <div className="step-number">2</div>
              <h4 className="step-title">Setup assumptions & Policy Data</h4>
              <p className="step-description">Upload assumptions & Policy Data</p>
            </div>

            <div className="getting-started-step">
              <div className="step-number">3</div>
              <h4 className="step-title">Setup Run Config and kick-off run</h4>
              <p className="step-description">Execute your first analysis</p>
            </div>

            <div className="getting-started-step">
              <div className="step-number">4</div>
              <h4 className="step-title">View Results</h4>
              <p className="step-description">Analyze output and visualize</p>
            </div>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="text-center text-sm text-gray-500 mt-6">
        © {new Date().getFullYear()} EY Rule Engine. All rights reserved.
      </footer>
    </div>
  );
};


const RunScript = () => {
  const [activePage, setActivePage] = useState("Home");

  const renderPage = () => {
    switch (activePage) {
      case "Master":
        return <Master />;
      case "OutputTables":
        return <OutputTables />;
      case "UserInput":
        return <UserInput />;
      case "Entities":
        return <Entities />;
      case "UserCreate":
        return <UserCreate />;
      case "VisualizeTables":
        return <VisualizeTables />;
      case 'LLM':
        return <LLM />;
      case "Home":
      default:
        return <HomePage />;
    }
  };

  return (
    <div className="flex h-screen overflow-hidden">
      <Sidebar setActivePage={setActivePage} activePage={activePage} />
      <div
        id="mainContainer"
        className="flex-1 flex flex-col h-full overflow-auto"
      >
        {renderPage()}
      </div>
      <ToastContainer position="top-right" autoClose={3000} />
    </div>
  );
};

export default RunScript;
